'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { loadJSON } = require('../jsonStore');
const { TICKETS_PATH } = require('../tickets');
const { isStaffInteraction } = require('../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('remove')
    .setDescription('Remove a user from the current ticket channel')
    .addUserOption((opt) => opt.setName('user').setDescription('User to remove').setRequired(true)),

  async execute(interaction) {
    const tickets = loadJSON(TICKETS_PATH);
    const ticketInfo = tickets[interaction.channel.id];
    if (!ticketInfo) {
      return interaction.reply({ content: '❌ This command may only be used inside a ticket channel.', ephemeral: true });
    }

    const isOwner = interaction.user.id === ticketInfo.owner;
    if (!isStaffInteraction(interaction) && !isOwner) {
      return interaction.reply({ content: '❌ Only staff or the ticket owner can manage ticket access.', ephemeral: true });
    }

    const user = interaction.options.getUser('user', true);
    if (user.id === ticketInfo.owner) {
      return interaction.reply({ content: '❌ You cannot remove the ticket owner from their own ticket.', ephemeral: true });
    }

    await interaction.channel.permissionOverwrites.delete(user.id).catch(() => {});
    return interaction.reply({ content: `✅ **${user.tag}** removed from this ticket.` });
  },
};
