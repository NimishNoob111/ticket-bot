'use strict';

const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Show all available commands.'),

  async execute(interaction) {
    const embed = infoEmbed({
      title: 'Pterodactyl Control Bot — Command Reference',
      description:
        'Manage game server deployments directly from Discord.\n\u200b',
      fields: [
        {
          name: '👤 User Commands',
          value: [
            '`/nothing help` — Show this menu.',
            '`/nothing link <email>` — Link your Discord account to your Pterodactyl panel account. (Staff can add `user:` to link someone else.)',
            '`/nothing status [user]` — View server stats for yourself, or (staff only) another user.',
          ].join('\n'),
        },
        {
          name: '\u200b',
          value: '\u200b',
        },
        {
          name: '📦 Server Owner Management',
          value: [
            '`/nothing subuser add <user> <server_id>` — Grant a friend console + power access to your server.',
            '`/nothing subuser remove <user> <server_id>` — Revoke that access.',
            '`/nothing config set <server_id> <key> <value>` — Edit a key in your server.properties file.',
            '`/nothing plugin install <server_id> <plugin> [mc_version]` — Install the latest compatible plugin from Modrinth or SpigotMC.',
          ].join('\n'),
        },
        {
          name: '\u200b',
          value: '\u200b',
        },
        {
          name: '🛠️ Admin Utilities',
          value: [
            '`/nothing deploy <username> <email> <server_name> <ram_gb>` — Create a panel account (if needed) and deploy a Minecraft Paper server in one step.',
            '`/nothing upgrade <server_id_or_uuid> <new_ram_gb>` — Scale an existing server\'s RAM/CPU limits up or down.',
            '`/nothing console command <server_id> <command>` — Send a raw console command to a server.',
            '`/nothing console power <server_id> <start|stop|restart|kill>` — Control a server\'s power state.',
            '`/nothing server renew <server_id>` — Unsuspend a server.',
            '`/nothing server suspend <server_id>` — Suspend a server.',
            '`/nothing server delete <server_id> <confirm_name>` — Permanently delete a server (requires typing its name to confirm).',
          ].join('\n'),
        },
      ],
    });

    await interaction.reply({ embeds: [embed] });
  },
};
