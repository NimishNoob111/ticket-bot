'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const ptero = require('../pterodactyl');
const { successEmbed, errorEmbed } = require('../utils/embeds');
const { hasManageServerPermission } = require('../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('upgrade')
    .setDescription("ADMIN: Scale a server's RAM/CPU limits.")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((o) =>
      o
        .setName('server_id_or_uuid')
        .setDescription('The internal server ID or full/short UUID')
        .setRequired(true)
    )
    .addIntegerOption((o) =>
      o
        .setName('new_ram_gb')
        .setDescription('New RAM allocation, in GB')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(64)
    ),

  async execute(interaction) {
    if (!hasManageServerPermission(interaction)) {
      await interaction.reply({
        embeds: [
          errorEmbed({
            title: 'Permission Denied',
            description: 'This command requires the **Administrator** permission.',
          }),
        ],
        ephemeral: true,
      });
      return;
    }

    const serverIdentifier = interaction.options.getString('server_id_or_uuid', true).trim();
    const newRamGb = interaction.options.getInteger('new_ram_gb', true);

    await interaction.deferReply();

    try {
      const current = await ptero.getServer(serverIdentifier);

      if (!current.ok) {
        await interaction.editReply({
          embeds: [
            errorEmbed({
              title: 'Server Not Found',
              description: current.error,
            }),
          ],
        });
        return;
      }

      const attrs = current.data.attributes;
      const oldLimits = attrs.limits;

      const newMemory = newRamGb * 1024;
      const newCpu = newRamGb * 100;

      const buildPayload = {
        limits: {
          memory: newMemory,
          swap: oldLimits.swap ?? 0,
          disk: oldLimits.disk, // kept as-is per spec
          io: oldLimits.io ?? 500,
          cpu: newCpu,
        },
        // feature_limits is required by the Pterodactyl build endpoint —
        // reuse the server's existing values so nothing else changes.
        feature_limits: {
          databases: attrs.feature_limits?.databases ?? 0,
          backups: attrs.feature_limits?.backups ?? 0,
          allocations: attrs.feature_limits?.allocations ?? 1,
        },
        allocation: attrs.allocation,
      };

      const updated = await ptero.updateServerBuild(serverIdentifier, buildPayload);

      if (!updated.ok) {
        await interaction.editReply({
          embeds: [
            errorEmbed({
              title: 'Failed To Upgrade Server',
              description: updated.error,
            }),
          ],
        });
        return;
      }

      await interaction.editReply({
        embeds: [
          successEmbed({
            title: 'Server Resources Updated',
            description: `**${attrs.name}** has been rescaled.`,
            fields: [
              {
                name: 'RAM',
                value: `${oldLimits.memory} MB  ➜  **${newMemory} MB**`,
              },
              {
                name: 'CPU',
                value: `${oldLimits.cpu}%  ➜  **${newCpu}%**`,
              },
              {
                name: 'Disk (unchanged)',
                value: `${oldLimits.disk} MB`,
              },
            ],
          }),
        ],
      });
    } catch (err) {
      console.error('[/upgrade] Unexpected error:', err);
      await interaction.editReply({
        embeds: [
          errorEmbed({
            description: 'An unexpected error occurred. Check the bot console logs.',
          }),
        ],
      });
    }
  },
};
