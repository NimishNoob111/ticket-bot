'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const music = require('../music');
const { checkVoiceState } = require('../musicGuards');

module.exports = {
  data: new SlashCommandBuilder().setName('nowplaying').setDescription("Show what's currently playing"),

  async execute(interaction) {
    const denial = checkVoiceState(interaction, 'nowplaying');
    if (denial) return interaction.reply(denial);

    const queue = music.getQueue(interaction.guild.id);
    if (!queue) return interaction.reply({ content: '❌ Nothing is playing right now.', ephemeral: true });

    const current = queue.songs[0];
    if (!current) return interaction.reply({ content: '❌ Nothing is playing right now.', ephemeral: true });

    const embed = new EmbedBuilder()
      .setColor(0x2B6CB0)
      .setTitle('🎶 Now Playing')
      .setDescription(`[${current.title}](${current.url})`)
      .addFields(
        { name: 'Duration', value: music.formatDuration(current.durationSec), inline: true },
        { name: 'Requested by', value: `<@${current.requestedBy}>`, inline: true },
        { name: 'Loop', value: queue.loop, inline: true },
      );
    if (current.thumbnail) embed.setThumbnail(current.thumbnail);
    return interaction.reply({ embeds: [embed] });
  },
};
