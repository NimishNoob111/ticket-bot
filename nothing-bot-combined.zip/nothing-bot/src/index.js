'use strict';

require('dotenv').config();

const path = require('node:path');
const fs = require('node:fs');
const { Client, Collection, GatewayIntentBits, Partials, Events, EmbedBuilder } = require('discord.js');

const { initDatabase } = require('./database');
const { errorEmbed } = require('./utils/embeds');
const { hasAllowedRole } = require('./utils/permissions');
const tickets = require('./tickets');
const moderation = require('./moderation');
const music = require('./music');

// ---------------------------------------------------------------------------
// Environment validation — fail fast with a clear message instead of a
// confusing crash three layers deep.
// ---------------------------------------------------------------------------
const REQUIRED_ENV = ['DISCORD_TOKEN', 'PTERO_URL', 'PTERO_APP_KEY'];
const missing = REQUIRED_ENV.filter((key) => !process.env[key]);

if (missing.length > 0) {
  console.error(
    `[Startup] Missing required environment variable(s): ${missing.join(', ')}.\n` +
      'Copy .env.example to .env and fill in the values before starting the bot.'
  );
  process.exit(1);
}

if (!process.env.STAFF_ROLE_ID) {
  console.warn('⚠️  STAFF_ROLE_ID is not set in .env — ticket/moderation staff checks will fall back to Administrator-only.');
}

const LOG_CHANNEL_ID = process.env.LOG_CHANNEL_ID || null;
if (!LOG_CHANNEL_ID) {
  console.warn('⚠️  LOG_CHANNEL_ID is not set in .env — moderation/ticket action logging is disabled until you set it.');
}

// ---------------------------------------------------------------------------
// Database (Pterodactyl <-> Discord account linking)
// ---------------------------------------------------------------------------
initDatabase();

// ---------------------------------------------------------------------------
// Discord Client
// ---------------------------------------------------------------------------
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates, // required for the music system
  ],
  partials: [Partials.Channel],
});

async function logAction(guild, embed) {
  if (!LOG_CHANNEL_ID) return;
  try {
    const ch = guild.channels.cache.get(LOG_CHANNEL_ID) || (await guild.channels.fetch(LOG_CHANNEL_ID).catch(() => null));
    if (ch) await ch.send({ embeds: [embed] }).catch(() => {});
  } catch (e) {
    /* ignore */
  }
}

const ctx = { logAction };

// ---------------------------------------------------------------------------
// Slash commands — every file in ./commands exports { data, execute }.
// ---------------------------------------------------------------------------
client.commands = new Collection();

const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter((f) => f.endsWith('.js'));

for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));

  if (!command?.data || typeof command.execute !== 'function') {
    console.warn(`[Startup] Skipping invalid command file: ${file}`);
    continue;
  }

  client.commands.set(command.data.name, command);
  console.log(`[Startup] Loaded command: /${command.data.name}`);
}

// Commands that stay open to everyone regardless of ALLOWED_ROLE_ID.
// Only the Pterodactyl-facing `/nothing` dispatcher is gated by this role at
// all (ticket/moderation/music commands have their own, separate staff
// checks) — and even then, `/nothing help` always stays open.
function isGatedByAllowedRole(interaction) {
  if (interaction.commandName !== 'nothing') return false;
  return interaction.options.getSubcommand(false) !== 'help';
}

// ---------------------------------------------------------------------------
// Ticket system + moderation (profanity filter, anti-ping quarantine)
// ---------------------------------------------------------------------------
tickets.register(client, ctx);
moderation.register(client, ctx);

// ---------------------------------------------------------------------------
// Ready
// ---------------------------------------------------------------------------
client.once(Events.ClientReady, async (readyClient) => {
  console.log(`[Startup] Logged in as ${readyClient.user.tag}`);
  console.log(`[Startup] Serving ${readyClient.guilds.cache.size} guild(s)`);

  readyClient.user.setActivity('server infrastructure', { type: 3 });

  // Whenever a song auto-advances (not triggered by /play itself), announce
  // it in whichever text channel the queue was started from.
  music.setNowPlayingNotifier((guildId, song, err) => {
    const queue = music.getQueue(guildId);
    if (!queue) return;
    const channel = readyClient.channels.cache.get(queue.textChannelId);
    if (!channel) return;
    if (err) {
      channel.send({ content: `⚠️ Skipping **${song.title}** — couldn't stream it (${err.message}).` }).catch(() => {});
      return;
    }
    const embed = new EmbedBuilder()
      .setColor(0x2B6CB0)
      .setTitle('🎶 Now Playing')
      .setDescription(`[${song.title}](${song.url})`)
      .addFields({ name: 'Requested by', value: `<@${song.requestedBy}>`, inline: true });
    if (song.thumbnail) embed.setThumbnail(song.thumbnail);
    channel.send({ embeds: [embed] }).catch(() => {});
  });

  for (const guild of readyClient.guilds.cache.values()) {
    await moderation.ensureQuarantineRole(guild);
  }
});

// ---------------------------------------------------------------------------
// Slash command interaction routing
// ---------------------------------------------------------------------------
client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);

  if (!command) {
    console.warn(`[Interaction] Unknown command received: /${interaction.commandName}`);
    return;
  }

  if (isGatedByAllowedRole(interaction) && !hasAllowedRole(interaction)) {
    await interaction.reply({
      embeds: [
        errorEmbed({
          title: 'Access Restricted',
          description: 'You need the required role to use this bot.',
        }),
      ],
      ephemeral: true,
    });
    return;
  }

  try {
    await command.execute(interaction, ctx);
  } catch (error) {
    console.error(`[Interaction] Error executing /${interaction.commandName}:`, error);

    const payload = {
      embeds: [
        errorEmbed({
          description:
            'An unexpected error occurred while running this command. The bot owner has been logged the details.',
        }),
      ],
      ephemeral: true,
    };

    try {
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(payload);
      } else {
        await interaction.reply(payload);
      }
    } catch (followUpError) {
      console.error('[Interaction] Failed to send error response:', followUpError);
    }
  }
});

// ---------------------------------------------------------------------------
// Music commands are triggered via the same InteractionCreate event above
// (they're plain slash commands, routed through client.commands like
// everything else) — no separate listener needed.
// ---------------------------------------------------------------------------

process.on('unhandledRejection', (reason) => {
  console.error('[Process] Unhandled promise rejection:', reason);
});

client.login(process.env.DISCORD_TOKEN);
