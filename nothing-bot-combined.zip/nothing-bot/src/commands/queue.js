'use strict';

const { SlashCommandBuilder } = require('discord.js');
const music = require('../music');
const { checkVoiceState } = require('../musicGuards');

module.exports = {
  data: new SlashCommandBuilder().setName('queue').setDescription('Show the current music queue'),

  async execute(interaction) {
    const denial = checkVoiceState(interaction, 'queue');
    if (denial) return interaction.reply(denial);

    const queue = music.getQueue(interaction.guild.id);
    if (!queue) return interaction.reply({ content: '❌ Nothing is playing right now.', ephemeral: true });

    return interaction.reply({ embeds: [music.buildQueueEmbed(queue, interaction.guild.name)] });
  },
};
