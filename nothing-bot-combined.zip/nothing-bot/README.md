# Nothing — Combined Discord Bot

Your two bots merged into **one** Discord application: the ticket /
moderation / music bot, plus the Pterodactyl panel-control bot. One
`DISCORD_TOKEN`, one process, one `npm start`.

## What changed from your two separate projects

### Node config (the reason you asked for this)
- Deploying used to be hardcoded to a single `DEFAULT_NODE_ID` (node 1).
  That node is gone now, so it's replaced with **`NODE_IDS`** in `.env` —
  a comma-separated list the bot tries in order until it finds a node with
  a free allocation. It's already set to `NODE_IDS=2,3`.
- `/nothing deploy` (and `/nothing upgrade`, unaffected) now report back
  *which* node it actually landed the server on, instead of always
  printing the old static node number.
- If both nodes are full, you get one clear error listing why each node
  was skipped, instead of a single opaque failure.

### The two bots' `/nothing` command collision
Both bots separately registered a top-level `/nothing` command with
different subcommands — that can't coexist as two separate Discord
applications sharing a command name cleanly, and definitely can't once
they're one process. They're merged into a single `/nothing` with all
subcommands from both: `help`, `link`, `status`, `deploy`, `upgrade`,
`whitelist`, `unwhitelist`, plus the `console`/`subuser`/`config`/`server`/
`plugin` subcommand groups.

### Other bugs fixed along the way
- **Dead cookies config**: your old `.env` had `YOUTUBE_COOKIE=...`, but
  `music.js` only ever read `YOUTUBE_COOKIES_FILE` — so your YouTube
  cookies were silently never applied. Fixed the variable name in `.env`.
- **Unused `QUARANTINE_ROLE_ID`**: this was in your `.env` but the code
  always looked up the quarantine role by the literal name `"Quarantine"`
  instead, ignoring the ID. Now it checks `QUARANTINE_ROLE_ID` first and
  falls back to the name search — more robust if that role ever gets
  renamed.
- **Dead files removed**: `ticket-auto-responder.js` and
  `ticket-autoresponder.js` were two abandoned draft versions of the
  auto-greeter, neither of which was ever wired into `index.js` — the
  ticket bot's real (and better) auto-greeter logic was already inline.
  Not carried over; nothing used them.
- Staff checks across tickets/quarantine/whitelist are now one shared
  `isStaffMember()` helper (Administrator OR `STAFF_ROLE_ID`) instead of
  being re-typed slightly differently in half a dozen places.

### ⚠️ Your bot token was exposed
Your uploaded `bot_backup.zip` had a live `DISCORD_TOKEN` sitting in plain
text `.env`. Treat it as compromised — **regenerate it** in the
[Discord Developer Portal](https://discord.com/developers/applications) →
your app → Bot → Reset Token, and put the *new* token in `.env`. I left
`DISCORD_TOKEN` blank in the generated `.env` on purpose so the old one
doesn't get reused anywhere. Same goes for `cookies.txt` /
`youtube-cookies.txt` if that YouTube account matters to you — a leaked
cookies file lets someone else act as that logged-in session.

## Project layout

```
nothing-bot/
├── package.json
├── .env                 # prefilled with your real ticket-bot config (token blanked, see above)
├── .env.example          # clean template, safe to share
├── cookies.txt            # your YouTube cookies (gitignored, don't share)
├── data/
│   ├── bad-words.json          # your existing filter list
│   ├── swear-offenses.json     # your existing offense counts
│   ├── tickets.json            # your existing ticket history
│   ├── whitelist.json          # your existing ping-whitelist
│   └── bot.sqlite               # auto-created — Discord<->Pterodactyl account links
└── src/
    ├── index.js              # single entrypoint: client, command loader, event wiring
    ├── deploy-commands.js    # registers every command in src/commands
    ├── database.js           # SQLite — Pterodactyl account linking
    ├── jsonStore.js          # race-safe JSON read/modify/write for tickets/whitelist/offenses
    ├── pterodactyl.js        # Pterodactyl API client (now with multi-node allocation lookup)
    ├── plugins.js            # Modrinth/SpigotMC plugin resolution for /nothing plugin install
    ├── music.js               # yt-dlp based music queue/playback engine
    ├── musicGuards.js         # shared voice-channel checks for the music commands
    ├── tickets/index.js      # ticket panel/modal/button logic + config
    ├── moderation/index.js   # profanity filter + anti-mass-ping auto-quarantine
    ├── handlers/             # Pterodactyl command implementations (help/link/status/deploy/...)
    ├── utils/
    │   ├── embeds.js
    │   └── permissions.js    # both permission systems: ManageGuild/Admin (ptero) + staff role (tickets)
    └── commands/              # one file per slash command, auto-loaded by index.js
```

## 1. Prerequisites

- Node.js **18+**
- A Discord Application + Bot ([discord.com/developers/applications](https://discord.com/developers/applications))
- A Pterodactyl panel with an **Application API key** (Admin → API
  Credentials — different from a user's Client API key)
- `yt-dlp` installed and on `PATH` (or point `YTDLP_PATH` at it) for music:
  `pip install -U yt-dlp`
- `ffmpeg` is bundled via the `ffmpeg-static` npm package — nothing extra
  to install for that part.

## 2. Install

```bash
cd nothing-bot
npm install
```

`better-sqlite3` compiles a small native addon on install — if it fails,
make sure `python3`, `make`, and a C++ toolchain are available
(`build-essential` on Debian/Ubuntu), or use a Node LTS version (18/20/22)
that has prebuilt binaries.

## 3. Configure

`.env` is already filled in with your real ticket-bot settings (categories,
staff role, etc.) — you still need to:

1. Paste a **new, regenerated** `DISCORD_TOKEN` (see the warning above).
2. Fill in `PTERO_URL` and `PTERO_APP_KEY` for your panel.
3. Double check `DEFAULT_NEST_ID` / `DEFAULT_EGG_ID` match your panel's
   Minecraft/Paper nest+egg (Admin → Nests), and that `DEFAULT_DOCKER_IMAGE`
   / `DEFAULT_STARTUP_CMD` match your egg's actual config.
4. `NODE_IDS=2,3` is already set — add/remove node IDs there if that
   changes again in the future.
5. Optional: set `PTERO_CLIENT_KEY` (a personal Client API key from an
   account that owns/subusers your servers) to enable `/nothing console`
   and the power-action part of it. Without it, those two subcommands
   reply with a clear "not configured" message instead of crashing.

## 4. Register slash commands

```bash
npm run deploy-commands
```

With `GUILD_ID` set (it already is, from your old bot), commands register
instantly to that one server. Remove `GUILD_ID` for global registration
(works everywhere the bot is added, but can take up to an hour to
propagate).

## 5. Run

```bash
npm start
```

or, for auto-restart on file changes during development:

```bash
npm run dev
```

## Commands

### Pterodactyl (`/nothing ...`)
| Command | Description |
|---|---|
| `/nothing help` | Lists all commands |
| `/nothing link <email>` | Link your Discord account to your Pterodactyl account |
| `/nothing status [user]` | Server stats for yourself, or (staff) another user |
| `/nothing deploy <username> <email> <server_name> <ram_gb>` | ADMIN: create account + deploy a Paper server on the first node (2 or 3) with room |
| `/nothing upgrade <server_id_or_uuid> <new_ram_gb>` | ADMIN: rescale RAM/CPU |
| `/nothing whitelist <user>` / `unwhitelist <user>` | ADMIN: bypass list for the `@everyone`/`@here` auto-quarantine |
| `/nothing console command\|power <server_id> ...` | ADMIN: raw console commands / start-stop-restart-kill |
| `/nothing subuser add\|remove <user> <server_id>` | Grant/revoke console+power access to *your* server |
| `/nothing config set <server_id> <key> <value>` | Edit `server.properties` |
| `/nothing server renew\|suspend\|delete <server_id>` | ADMIN: server lifecycle |
| `/nothing plugin install <server_id> <plugin>` | Install a plugin from Modrinth/SpigotMC |

### Tickets
| Command | Description |
|---|---|
| `/ticket-panel` | Deploy the ticket-creation panel in the current channel |
| `/add <user>` / `/remove <user>` | Manage who can see the current ticket |
| Claim / Close / Reopen / Delete buttons | On every ticket, for staff (or the owner, for Reopen) |

### Moderation
| Command | Description |
|---|---|
| `/attack <user>` | Manually quarantine a user (full lockdown) |
| `/release <user>` | Undo quarantine |
| Profanity filter | Auto-deletes + escalating timeouts → ban on repeat offenses (message-based, no command) |
| Anti-mass-ping | Auto-quarantines anyone who pings `@everyone`/`@here` without being whitelisted |

### Music
`/play`, `/skip`, `/stop`, `/pause`, `/resume`, `/queue`, `/nowplaying`,
`/volume`, `/loop`, `/disconnect` — YouTube search/links and Spotify track
links (resolved to a YouTube search since Spotify audio itself is DRM'd).

## Error handling

Every Pterodactyl API call goes through `pterodactyl.js`'s `safeRequest()`,
which never throws — it returns `{ ok, data }` or `{ ok, error }` with the
panel's actual reported reason. Any other unexpected error is still caught
by a top-level handler in `index.js` so one broken command can't take the
whole bot down or leave an interaction hanging forever.

## Extending

- **New command:** add a file to `src/commands/` exporting `{ data, execute }`, then `npm run deploy-commands`.
- **New node:** just add its ID to `NODE_IDS` in `.env` — no code changes needed.
- **Different game egg:** update `DEFAULT_NEST_ID`/`DEFAULT_EGG_ID` in `.env`, and the `docker_image`/`startup`/`environment` block in `src/handlers/deploy.js`.
