import { Client, GatewayIntentBits, Partials, Events } from "discord.js";
import { GoogleGenerativeAI } from "@google/generative-ai";
import "dotenv/config";
import { SYSTEM_PROMPT } from "./systemPrompt.js";

// ---------- Config ----------
const {
  DISCORD_TOKEN,
  GEMINI_API_KEY,
  GEMINI_MODEL = "gemini-2.0-flash",
} = process.env;

if (!DISCORD_TOKEN || !GEMINI_API_KEY) {
  console.error("Missing DISCORD_TOKEN or GEMINI_API_KEY in .env — see .env.example");
  process.exit(1);
}

const MAX_HISTORY_TURNS = 8; // per-channel, to keep context small & cheap
const MAX_INPUT_CHARS = 6000; // truncate huge pasted logs

// ---------- Gemini setup ----------
const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
const model = genAI.getGenerativeModel({
  model: GEMINI_MODEL,
  systemInstruction: SYSTEM_PROMPT,
});

// channelId -> [{role: "user"|"model", parts: [{text}]}]
const conversations = new Map();

function getHistory(channelId) {
  if (!conversations.has(channelId)) conversations.set(channelId, []);
  return conversations.get(channelId);
}

function pushTurn(channelId, role, text) {
  const history = getHistory(channelId);
  history.push({ role, parts: [{ text }] });
  // Keep only the last N turns (user+model pairs)
  const maxMessages = MAX_HISTORY_TURNS * 2;
  if (history.length > maxMessages) {
    history.splice(0, history.length - maxMessages);
  }
}

function truncate(text, max = MAX_INPUT_CHARS) {
  if (text.length <= max) return text;
  return text.slice(0, max) + "\n\n[...truncated, message was too long...]";
}

async function askGemini(channelId, userText) {
  const history = getHistory(channelId);
  const chat = model.startChat({ history });
  const result = await chat.sendMessage(truncate(userText));
  const responseText = result.response.text();

  pushTurn(channelId, "user", userText);
  pushTurn(channelId, "model", responseText);

  return responseText;
}

// Discord messages are capped at 2000 chars; split long replies safely.
function splitMessage(text, maxLen = 1900) {
  if (text.length <= maxLen) return [text];
  const chunks = [];
  let remaining = text;
  while (remaining.length > maxLen) {
    let cut = remaining.lastIndexOf("\n", maxLen);
    if (cut < maxLen * 0.5) cut = maxLen; // no good newline, hard cut
    chunks.push(remaining.slice(0, cut));
    remaining = remaining.slice(cut);
  }
  if (remaining.length) chunks.push(remaining);
  return chunks;
}

// ---------- Discord client ----------
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel],
});

client.once(Events.ClientReady, (c) => {
  console.log(`Logged in as ${c.user.tag}`);
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  if (interaction.commandName === "resetchat") {
    conversations.delete(interaction.channelId);
    await interaction.reply({ content: "Conversation memory cleared for this channel.", ephemeral: true });
    return;
  }

  if (interaction.commandName === "ask") {
    const question = interaction.options.getString("question", true);
    await interaction.deferReply();
    try {
      const answer = await askGemini(interaction.channelId, question);
      const chunks = splitMessage(answer);
      await interaction.editReply(chunks[0]);
      for (const chunk of chunks.slice(1)) {
        await interaction.followUp(chunk);
      }
    } catch (err) {
      console.error("Gemini error:", err);
      await interaction.editReply(
        "Something went wrong talking to the AI. Try again in a moment."
      );
    }
  }
});

// Responds to every message in every text channel it can see (minus bots/itself).
client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot) return;

  const content = message.content.replace(`<@${client.user.id}>`, "").trim();
  if (!content) return;

  await message.channel.sendTyping();
  try {
    const answer = await askGemini(message.channelId, content);
    const chunks = splitMessage(answer);
    for (const chunk of chunks) {
      await message.reply(chunk);
    }
  } catch (err) {
    console.error("Gemini error:", err);
    await message.reply("Something went wrong talking to the AI. Try again in a moment.");
  }
});

client.login(DISCORD_TOKEN);
