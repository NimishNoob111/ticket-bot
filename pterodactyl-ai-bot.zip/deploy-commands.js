import { REST, Routes, SlashCommandBuilder } from "discord.js";
import "dotenv/config";

const commands = [
  new SlashCommandBuilder()
    .setName("ask")
    .setDescription("Ask the AI about a Pterodactyl or Minecraft server problem")
    .addStringOption((opt) =>
      opt
        .setName("question")
        .setDescription("Describe the problem or paste the error/log")
        .setRequired(true)
    ),
  new SlashCommandBuilder()
    .setName("resetchat")
    .setDescription("Clear this channel's conversation memory with the bot"),
].map((c) => c.toJSON());

const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);

async function main() {
  const clientId = process.env.DISCORD_CLIENT_ID;
  const guildId = process.env.DISCORD_GUILD_ID;

  const route = guildId
    ? Routes.applicationGuildCommands(clientId, guildId)
    : Routes.applicationCommands(clientId);

  console.log(
    `Deploying ${commands.length} command(s) ${guildId ? `to guild ${guildId}` : "globally"}...`
  );
  await rest.put(route, { body: commands });
  console.log("Done. Global commands can take up to 1 hour to show up everywhere.");
}

main().catch((err) => {
  console.error("Failed to deploy commands:", err);
  process.exit(1);
});
