'use strict';

/**
 * Plugin lookup/resolution for /plugin install.
 *
 * Supports two sources, auto-detected from whatever the user types:
 *   - Modrinth  (slug, project ID, or a modrinth.com/plugin/<slug> URL)
 *   - SpigotMC  (a spigotmc.org/resources/....<id>/ URL, a bare numeric
 *                resource ID, or via the unofficial Spiget API's search)
 *
 * If the input doesn't look like a URL or ID, we try Modrinth first
 * (exact slug match, then search), then fall back to Spiget search.
 *
 * Neither API requires a key. Modrinth's API asks that clients send a
 * descriptive User-Agent - see https://docs.modrinth.com/api/#authentication
 */

const axios = require('axios');

const MODRINTH_API = 'https://api.modrinth.com/v2';
const SPIGET_API = 'https://api.spiget.org/v2';

const modrinth = axios.create({
  baseURL: MODRINTH_API,
  timeout: 15_000,
  headers: {
    'User-Agent': 'discord-ptero-bot/1.0 (+plugin-install-command)',
  },
});

const spiget = axios.create({
  baseURL: SPIGET_API,
  timeout: 15_000,
  headers: {
    'User-Agent': 'discord-ptero-bot/1.0 (+plugin-install-command)',
  },
});

// Loaders we'll ask Modrinth about, in priority order, mapped from common
// Pterodactyl egg names. Most Paper-family servers can also run plugins
// built for older ancestor loaders (Paper accepts Spigot/Bukkit plugins).
const LOADER_FALLBACK_CHAIN = {
  purpur: ['purpur', 'paper', 'spigot', 'bukkit'],
  paper: ['paper', 'spigot', 'bukkit'],
  folia: ['folia', 'paper', 'spigot', 'bukkit'],
  spigot: ['spigot', 'bukkit'],
  bukkit: ['bukkit'],
  fabric: ['fabric'],
  forge: ['forge'],
  quilt: ['quilt', 'fabric'],
  velocity: ['velocity'],
  bungeecord: ['bungeecord'],
};

/**
 * Guesses the loader family from a Pterodactyl egg name string, e.g.
 * "Paper" -> "paper", "Purpur (PufferPanel Fork)" -> "purpur".
 * Defaults to the "paper" fallback chain since it's the most common/
 * permissive modern egg, but callers should treat this as a best guess.
 */
function guessLoaderChain(eggName) {
  const name = (eggName || '').toLowerCase();
  for (const key of Object.keys(LOADER_FALLBACK_CHAIN)) {
    if (name.includes(key)) return LOADER_FALLBACK_CHAIN[key];
  }
  return LOADER_FALLBACK_CHAIN.paper;
}

/**
 * Pulls a Minecraft version string out of a server's egg environment
 * variables. Different eggs name this differently, so we check the
 * common candidates in order of likelihood.
 */
function extractMinecraftVersion(environment) {
  if (!environment || typeof environment !== 'object') return null;

  const candidates = [
    'MINECRAFT_VERSION',
    'MC_VERSION',
    'SERVER_VERSION',
    'VERSION',
    'GAME_VERSION',
  ];

  for (const key of candidates) {
    const value = environment[key];
    if (value && typeof value === 'string' && value.toLowerCase() !== 'latest') {
      return value.trim();
    }
  }

  return null;
}

// ---------------------------------------------------------------------------
// Input parsing - figure out which source + identifier the user gave us
// ---------------------------------------------------------------------------

function parsePluginInput(raw) {
  const input = raw.trim();

  const modrinthUrlMatch = input.match(
    /modrinth\.com\/(?:plugin|mod|project)\/([a-zA-Z0-9._-]+)/i
  );
  if (modrinthUrlMatch) {
    return { source: 'modrinth', identifier: modrinthUrlMatch[1] };
  }

  const spigotUrlMatch = input.match(/spigotmc\.org\/resources\/[^/]*\.(\d+)/i);
  if (spigotUrlMatch) {
    return { source: 'spiget', identifier: spigotUrlMatch[1] };
  }

  // Bare number -> almost certainly a SpigotMC resource ID (Modrinth
  // project IDs are 8-character base62 strings, never pure digits).
  if (/^\d+$/.test(input)) {
    return { source: 'spiget', identifier: input };
  }

  // Otherwise: treat as a Modrinth slug/name first, with Spiget as a
  // fallback handled by the caller if Modrinth comes up empty.
  return { source: 'auto', identifier: input };
}

// ---------------------------------------------------------------------------
// Modrinth
// ---------------------------------------------------------------------------

/** Resolves a slug or ID to a Modrinth project, or null if not found. */
async function fetchModrinthProject(idOrSlug) {
  try {
    const { data } = await modrinth.get(`/project/${encodeURIComponent(idOrSlug)}`);
    return data;
  } catch (err) {
    if (err.response?.status === 404) return null;
    throw err;
  }
}

/** Searches Modrinth for plugins matching a free-text query. */
async function searchModrinthProject(query) {
  const { data } = await modrinth.get('/search', {
    params: {
      query,
      limit: 1,
      facets: JSON.stringify([['project_type:plugin']]),
    },
  });
  const hit = data?.hits?.[0];
  if (!hit) return null;
  return fetchModrinthProject(hit.project_id);
}

/**
 * Fetches versions for a project, trying loaders in the fallback chain and
 * narrowing by game_versions when possible. Returns the best match found,
 * or a { version, exactMatch:false } fallback using the newest version of
 * the project if nothing matched the requested Minecraft version.
 */
async function pickModrinthVersion(projectId, mcVersion, loaderChain) {
  for (const loader of loaderChain) {
    const params = { loaders: JSON.stringify([loader]) };
    if (mcVersion) params.game_versions = JSON.stringify([mcVersion]);

    const { data: versions } = await modrinth.get(`/project/${projectId}/version`, { params });
    if (versions && versions.length > 0) {
      // Modrinth returns newest-first already, but sort defensively.
      versions.sort((a, b) => new Date(b.date_published) - new Date(a.date_published));
      return { version: versions[0], exactMatch: Boolean(mcVersion), loader };
    }
  }

  // Nothing matched the exact MC version - fall back to the newest version
  // for any loader in the chain, ignoring game_versions entirely.
  for (const loader of loaderChain) {
    const { data: versions } = await modrinth.get(`/project/${projectId}/version`, {
      params: { loaders: JSON.stringify([loader]) },
    });
    if (versions && versions.length > 0) {
      versions.sort((a, b) => new Date(b.date_published) - new Date(a.date_published));
      return { version: versions[0], exactMatch: false, loader };
    }
  }

  return null;
}

async function resolveModrinth(identifier, mcVersion, loaderChain) {
  let project = await fetchModrinthProject(identifier);
  if (!project) project = await searchModrinthProject(identifier);
  if (!project) {
    return { ok: false, error: `No Modrinth plugin found matching "${identifier}".` };
  }

  const picked = await pickModrinthVersion(project.id, mcVersion, loaderChain);
  if (!picked) {
    return {
      ok: false,
      error: `Found **${project.title}** on Modrinth, but it has no downloadable files for the ${loaderChain[0]} loader family.`,
    };
  }

  const file = picked.version.files.find((f) => f.primary) || picked.version.files[0];
  if (!file) {
    return { ok: false, error: `Found a matching version of **${project.title}**, but it has no files attached.` };
  }

  return {
    ok: true,
    data: {
      source: 'Modrinth',
      name: project.title,
      versionNumber: picked.version.version_number,
      loader: picked.loader,
      exactMatch: picked.exactMatch,
      fileName: file.filename,
      downloadUrl: file.url,
      pageUrl: `https://modrinth.com/plugin/${project.slug}`,
    },
  };
}

// ---------------------------------------------------------------------------
// SpigotMC (via the unofficial Spiget API)
// ---------------------------------------------------------------------------

async function fetchSpigetResource(id) {
  try {
    const { data } = await spiget.get(`/resources/${id}`);
    return data;
  } catch (err) {
    if (err.response?.status === 404) return null;
    throw err;
  }
}

async function searchSpigetResource(query) {
  try {
    const { data } = await spiget.get(`/search/resources/${encodeURIComponent(query)}`, {
      params: { field: 'name', size: 1 },
    });
    const hit = data?.[0];
    if (!hit) return null;
    return fetchSpigetResource(hit.id);
  } catch (err) {
    if (err.response?.status === 404) return null;
    throw err;
  }
}

async function resolveSpiget(identifier, mcVersion) {
  let resource = /^\d+$/.test(identifier) ? await fetchSpigetResource(identifier) : null;
  if (!resource) resource = await searchSpigetResource(identifier);
  if (!resource) {
    return { ok: false, error: `No SpigotMC resource found matching "${identifier}".` };
  }

  // Spiget's free API only exposes the resource's current/latest file -
  // there's no per-Minecraft-version archive of downloads like Modrinth
  // has. The best we can do is check the resource's declared "tested
  // versions" list and warn if the target version isn't in it.
  const testedVersions = Array.isArray(resource.testedVersions) ? resource.testedVersions : [];
  const exactMatch = mcVersion
    ? testedVersions.some((v) => v === mcVersion || mcVersion.startsWith(v) || v.startsWith(mcVersion))
    : testedVersions.length === 0;

  return {
    ok: true,
    data: {
      source: 'SpigotMC',
      name: resource.name,
      versionNumber: resource.version?.name || 'latest',
      loader: 'spigot',
      exactMatch,
      testedVersions,
      fileName: `${resource.id}-${(resource.name || 'plugin').replace(/[^a-z0-9._-]/gi, '_')}.jar`,
      downloadUrl: `${SPIGET_API}/resources/${resource.id}/download`,
      pageUrl: `https://www.spigotmc.org/resources/${resource.id}`,
    },
  };
}

// ---------------------------------------------------------------------------
// Public entry point
// ---------------------------------------------------------------------------

/**
 * Resolves user input (slug/URL/ID/search term) to a concrete downloadable
 * plugin file, preferring Modrinth and falling back to SpigotMC.
 *
 * Returns { ok: true, data: { source, name, versionNumber, loader,
 * exactMatch, fileName, downloadUrl, pageUrl, testedVersions? } }
 * or { ok: false, error }.
 */
async function resolvePlugin(rawInput, { mcVersion, eggName }) {
  const { source, identifier } = parsePluginInput(rawInput);
  const loaderChain = guessLoaderChain(eggName);

  try {
    if (source === 'modrinth') {
      return await resolveModrinth(identifier, mcVersion, loaderChain);
    }

    if (source === 'spiget') {
      return await resolveSpiget(identifier, mcVersion);
    }

    // auto: try Modrinth first, then Spiget.
    const modrinthResult = await resolveModrinth(identifier, mcVersion, loaderChain);
    if (modrinthResult.ok) return modrinthResult;

    const spigetResult = await resolveSpiget(identifier, mcVersion);
    if (spigetResult.ok) return spigetResult;

    return {
      ok: false,
      error: `Couldn't find "${rawInput}" on Modrinth or SpigotMC.\n- Modrinth: ${modrinthResult.error}\n- SpigotMC: ${spigetResult.error}`,
    };
  } catch (err) {
    return {
      ok: false,
      error: `Error contacting plugin repository: ${err.message}`,
    };
  }
}

/** Downloads a plugin file into a Buffer. */
async function downloadPluginFile(url) {
  const response = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: 60_000,
    maxContentLength: 200 * 1024 * 1024, // 200MB safety cap
    maxBodyLength: 200 * 1024 * 1024,
    headers: { 'User-Agent': 'discord-ptero-bot/1.0 (+plugin-install-command)' },
  });
  return Buffer.from(response.data);
}

module.exports = {
  extractMinecraftVersion,
  guessLoaderChain,
  resolvePlugin,
  downloadPluginFile,
};
