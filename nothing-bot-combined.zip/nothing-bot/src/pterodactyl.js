'use strict';

const axios = require('axios');
const FormData = require('form-data');

const PTERO_URL = (process.env.PTERO_URL || '').replace(/\/+$/, '');
const PTERO_APP_KEY = process.env.PTERO_APP_KEY;
const PTERO_CLIENT_KEY = process.env.PTERO_CLIENT_KEY;

if (!PTERO_URL || !PTERO_APP_KEY) {
  throw new Error(
    '[Pterodactyl] Missing PTERO_URL or PTERO_APP_KEY in your .env file.'
  );
}

const api = axios.create({
  baseURL: `${PTERO_URL}/api/application`,
  timeout: 15_000,
  headers: {
    Authorization: `Bearer ${PTERO_APP_KEY}`,
    Accept: 'application/json',
    'Content-Type': 'application/json',
  },
});

// Separate client for the Client API (console commands, power actions).
// Only created if PTERO_CLIENT_KEY is set - /console commands will report
// a clear error if it's missing rather than crashing.
const clientApi = PTERO_CLIENT_KEY
  ? axios.create({
      baseURL: `${PTERO_URL}/api/client`,
      timeout: 15_000,
      headers: {
        Authorization: `Bearer ${PTERO_CLIENT_KEY}`,
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
    })
  : null;

// ---------------------------------------------------------------------------
// Debug logging (console only - never leaks the API key)
// ---------------------------------------------------------------------------
function attachLogging(instance, label) {
  instance.interceptors.request.use((config) => {
    console.log(
      `[Pterodactyl:${label}] -> ${config.method?.toUpperCase()} ${config.baseURL}${config.url}` +
        (config.params ? ` params=${JSON.stringify(config.params)}` : '')
    );
    if (config.data) {
      console.log(`[Pterodactyl:${label}]    payload=${JSON.stringify(config.data)}`);
    }
    return config;
  });

  instance.interceptors.response.use(
    (response) => {
      console.log(`[Pterodactyl:${label}] <- ${response.status} ${response.config.url}`);
      return response;
    },
    (error) => {
      console.log(
        `[Pterodactyl:${label}] <- ERROR ${error.response?.status ?? 'NETWORK'} ${
          error.config?.url ?? ''
        }`
      );
      return Promise.reject(error);
    }
  );
}

attachLogging(api, 'app');
if (clientApi) attachLogging(clientApi, 'client');

/**
 * Pterodactyl returns errors as:
 * { errors: [ { code, status, detail }, ... ] }
 * This normalizes any axios error into a clean, human-readable string.
 */
function parsePteroError(error) {
  const apiErrors = error?.response?.data?.errors;

  if (Array.isArray(apiErrors) && apiErrors.length > 0) {
    return apiErrors
      .map((e) => e.detail || e.code || 'Unknown Pterodactyl error')
      .join(' | ');
  }

  if (error?.response?.status) {
    return `Pterodactyl returned HTTP ${error.response.status} with no detail (check panel logs).`;
  }

  if (error?.code === 'ECONNABORTED') {
    return 'Request to Pterodactyl timed out. Is the panel reachable?';
  }

  if (error?.request) {
    return 'Could not reach the Pterodactyl panel. Check PTERO_URL and network connectivity.';
  }

  return error?.message || 'An unknown error occurred while contacting Pterodactyl.';
}

/**
 * Small helper class so callers get { ok, data } or { ok, error } instead of
 * throwing everywhere. Keeps command files clean of try/catch boilerplate
 * for the *API layer* (Discord-side try/catch is still applied in commands).
 */
async function safeRequest(promise) {
  try {
    const response = await promise;
    return { ok: true, data: response.data, status: response.status };
  } catch (error) {
    return { ok: false, error: parsePteroError(error), raw: error };
  }
}

// ---------------------------------------------------------------------------
// Users
// ---------------------------------------------------------------------------

/** GET /users?filter[email]=<email> */
function getUserByEmail(email) {
  return safeRequest(
    api.get('/users', { params: { 'filter[email]': email } })
  );
}

/** GET /users/{id} */
function getUserById(id) {
  return safeRequest(api.get(`/users/${id}`));
}

/** POST /users - creates a Pterodactyl account */
function createUser({ email, username, firstName, lastName, password }) {
  return safeRequest(
    api.post('/users', {
      email,
      username,
      first_name: firstName || username,
      last_name: lastName || 'Server-Owner',
      password,
    })
  );
}

// ---------------------------------------------------------------------------
// Servers
// ---------------------------------------------------------------------------

/** GET /servers?filter[...]=... with pagination handled, then locally filter by owner id */
async function getServersByUserId(pterodactylUserId) {
  const result = await safeRequest(
    api.get('/servers', {
      params: {
        per_page: 100,
        include: 'allocations',
      },
    })
  );

  if (!result.ok) return result;

  const allServers = result.data?.data ?? [];
  const owned = allServers.filter(
    (s) => s.attributes.user === Number(pterodactylUserId)
  );

  return { ok: true, data: owned };
}

/** GET /servers/{id} */
function getServer(serverId) {
  return safeRequest(
    api.get(`/servers/${serverId}`, { params: { include: 'allocations' } })
  );
}

/**
 * GET /servers/{id}?include=egg,variables - used by /plugin to figure out
 * the egg name (Paper/Purpur/Spigot/Fabric/...) and startup environment
 * variables (which usually contain something like MINECRAFT_VERSION).
 */
function getServerWithEggInfo(serverId) {
  return safeRequest(
    api.get(`/servers/${serverId}`, { params: { include: 'egg,variables' } })
  );
}

/** POST /servers */
function createServer(payload) {
  return safeRequest(api.post('/servers', payload));
}

/** PATCH /servers/{id}/build */
function updateServerBuild(serverId, buildPayload) {
  return safeRequest(api.patch(`/servers/${serverId}/build`, buildPayload));
}

/** POST /servers/{id}/suspend */
function suspendServer(serverId) {
  return safeRequest(api.post(`/servers/${serverId}/suspend`));
}

/** POST /servers/{id}/unsuspend - a.k.a. "renew" access after suspension */
function unsuspendServer(serverId) {
  return safeRequest(api.post(`/servers/${serverId}/unsuspend`));
}

/** DELETE /servers/{id} - permanent, irreversible */
function deleteServer(serverId) {
  return safeRequest(api.delete(`/servers/${serverId}`));
}

// ---------------------------------------------------------------------------
// Nodes / Allocations
// ---------------------------------------------------------------------------

/** GET /nodes/{id}/allocations (paginated) */
async function getFreeAllocation(nodeId) {
  const result = await safeRequest(
    api.get(`/nodes/${nodeId}/allocations`, { params: { per_page: 200 } })
  );

  if (!result.ok) return result;

  const allocations = result.data?.data ?? [];
  const free = allocations.find((a) => a.attributes.assigned === false);

  if (!free) {
    return {
      ok: false,
      error: `Node ${nodeId} is out of free allocations. Add more ports or pick another node.`,
    };
  }

  return { ok: true, data: { ...free.attributes, nodeId: Number(nodeId) } };
}

/**
 * Tries a list of node IDs in order and returns the first free allocation
 * found. This is what powers deploy/register-and-deploy now that a panel
 * can have several usable nodes (configured via NODE_IDS in .env, e.g.
 * "2,3") instead of a single hardcoded node.
 *
 * Returns { ok: true, data: { ...allocationAttrs, nodeId } } for the first
 * node with room, or { ok: false, error } listing every node that was
 * checked and why each one failed, if none had a free allocation.
 */
async function getFreeAllocationFromNodes(nodeIds) {
  const ids = (Array.isArray(nodeIds) ? nodeIds : [nodeIds])
    .map((n) => Number(n))
    .filter((n) => Number.isInteger(n) && n > 0);

  if (ids.length === 0) {
    return {
      ok: false,
      error:
        'No valid node IDs configured. Set NODE_IDS in your .env (e.g. NODE_IDS=2,3).',
    };
  }

  const failures = [];

  for (const nodeId of ids) {
    const result = await getFreeAllocation(nodeId);
    if (result.ok) return result;
    failures.push(`Node ${nodeId}: ${result.error}`);
  }

  return {
    ok: false,
    error: `No free allocation found on any configured node.\n${failures.join('\n')}`,
  };
}

// ---------------------------------------------------------------------------
// Client API (console commands, power actions)
// Requires PTERO_CLIENT_KEY - a Client API key generated from a normal
// account's Account Settings, not the Admin panel. That account must own or
// be a subuser on the target server(s), since the Application API has no
// console/power endpoints.
// ---------------------------------------------------------------------------

function ensureClientApi() {
  if (!clientApi) {
    return {
      ok: false,
      error:
        'PTERO_CLIENT_KEY is not set in .env. Console/power actions require a Client API key (Account Settings -> API Credentials), not the Application key.',
    };
  }
  return null;
}

/** POST /client/servers/{server}/command - server identifier (short UUID), not numeric ID */
async function sendConsoleCommand(serverIdentifier, command) {
  const guard = ensureClientApi();
  if (guard) return guard;

  return safeRequest(
    clientApi.post(`/servers/${serverIdentifier}/command`, { command })
  );
}

/** POST /client/servers/{server}/power - signal: start | stop | restart | kill */
async function setPowerState(serverIdentifier, signal) {
  const guard = ensureClientApi();
  if (guard) return guard;

  return safeRequest(
    clientApi.post(`/servers/${serverIdentifier}/power`, { signal })
  );
}

/**
 * Finds a server by its short identifier (e.g. "s1") or full UUID by
 * scanning the Application API's server list. Needed because /subuser and
 * /config only know the identifier, but we need Application-API-level data
 * (like the owner's numeric user id) to verify ownership.
 */
async function findServerByIdentifier(identifier) {
  const result = await safeRequest(api.get('/servers', { params: { per_page: 100 } }));
  if (!result.ok) return result;

  const servers = result.data?.data ?? [];
  const match = servers.find(
    (s) =>
      s.attributes.identifier === identifier ||
      s.attributes.identifier.startsWith(identifier)
  );

  if (!match) {
    return { ok: false, error: `No server found matching identifier "${identifier}".` };
  }

  return { ok: true, data: match };
}

// ---------------------------------------------------------------------------
// Subusers (Client API) - lets a server owner share console/power access
// ---------------------------------------------------------------------------

/** GET /client/servers/{server}/users */
async function listSubusers(serverIdentifier) {
  const guard = ensureClientApi();
  if (guard) return guard;

  return safeRequest(clientApi.get(`/servers/${serverIdentifier}/users`));
}

/** POST /client/servers/{server}/users */
async function createSubuser(serverIdentifier, email, permissions) {
  const guard = ensureClientApi();
  if (guard) return guard;

  return safeRequest(
    clientApi.post(`/servers/${serverIdentifier}/users`, { email, permissions })
  );
}

/** DELETE /client/servers/{server}/users/{subuserUuid} */
async function deleteSubuser(serverIdentifier, subuserUuid) {
  const guard = ensureClientApi();
  if (guard) return guard;

  return safeRequest(
    clientApi.delete(`/servers/${serverIdentifier}/users/${subuserUuid}`)
  );
}

// ---------------------------------------------------------------------------
// Files (Client API) - used by /config set to read/write server.properties
// ---------------------------------------------------------------------------

/** GET /client/servers/{server}/files/contents?file=... - returns raw text */
async function readFile(serverIdentifier, filePath) {
  const guard = ensureClientApi();
  if (guard) return guard;

  return safeRequest(
    clientApi.get(`/servers/${serverIdentifier}/files/contents`, {
      params: { file: filePath },
      headers: { Accept: 'text/plain' },
      responseType: 'text',
    })
  );
}

/** POST /client/servers/{server}/files/write?file=... - raw text body */
async function writeFile(serverIdentifier, filePath, content) {
  const guard = ensureClientApi();
  if (guard) return guard;

  return safeRequest(
    clientApi.post(`/servers/${serverIdentifier}/files/write`, content, {
      params: { file: filePath },
      headers: { 'Content-Type': 'text/plain' },
    })
  );
}

/**
 * POST /client/servers/{server}/files/write?file=... - raw binary body.
 * Same endpoint as writeFile, but sends a Buffer with an octet-stream
 * Content-Type instead of text/plain, and disables axios's request/response
 * JSON transforms so the buffer is streamed as-is. Used by /plugin install
 * to upload downloaded .jar files.
 */
/**
 * Large binary files (like plugin jars) must NOT go through /files/write -
 * that endpoint is meant for small text edits and sits behind a low
 * reverse-proxy body-size cap (hence "HTTP 413, no detail" on anything
 * more than a few hundred KB). Uploads instead go through Pterodactyl's
 * dedicated upload flow: request a one-time signed URL, then multipart-POST
 * the file to it.
 */

/** GET /client/servers/{server}/files/upload - returns a one-time signed upload URL */
async function getUploadUrl(serverIdentifier) {
  const guard = ensureClientApi();
  if (guard) return guard;

  return safeRequest(clientApi.get(`/servers/${serverIdentifier}/files/upload`));
}

/**
 * POSTs a binary buffer to a signed upload URL (from getUploadUrl) as
 * multipart/form-data, landing it in the given directory on the server.
 * This is a plain axios call (not through `clientApi`) because the signed
 * URL is already a complete, pre-authorized URL - it doesn't need or want
 * our Bearer token attached.
 */
async function uploadFile(uploadUrl, directory, filename, buffer) {
  try {
    const form = new FormData();
    form.append('files', buffer, { filename });

    const response = await axios.post(uploadUrl, form, {
      headers: form.getHeaders(),
      params: { directory },
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
      timeout: 60_000,
    });

    return { ok: true, data: response.data, status: response.status };
  } catch (error) {
    return { ok: false, error: parsePteroError(error) };
  }
}

/** GET /client/servers/{server}/files/list?directory=... */
async function listFiles(serverIdentifier, directory) {
  const guard = ensureClientApi();
  if (guard) return guard;

  return safeRequest(
    clientApi.get(`/servers/${serverIdentifier}/files/list`, {
      params: { directory },
    })
  );
}

module.exports = {
  api,
  parsePteroError,
  getUserByEmail,
  getUserById,
  createUser,
  getServersByUserId,
  getServer,
  getServerWithEggInfo,
  createServer,
  updateServerBuild,
  suspendServer,
  unsuspendServer,
  deleteServer,
  getFreeAllocation,
  getFreeAllocationFromNodes,
  sendConsoleCommand,
  setPowerState,
  findServerByIdentifier,
  listSubusers,
  createSubuser,
  deleteSubuser,
  readFile,
  writeFile,
  getUploadUrl,
  uploadFile,
  listFiles,
};
