'use strict';

const { SlashCommandBuilder } = require('discord.js');
const music = require('../music');
const { checkVoiceState } = require('../musicGuards');

module.exports = {
  data: new SlashCommandBuilder().setName('stop').setDescription('Stop playback, clear the queue, and leave the voice channel'),

  async execute(interaction) {
    const denial = checkVoiceState(interaction, 'stop');
    if (denial) return interaction.reply(denial);

    const queue = music.getQueue(interaction.guild.id);
    if (!queue) return interaction.reply({ content: '❌ Nothing is playing right now.', ephemeral: true });

    music.stop(interaction.guild.id);
    return interaction.reply({ content: '⏹️ Stopped playback and cleared the queue.' });
  },
};
