// ================= MUSIC SYSTEM =================
// Self-contained per-guild queue + voice-connection manager.
// Everything lives in memory (queues don't need to survive a restart).
//
// Backend: yt-dlp (spawned as a child process), not play-dl. play-dl hasn't had
// a real release in years and reliably hits YouTube's "Sign in to confirm you're
// not a bot" wall in 2026. yt-dlp is actively patched against YouTube's changes
// (often within days), so it's the more durable choice for a self-hosted bot.
//
// Requires the `yt-dlp` binary to be installed on the host and on PATH (or set
// YTDLP_PATH in .env to an explicit path). Install it with:
//   pip install -U yt-dlp        (or: pip3 install -U yt-dlp)
// Keep it updated periodically — `pip install -U yt-dlp` — since that update is
// what actually fixes most YouTube bot-detection breakage, more than cookies do.

const { spawn } = require('child_process');
const https = require('https');
const ffmpegPath = require('ffmpeg-static');
const {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  AudioPlayerStatus,
  VoiceConnectionStatus,
  entersState,
  NoSubscriberBehavior,
  StreamType,
} = require('@discordjs/voice');
const { EmbedBuilder } = require('discord.js');

const YTDLP_PATH = process.env.YTDLP_PATH || 'yt-dlp';
// Optional: path to a Netscape-format cookies.txt file (the same format the
// "Get cookies.txt LOCALLY" browser extension exports — no conversion needed).
const YOUTUBE_COOKIES_FILE = process.env.YOUTUBE_COOKIES_FILE || null;

function ytDlpBaseArgs() {
  const args = ['--no-warnings', '--no-playlist'];
  if (YOUTUBE_COOKIES_FILE) args.push('--cookies', YOUTUBE_COOKIES_FILE);
  return args;
}

/** Runs yt-dlp and captures stdout as text. Rejects with stderr on non-zero exit. */
function runYtDlp(args) {
  return new Promise((resolve, reject) => {
    const proc = spawn(YTDLP_PATH, args);
    let stdout = '';
    let stderr = '';
    proc.stdout.on('data', (d) => { stdout += d; });
    proc.stderr.on('data', (d) => { stderr += d; });
    proc.on('error', (err) => {
      if (err.code === 'ENOENT') {
        reject(new Error('yt-dlp isn\u2019t installed or isn\u2019t on PATH. Install it with `pip install -U yt-dlp`, or set YTDLP_PATH in .env.'));
      } else {
        reject(err);
      }
    });
    proc.on('close', (code) => {
      if (code === 0) resolve(stdout);
      else reject(new Error(stderr.trim().split('\n').pop() || `yt-dlp exited with code ${code}`));
    });
  });
}

/**
 * @typedef {Object} Song
 * @property {string} title
 * @property {string} url
 * @property {number} durationSec
 * @property {string} thumbnail
 * @property {string} requestedBy
 */

/**
 * @typedef {Object} GuildQueue
 * @property {import('@discordjs/voice').VoiceConnection} connection
 * @property {import('@discordjs/voice').AudioPlayer} player
 * @property {Song[]} songs
 * @property {string} textChannelId
 * @property {string} voiceChannelId
 * @property {'off'|'song'|'queue'} loop
 * @property {number} volume  // 0 - 200 (%)
 * @property {boolean} destroyed
 */

/** @type {Map<string, GuildQueue>} */
const queues = new Map();

function formatDuration(totalSeconds) {
  if (!totalSeconds || totalSeconds <= 0) return 'LIVE';
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = Math.floor(totalSeconds % 60);
  const mm = h > 0 ? String(m).padStart(2, '0') : String(m);
  const ss = String(s).padStart(2, '0');
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}

function getQueue(guildId) {
  return queues.get(guildId) || null;
}

const YOUTUBE_URL_RE = /^https?:\/\/(www\.|music\.|m\.)?(youtube\.com\/watch\?v=|youtu\.be\/)/i;
const SPOTIFY_TRACK_RE = /^https?:\/\/open\.spotify\.com\/(intl-\w+\/)?track\//i;
const SPOTIFY_OTHER_RE = /^https?:\/\/open\.spotify\.com\/(intl-\w+\/)?(album|playlist|artist)\//i;

function fetchText(url, redirectsLeft = 3) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && redirectsLeft > 0) {
        res.resume();
        return resolve(fetchText(res.headers.location, redirectsLeft - 1));
      }
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error(`got HTTP ${res.statusCode}`));
      }
      let data = '';
      res.on('data', (c) => { data += c; });
      res.on('end', () => resolve(data));
    }).on('error', reject);
  });
}

/**
 * Spotify tracks are DRM-protected and can't be streamed directly — no bot can
 * legitimately play the actual Spotify audio. Instead, this reads the track's
 * title/artist off the public Spotify page and returns a search string, so the
 * caller can find and play the same song from YouTube.
 */
async function resolveSpotifyTrackAsSearch(url) {
  let html;
  try {
    html = await fetchText(url);
  } catch (err) {
    throw new Error(`Couldn't read that Spotify link (${err.message}).`);
  }
  const match = html.match(/<title>(.*?)<\/title>/i);
  if (!match) throw new Error('Couldn\u2019t read that Spotify link \u2014 try pasting the song name instead.');
  // Spotify formats this as "Song Name - song by Artist Name | Spotify"
  return match[1]
    .replace(/\s*\|\s*Spotify\s*$/i, '')
    .replace(/\s*-\s*song by\s*/i, ' - ')
    .trim();
}

/**
 * Resolves a user's search text or URL into a Song via `yt-dlp --dump-single-json`.
 * Throws a human-readable Error on failure.
 */
async function resolveSong(query, requestedBy) {
  if (SPOTIFY_OTHER_RE.test(query)) {
    throw new Error('Spotify albums/playlists aren\u2019t supported yet \u2014 paste a single track link instead.');
  }

  let searchTarget = query;
  let fromSpotify = false;
  if (SPOTIFY_TRACK_RE.test(query)) {
    searchTarget = await resolveSpotifyTrackAsSearch(query);
    fromSpotify = true;
  }

  const isUrl = !fromSpotify && YOUTUBE_URL_RE.test(searchTarget);
  const target = isUrl ? searchTarget : `ytsearch1:${searchTarget}`;

  let raw;
  try {
    raw = await runYtDlp([...ytDlpBaseArgs(), '--dump-single-json', target]);
  } catch (err) {
    throw new Error(err.message.includes('isn\u2019t on PATH') ? err.message : `Couldn't find that: ${err.message}`);
  }

  let info;
  try {
    info = JSON.parse(raw);
  } catch {
    throw new Error('Got an unexpected response from yt-dlp.');
  }

  // ytsearch wraps results in an "entries" array; direct URLs don't.
  const d = info.entries ? info.entries[0] : info;
  if (!d) throw new Error(`No results found for **${searchTarget}**.`);

  return {
    title: fromSpotify ? `${d.title} (via YouTube)` : d.title,
    url: d.webpage_url || d.url,
    durationSec: d.duration || 0,
    thumbnail: d.thumbnail || null,
    requestedBy,
  };
}

/**
 * Creates (or returns the existing) queue for a guild and connects to the voice channel.
 */
function ensureQueue(voiceChannel, textChannelId) {
  const guildId = voiceChannel.guild.id;
  let queue = queues.get(guildId);
  if (queue && !queue.destroyed) return queue;

  const connection = joinVoiceChannel({
    channelId: voiceChannel.id,
    guildId,
    adapterCreator: voiceChannel.guild.voiceAdapterCreator,
    selfDeaf: true,
  });

  const player = createAudioPlayer({
    behaviors: { noSubscriber: NoSubscriberBehavior.Pause },
  });
  connection.subscribe(player);

  queue = {
    connection,
    player,
    songs: [],
    textChannelId,
    voiceChannelId: voiceChannel.id,
    loop: 'off',
    volume: 100,
    destroyed: false,
  };
  queues.set(guildId, queue);

  connection.on(VoiceConnectionStatus.Disconnected, async () => {
    try {
      await Promise.race([
        entersState(connection, VoiceConnectionStatus.Signalling, 5000),
        entersState(connection, VoiceConnectionStatus.Connecting, 5000),
      ]);
    } catch {
      destroyQueue(guildId);
    }
  });

  player.on(AudioPlayerStatus.Idle, () => {
    void advance(guildId);
  });

  player.on('error', (err) => {
    console.error(`Music player error in guild ${guildId}:`, err.message);
    void advance(guildId);
  });

  return queue;
}

function destroyQueue(guildId) {
  const queue = queues.get(guildId);
  if (!queue) return;
  queue.destroyed = true;
  clearTimeout(queue.idleTimer);
  try { queue.ytdlpProc?.kill('SIGKILL'); } catch { /* ignore */ }
  try { queue.ffmpegProc?.kill('SIGKILL'); } catch { /* ignore */ }
  try { queue.player.stop(true); } catch { /* ignore */ }
  try { queue.connection.destroy(); } catch { /* ignore */ }
  queues.delete(guildId);
}

let notifyChannel = null;
/** Allows index.js to inject a "send now-playing embed" callback without circular imports. */
function setNowPlayingNotifier(fn) {
  notifyChannel = fn;
}

async function advance(guildId) {
  const queue = queues.get(guildId);
  if (!queue || queue.destroyed) return;

  if (queue.loop === 'song' && queue.songs.length > 0) {
    // replay the same song, do nothing to the array
  } else if (queue.loop === 'queue' && queue.songs.length > 0) {
    queue.songs.push(queue.songs.shift());
  } else {
    queue.songs.shift();
  }

  const next = queue.songs[0];
  if (!next) {
    // Nothing left to play — give the user a few minutes to queue something else
    // before the bot leaves the voice channel on its own.
    clearTimeout(queue.idleTimer);
    queue.idleTimer = setTimeout(() => destroyQueue(guildId), 5 * 60 * 1000);
    return;
  }

  await playSong(guildId, next);
}

/**
 * Streams a song by piping `yt-dlp` (best audio -> stdout) into `ffmpeg`
 * (transcoding to an Ogg/Opus container), and returns ffmpeg's stdout —
 * which @discordjs/voice can play directly as StreamType.OggOpus without
 * needing a separate JS-side opus encoder.
 */
function spawnAudioStream(queue, song) {
  const ytdlpArgs = [...ytDlpBaseArgs(), '-f', 'bestaudio/best', '-o', '-', song.url];
  const ytdlpProc = spawn(YTDLP_PATH, ytdlpArgs, { stdio: ['ignore', 'pipe', 'pipe'] });

  const ffmpegProc = spawn(ffmpegPath, [
    '-i', 'pipe:0',
    '-vn',
    '-c:a', 'libopus',
    '-b:a', '128k',
    '-f', 'ogg',
    'pipe:1',
  ], { stdio: ['pipe', 'pipe', 'pipe'] });

  ytdlpProc.stdout.pipe(ffmpegProc.stdin);

  let ytdlpStderr = '';
  ytdlpProc.stderr.on('data', (d) => { ytdlpStderr += d; });
  ytdlpProc.on('error', () => {}); // surfaced via close/exit below
  ytdlpProc.stdout.on('error', () => {}); // EPIPE when ffmpeg exits first — harmless

  let ffmpegStderr = '';
  ffmpegProc.stderr.on('data', (d) => { ffmpegStderr += d; });
  ffmpegProc.stdin.on('error', () => {}); // EPIPE when yt-dlp exits/fails — harmless

  queue.ytdlpProc = ytdlpProc;
  queue.ffmpegProc = ffmpegProc;

  ffmpegProc.on('close', (code) => {
    if (code !== 0 && code !== null) {
      console.error(`ffmpeg exited ${code} for "${song.title}". yt-dlp: ${ytdlpStderr.slice(-500)} | ffmpeg: ${ffmpegStderr.slice(-500)}`);
    }
  });

  return ffmpegProc.stdout;
}

async function playSong(guildId, song, announce = true) {
  const queue = queues.get(guildId);
  if (!queue || queue.destroyed) return;
  clearTimeout(queue.idleTimer);

  try {
    const stream = spawnAudioStream(queue, song);
    const resource = createAudioResource(stream, {
      inputType: StreamType.OggOpus,
      inlineVolume: true,
    });
    resource.volume?.setVolume(queue.volume / 100);
    queue.currentResource = resource;
    queue.player.play(resource);
    if (announce && notifyChannel) notifyChannel(guildId, song);
  } catch (err) {
    console.error(`Failed to stream "${song.title}":`, err.message);
    if (notifyChannel) notifyChannel(guildId, song, err);
    // Skip the broken song and try the next one
    queue.songs.shift();
    const next = queue.songs[0];
    if (next) await playSong(guildId, next);
  }
}

/** Adds a song to the queue and starts playback if idle. */
async function enqueue(voiceChannel, textChannelId, song) {
  const queue = ensureQueue(voiceChannel, textChannelId);
  queue.songs.push(song);
  if (queue.songs.length === 1) {
    // announce=false: the caller (the /play command) already shows a
    // "Now Playing" embed in its own reply, so the auto-notifier would
    // otherwise post a duplicate right after it.
    await playSong(voiceChannel.guild.id, song, false);
  }
  return queue;
}

function skip(guildId) {
  const queue = queues.get(guildId);
  if (!queue || queue.songs.length === 0) return false;
  // Force-advance regardless of song-loop
  const wasLoopSong = queue.loop === 'song';
  if (wasLoopSong) queue.loop = 'off';
  queue.player.stop(); // triggers Idle -> advance()
  if (wasLoopSong) queue.loop = 'song';
  return true;
}

function stop(guildId) {
  const queue = queues.get(guildId);
  if (!queue) return false;
  queue.songs = [];
  queue.loop = 'off';
  destroyQueue(guildId);
  return true;
}

function pause(guildId) {
  const queue = queues.get(guildId);
  if (!queue) return false;
  return queue.player.pause();
}

function resume(guildId) {
  const queue = queues.get(guildId);
  if (!queue) return false;
  return queue.player.unpause();
}

function setVolume(guildId, percent) {
  const queue = queues.get(guildId);
  if (!queue) return false;
  queue.volume = percent;
  queue.currentResource?.volume?.setVolume(percent / 100);
  return true;
}

function setLoop(guildId, mode) {
  const queue = queues.get(guildId);
  if (!queue) return false;
  queue.loop = mode;
  return true;
}

function buildQueueEmbed(queue, guildName) {
  const embed = new EmbedBuilder().setColor(0x2B6CB0).setTitle(`\ud83c\udfb6 Queue \u2014 ${guildName}`);
  if (queue.songs.length === 0) {
    embed.setDescription('Queue is empty.');
    return embed;
  }
  const lines = queue.songs.slice(0, 15).map((s, i) => {
    const tag = i === 0 ? '\u25b6\ufe0f Now Playing' : `**${i}.**`;
    return `${tag} [${s.title}](${s.url}) \u2014 \`${formatDuration(s.durationSec)}\` \u2014 requested by <@${s.requestedBy}>`;
  });
  if (queue.songs.length > 15) lines.push(`...and ${queue.songs.length - 15} more.`);
  embed.setDescription(lines.join('\n'));
  embed.setFooter({ text: `Loop: ${queue.loop} \u2022 Volume: ${queue.volume}%` });
  return embed;
}

module.exports = {
  queues,
  getQueue,
  ensureQueue,
  destroyQueue,
  resolveSong,
  enqueue,
  skip,
  stop,
  pause,
  resume,
  setVolume,
  setLoop,
  formatDuration,
  buildQueueEmbed,
  setNowPlayingNotifier,
};
