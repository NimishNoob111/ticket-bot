# Pterodactyl / Minecraft Support Bot

A free Discord bot that answers Pterodactyl Panel, Wings, and Minecraft server
questions using Groq's free LLM API (super fast, generous free tier, no credit card).

It responds when:
- Someone uses `/support <question>`
- Someone @mentions the bot in a server channel
- Someone DMs the bot directly

---

## 1. Get a free Groq API key

1. Go to https://console.groq.com/keys
2. Sign up (free, no card required)
3. Click "Create API Key", copy it — you'll paste it into `.env` below

Groq's free tier is rate-limited but plenty for a support bot with normal traffic.
Check current limits at https://console.groq.com/docs/rate-limits if you expect heavy use.

## 2. Create the Discord bot

1. Go to https://discord.com/developers/applications → "New Application"
2. Name it (e.g. "Pterodactyl Helper") → Create
3. Left sidebar → **Bot** → "Add Bot"
4. Under **Privileged Gateway Intents**, turn ON **Message Content Intent** (required so it can read questions in mentions/DMs)
5. Click "Reset Token" → copy the token — this goes in `.env` as `DISCORD_TOKEN`
6. Left sidebar → **OAuth2 → General** → copy the **Client ID** — this goes in `.env` as `DISCORD_CLIENT_ID`
7. Left sidebar → **OAuth2 → URL Generator**:
   - Scopes: check `bot` and `applications.commands`
   - Bot Permissions: check `Send Messages`, `Read Message History`, `View Channels`
   - Copy the generated URL at the bottom, open it in your browser, and invite the bot to your server

## 3. Install and configure

```bash
npm install
cp .env.example .env
```

Open `.env` and fill in the three values you copied above:

```
DISCORD_TOKEN=...
DISCORD_CLIENT_ID=...
GROQ_API_KEY=...
```

## 4. Register the slash command

```bash
npm run deploy-commands
```

You only need to re-run this if you change the command's name/description/options.

## 5. Run the bot

```bash
npm start
```

You should see `Logged in as YourBot#1234. Ready to help...` in the console.

Try it in Discord:
- `/support my server is stuck on "Installing..."`
- `@YourBot the server crashed with "Exit code 1"`
- DM the bot directly

## 6. Keep it running 24/7 (optional)

Right now the bot only runs while your terminal is open. To host it for free/cheap:

- **Free option:** Railway, Render, or Fly.io free tiers — push this folder as a repo and set it to run `npm start`, with the same env vars added in their dashboard.
- **On your own PC:** use `pm2` (`npm i -g pm2`, then `pm2 start index.js --name pterodactyl-bot`) so it survives terminal closes and restarts on crash.
- Since this bot is likely meant to run *alongside* an actual Pterodactyl node, you could also just run it on the same VPS as your Pterodactyl install with `pm2`.

## Customizing the bot's knowledge/behavior

Edit the `SYSTEM_PROMPT` constant near the top of `index.js`. That's the bot's
entire "personality" and expertise — you can:
- Add specifics about your own hosting setup (e.g. your egg configs, node specs)
- Tell it to always recommend your support Discord/ticket system for issues it can't solve
- Make it terser or more detailed
- Swap `GROQ_MODEL` in `.env` to a different Groq-hosted model if you want (see https://console.groq.com/docs/models for the current list)

## Notes / limitations

- This bot gives general troubleshooting advice based on common Pterodactyl/Minecraft
  issues — it has no direct access to your actual panel, node, or server logs unless
  a user pastes them into the chat.
- It's not affiliated with the official Pterodactyl project. For confirmed bugs or
  edge cases, point users to https://pterodactyl.io/ or the official Pterodactyl Discord.
- Groq's free tier has rate limits; if you hit them the bot will show an error —
  consider adding your own retry/backoff logic if you scale up usage.
