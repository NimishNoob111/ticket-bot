'use strict';

const { SlashCommandBuilder } = require('discord.js');
const ptero = require('../pterodactyl');
const { getUserByDiscordId } = require('../database');
const { successEmbed, errorEmbed } = require('../utils/embeds');
const { hasManageServerPermission } = require('../utils/permissions');

// Grants exactly enough to run console commands + power actions - nothing
// else (no file access, no settings, no ability to manage other subusers).
const CONSOLE_POWER_PERMISSIONS = [
  'control.console',
  'control.start',
  'control.stop',
  'control.restart',
];

/**
 * Verifies the caller either owns the server (via the users table mapping)
 * or has Manage Server/Administrator as a staff override.
 */
async function resolveOwnedServer(interaction, serverId) {
  const callerMapping = getUserByDiscordId(interaction.user.id);

  if (!callerMapping) {
    return {
      ok: false,
      embed: errorEmbed({
        title: 'Not Linked',
        description: 'You need to `/nothing link` your Pterodactyl account before managing subusers.',
      }),
    };
  }

  const serverResult = await ptero.findServerByIdentifier(serverId);
  if (!serverResult.ok) {
    return {
      ok: false,
      embed: errorEmbed({ title: 'Server Not Found', description: serverResult.error }),
    };
  }

  const server = serverResult.data;
  const isOwner = server.attributes.user === callerMapping.pterodactyl_id;

  if (!isOwner && !hasManageServerPermission(interaction)) {
    return {
      ok: false,
      embed: errorEmbed({
        title: 'Not The Server Owner',
        description: 'Only the server owner (or an admin) can manage subusers for this server.',
      }),
    };
  }

  return { ok: true, server };
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('subuser')
    .setDescription('Grant or revoke console/power access to your server for another user.')
    .addSubcommand((sub) =>
      sub
        .setName('add')
        .setDescription('Grant a user console + power access to your server')
        .addUserOption((o) =>
          o.setName('user').setDescription('Discord user to grant access to').setRequired(true)
        )
        .addStringOption((o) =>
          o.setName('server_id').setDescription('Server identifier (e.g. s1)').setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('remove')
        .setDescription("Revoke a user's console + power access to your server")
        .addUserOption((o) =>
          o.setName('user').setDescription('Discord user to revoke access from').setRequired(true)
        )
        .addStringOption((o) =>
          o.setName('server_id').setDescription('Server identifier (e.g. s1)').setRequired(true)
        )
    ),

  async execute(interaction) {
    const subcommand = interaction.options.getSubcommand();
    const targetDiscordUser = interaction.options.getUser('user', true);
    const serverId = interaction.options.getString('server_id', true).trim();

    await interaction.deferReply({ ephemeral: true });

    const resolved = await resolveOwnedServer(interaction, serverId);
    if (!resolved.ok) {
      await interaction.editReply({ embeds: [resolved.embed] });
      return;
    }

    const targetMapping = getUserByDiscordId(targetDiscordUser.id);
    if (!targetMapping) {
      await interaction.editReply({
        embeds: [
          errorEmbed({
            title: 'User Not Linked',
            description: `**${targetDiscordUser.tag}** needs to \`/nothing link\` their Pterodactyl account first.`,
          }),
        ],
      });
      return;
    }

    const identifier = resolved.server.attributes.identifier;

    try {
      if (subcommand === 'add') {
        const result = await ptero.createSubuser(
          identifier,
          targetMapping.pterodactyl_email,
          CONSOLE_POWER_PERMISSIONS
        );

        if (!result.ok) {
          await interaction.editReply({
            embeds: [errorEmbed({ title: 'Failed To Add Subuser', description: result.error })],
          });
          return;
        }

        await interaction.editReply({
          embeds: [
            successEmbed({
              title: 'Subuser Added',
              description: `**${targetDiscordUser.tag}** can now run console commands and power actions on **${resolved.server.attributes.name}**.`,
            }),
          ],
        });
        return;
      }

      // subcommand === 'remove'
      const listResult = await ptero.listSubusers(identifier);
      if (!listResult.ok) {
        await interaction.editReply({
          embeds: [errorEmbed({ title: 'Failed To Fetch Subusers', description: listResult.error })],
        });
        return;
      }

      const subusers = listResult.data?.data ?? [];
      const match = subusers.find(
        (s) => s.attributes.email?.toLowerCase() === targetMapping.pterodactyl_email.toLowerCase()
      );

      if (!match) {
        await interaction.editReply({
          embeds: [
            errorEmbed({
              title: 'Not A Subuser',
              description: `**${targetDiscordUser.tag}** isn't currently a subuser on this server.`,
            }),
          ],
        });
        return;
      }

      const deleteResult = await ptero.deleteSubuser(identifier, match.attributes.uuid);
      if (!deleteResult.ok) {
        await interaction.editReply({
          embeds: [errorEmbed({ title: 'Failed To Remove Subuser', description: deleteResult.error })],
        });
        return;
      }

      await interaction.editReply({
        embeds: [
          successEmbed({
            title: 'Subuser Removed',
            description: `**${targetDiscordUser.tag}**'s access to **${resolved.server.attributes.name}** has been revoked.`,
          }),
        ],
      });
    } catch (err) {
      console.error('[/subuser] Unexpected error:', err);
      await interaction.editReply({
        embeds: [
          errorEmbed({
            description: 'An unexpected error occurred. Check the bot console logs.',
          }),
        ],
      });
    }
  },
};
