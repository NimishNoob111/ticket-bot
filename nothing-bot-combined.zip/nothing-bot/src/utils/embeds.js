'use strict';

const { EmbedBuilder } = require('discord.js');

const COLORS = {
  SUCCESS: 0x57f287, // Discord green
  ERROR: 0xed4245, // Discord red
  INFO: 0x5865f2, // Discord blurple
  WARN: 0xfee75c, // Discord yellow
};

function baseEmbed() {
  return new EmbedBuilder().setTimestamp().setFooter({
    text: 'Pterodactyl Control',
  });
}

function successEmbed({ title, description, fields = [] }) {
  const embed = baseEmbed()
    .setColor(COLORS.SUCCESS)
    .setTitle(`✅ ${title}`);
  if (description) embed.setDescription(description);
  if (fields.length) embed.addFields(fields);
  return embed;
}

function errorEmbed({ title = 'Something went wrong', description }) {
  return baseEmbed()
    .setColor(COLORS.ERROR)
    .setTitle(`❌ ${title}`)
    .setDescription(description || 'An unknown error occurred.');
}

function infoEmbed({ title, description, fields = [] }) {
  const embed = baseEmbed().setColor(COLORS.INFO).setTitle(`ℹ️ ${title}`);
  if (description) embed.setDescription(description);
  if (fields.length) embed.addFields(fields);
  return embed;
}

function warnEmbed({ title, description }) {
  return baseEmbed()
    .setColor(COLORS.WARN)
    .setTitle(`⚠️ ${title}`)
    .setDescription(description);
}

module.exports = { COLORS, successEmbed, errorEmbed, infoEmbed, warnEmbed };
