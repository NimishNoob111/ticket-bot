'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { findQuarantineRole } = require('../moderation');
const { isStaffInteraction } = require('../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('release')
    .setDescription('Release a user from quarantine')
    .addUserOption((opt) => opt.setName('user').setDescription('User to release').setRequired(true)),

  async execute(interaction, { logAction }) {
    if (!isStaffInteraction(interaction)) {
      return interaction.reply({ content: '❌ Staff only.', ephemeral: true });
    }

    const target = interaction.options.getUser('user', true);
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) {
      return interaction.reply({ content: '❌ Could not find that member in this server.', ephemeral: true });
    }

    const role = findQuarantineRole(interaction.guild);
    if (role) await member.roles.remove(role).catch(() => {});

    await interaction.reply({ content: `🔓 **${target.tag}** has been released from quarantine.` });
    return logAction(interaction.guild, new EmbedBuilder()
      .setColor(0x2B6CB0)
      .setTitle('🔓 Manual Release (/release)')
      .setDescription(`**Target:** ${target} (${target.id})\n**By:** ${interaction.user}`)
      .setTimestamp());
  },
};
