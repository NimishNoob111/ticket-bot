'use strict';

const path = require('node:path');
const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const { loadJSON, updateJSON } = require('../jsonStore');
const { isStaffMember } = require('../utils/permissions');

const BAD_WORDS_PATH = path.join(__dirname, '..', '..', 'data', 'bad-words.json');
const OFFENSES_PATH = path.join(__dirname, '..', '..', 'data', 'swear-offenses.json');
const WHITELIST_PATH = path.join(__dirname, '..', '..', 'data', 'whitelist.json');

const BAD_WORDS = new Set(loadJSON(BAD_WORDS_PATH));

// Longer legitimate words that happen to contain a flagged word as a substring.
// These get masked out before the fuzzy substring scan so they don't false-positive.
// Extend this list if you notice more false positives in practice.
const SAFE_WORDS = [
  'class', 'classic', 'classroom', 'classified', 'assassin', 'assassinate',
  'assist', 'assistant', 'assistance', 'assess', 'assessment', 'associate',
  'grass', 'glass', 'brass', 'mass', 'pass', 'password', 'bass', 'compass',
  'hello', 'shell', 'cockpit', 'cockroach', 'cocktail', 'scunthorpe',
  'harassment', 'embarrass', 'embarrassed',
];

const LEET_MAP = { '1': 'i', '3': 'e', '4': 'a', '5': 's', '7': 't', '0': 'o', '@': 'a', '$': 's' };
const LEET_REGEX = new RegExp('[' + Object.keys(LEET_MAP).map((c) => '\\' + c).join('') + ']', 'g');
function applyLeet(str) {
  return str.replace(LEET_REGEX, (ch) => LEET_MAP[ch]);
}

// Collapses runs of the same repeated character down to one, e.g. "fuuuuck" -> "fuck".
function collapseRepeats(str) {
  return str.replace(/(.)\1+/g, '$1');
}

// Separators people use to break a word up: spaces, dots, underscores, asterisks, dashes.
const SEPARATOR_REGEX = /[\s.\-_*]+/g;
function stripSeparators(str) {
  return str.replace(SEPARATOR_REGEX, '');
}

// Masks known-safe words out of a compact (separator-stripped) string so
// their substrings (e.g. "ass" inside "class") can't trigger a false match.
function maskSafeWords(compact) {
  let masked = compact;
  for (const safe of SAFE_WORDS) {
    if (!safe) continue;
    masked = masked.split(safe).join('#'.repeat(safe.length));
  }
  return masked;
}

// Returns the matched bad word if the message content trips the filter, else null.
function findBadWordHit(rawContent) {
  const lower = rawContent.toLowerCase();
  const leeted = applyLeet(lower);
  const collapsed = collapseRepeats(leeted);

  // Stage 1 — exact whole-word match. Catches normal usage, whole-word
  // leetspeak ("sh1t" -> "shit"), and letter-spam ("fuuuck" -> "fuck")
  // without false-positive risk, since word boundaries (spaces/punctuation)
  // are respected.
  const tokens = collapsed.split(/[^a-z]+/).filter(Boolean);
  for (const token of tokens) {
    if (BAD_WORDS.has(token)) return token;
  }

  // Stage 2 — separator-stripped substring match. Catches evasion like
  // "f u c k", "f.u.c.k", "f_u_c_k", "f*ck". Only applied to words 3+
  // letters long to keep 1-2 letter entries (e.g. "mc", "bc") from
  // generating noise here.
  const compact = collapseRepeats(stripSeparators(collapsed));
  const masked = maskSafeWords(compact);
  for (const word of BAD_WORDS) {
    if (word.length < 3) continue;
    if (masked.includes(word)) return word;
  }

  return null;
}

// Offenses 1-5 escalate through timeouts; only offense 6+ results in a ban.
const TIMEOUT_DURATIONS_MS = [
  2 * 60 * 1000,    // offense 1 — 2 min
  5 * 60 * 1000,    // offense 2 — 5 min
  10 * 60 * 1000,   // offense 3 — 10 min
  30 * 60 * 1000,   // offense 4 — 30 min
  60 * 60 * 1000,   // offense 5 — 1 hour
];

// Applies full lockdown overwrites (no view, no chat, no invites, no voice)
// for the Quarantine role across every channel in a guild.
async function lockdownChannelForQuarantine(channel, role) {
  if (!channel.permissionOverwrites) return;
  await channel.permissionOverwrites.edit(role, {
    ViewChannel: false,
    SendMessages: false,
    CreateInstantInvite: false,
    AddReactions: false,
    Speak: false,
    Connect: false,
  }).catch(() => {});
}

// Resolves the guild's Quarantine role: prefers the explicit QUARANTINE_ROLE_ID
// from .env if set (robust against the role being renamed), falling back to
// searching by the literal name "Quarantine".
function findQuarantineRole(guild) {
  const configuredId = process.env.QUARANTINE_ROLE_ID;
  if (configuredId) {
    const byId = guild.roles.cache.get(configuredId);
    if (byId) return byId;
  }
  return guild.roles.cache.find((r) => r.name === 'Quarantine') || null;
}

async function ensureQuarantineRole(guild) {
  let role = findQuarantineRole(guild);
  if (!role) {
    try {
      role = await guild.roles.create({
        name: 'Quarantine',
        color: 'DarkRed',
        permissions: [],
        reason: 'Nothing bot: auto-created quarantine role',
      });
      for (const ch of guild.channels.cache.values()) {
        await lockdownChannelForQuarantine(ch, role);
      }
      console.log(`🛡️ Quarantine role created and locked down in ${guild.name}`);
      if (process.env.QUARANTINE_ROLE_ID && process.env.QUARANTINE_ROLE_ID !== role.id) {
        console.warn(
          `⚠️ QUARANTINE_ROLE_ID in .env (${process.env.QUARANTINE_ROLE_ID}) doesn't match any role in ${guild.name} — ` +
          `created a fresh one (${role.id}) instead. Update .env if that's not intentional.`
        );
      }
    } catch (e) {
      console.warn(`⚠️ Could not create Quarantine role in ${guild.name}: ${e.message}`);
    }
  }
  return role;
}

function register(client, { logAction }) {
  async function handleBadWordOffense(message, hitWord) {
    if (isStaffMember(message.member)) return; // filter doesn't apply to staff/admins

    await message.delete().catch(() => {});

    // updateJSON serializes this read-increment-write so two swears landing
    // at the same instant (e.g. from two different channels) can't both
    // read the same starting count and silently lose an offense.
    const count = await updateJSON(OFFENSES_PATH, (offenses) => {
      const next = (offenses[message.author.id] || 0) + 1;
      offenses[message.author.id] = next;
      return next;
    });

    const embed = new EmbedBuilder().setColor(0xE02424).setTitle('🤬 Language Warning').setTimestamp();

    try {
      if (count <= TIMEOUT_DURATIONS_MS.length) {
        const ms = TIMEOUT_DURATIONS_MS[count - 1];
        const minutes = ms / 60000;
        await message.member.timeout(ms, `Profanity filter — offense #${count}`);
        embed.setDescription(
          `${message.author} your message was removed for inappropriate language.\n\n` +
          `**Offense #${count}** — timed out for **${minutes} minutes**.`
        );
      } else {
        await message.member.ban({ reason: `Profanity filter — offense #${count}` });
        embed.setDescription(`${message.author} was **banned** for repeated inappropriate language (offense #${count}).`);
      }
    } catch (err) {
      console.error('Profanity filter punishment error:', err);
      embed.setDescription(`${message.author}'s message was removed for inappropriate language, but I couldn't apply the punishment — check my permissions (Moderate Members / Ban Members).`);
    }

    await message.channel.send({ embeds: [embed] }).catch(() => {});
    await logAction(message.guild, new EmbedBuilder()
      .setColor(0xE02424)
      .setTitle('🤬 Profanity Filter Triggered')
      .setDescription(`**User:** ${message.author} (${message.author.id})\n**Channel:** ${message.channel}\n**Offense #:** ${count}\n**Matched:** \`${hitWord}\`\n**Action:** ${count <= TIMEOUT_DURATIONS_MS.length ? `Timeout ${TIMEOUT_DURATIONS_MS[count - 1] / 60000}m` : 'Ban'}`)
      .setTimestamp());
  }

  client.on('messageCreate', async (message) => {
    if (!message.guild || message.author.bot || !message.member) return;
    const hit = findBadWordHit(message.content);
    if (hit) await handleBadWordOffense(message, hit);
  });

  // ================= ANTI-PING QUARANTINE PROTOCOL =================
  client.on('messageCreate', async (message) => {
    if (message.author.bot || !message.guild || !message.member) return;

    const usedMassPing = message.mentions.everyone; // covers @everyone and @here
    if (!usedMassPing) return;

    const whitelist = loadJSON(WHITELIST_PATH);
    const isWhitelisted = whitelist.includes(message.author.id);

    if (isWhitelisted || isStaffMember(message.member)) return;

    // BREACH
    try {
      await message.delete();

      const role = findQuarantineRole(message.guild);
      if (role) await message.member.roles.add(role).catch(() => {});

      const embed = new EmbedBuilder()
        .setColor(0xE02424)
        .setTitle('⚠️ Security Breach — User Quarantined')
        .setDescription(
          `**User Quarantined:** ${message.author} has been quarantined for mentioning \`@everyone\`/\`@here\` without being whitelisted.`
        )
        .addFields(
          { name: 'Action Taken', value: '🗑️ Message deleted\n🔒 `Quarantine` role applied' },
          { name: 'Resolution', value: 'Administrator: `/nothing whitelist [user]`' }
        )
        .setTimestamp();

      await message.channel.send({ embeds: [embed] });
      await logAction(message.guild, new EmbedBuilder()
        .setColor(0xE02424)
        .setTitle('⚠️ Auto-Quarantine (Mass Ping)')
        .setDescription(`**User:** ${message.author} (${message.author.id})\n**Channel:** ${message.channel}\n**Action:** Message deleted, Quarantine role applied`)
        .setTimestamp());
    } catch (err) {
      console.error('Quarantine protocol error:', err);
    }
  });

  // Auto-lock the Quarantine role out of any newly created channel
  client.on('channelCreate', async (channel) => {
    if (!channel.guild) return;
    const role = findQuarantineRole(channel.guild);
    if (role) await lockdownChannelForQuarantine(channel, role);
  });
}

module.exports = {
  BAD_WORDS_PATH,
  OFFENSES_PATH,
  WHITELIST_PATH,
  findBadWordHit,
  findQuarantineRole,
  ensureQuarantineRole,
  lockdownChannelForQuarantine,
  register,
};
