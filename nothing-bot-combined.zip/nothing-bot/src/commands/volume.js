'use strict';

const { SlashCommandBuilder } = require('discord.js');
const music = require('../music');
const { checkVoiceState } = require('../musicGuards');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('volume')
    .setDescription('Set playback volume')
    .addIntegerOption((opt) => opt.setName('percent').setDescription('0-200').setRequired(true).setMinValue(0).setMaxValue(200)),

  async execute(interaction) {
    const denial = checkVoiceState(interaction, 'volume');
    if (denial) return interaction.reply(denial);

    const queue = music.getQueue(interaction.guild.id);
    if (!queue) return interaction.reply({ content: '❌ Nothing is playing right now.', ephemeral: true });

    const percent = interaction.options.getInteger('percent', true);
    if (percent < 0 || percent > 200) {
      return interaction.reply({ content: '❌ Volume must be between 0 and 200.', ephemeral: true });
    }
    music.setVolume(interaction.guild.id, percent);
    return interaction.reply({ content: `🔊 Volume set to **${percent}%**.` });
  },
};
