'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const music = require('../music');
const { checkVoiceState } = require('../musicGuards');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('play')
    .setDescription('Play a song — search, YouTube link, or Spotify track link')
    .addStringOption((opt) => opt.setName('query').setDescription('Song name, YouTube URL, or Spotify track URL').setRequired(true)),

  async execute(interaction) {
    const denial = checkVoiceState(interaction, 'play');
    if (denial) return interaction.reply(denial);

    const voiceChannel = interaction.member.voice.channel;
    const query = interaction.options.getString('query', true);
    await interaction.deferReply();

    let song;
    try {
      song = await music.resolveSong(query, interaction.user.id);
    } catch (err) {
      return interaction.editReply({ content: `❌ ${err.message}` });
    }

    try {
      const q = await music.enqueue(voiceChannel, interaction.channel.id, song);
      const isNowPlaying = q.songs[0] === song;
      const embed = new EmbedBuilder()
        .setColor(0x2B6CB0)
        .setTitle(isNowPlaying ? '🎶 Now Playing' : '➕ Added to Queue')
        .setDescription(`[${song.title}](${song.url})`)
        .addFields(
          { name: 'Duration', value: music.formatDuration(song.durationSec), inline: true },
          { name: 'Requested by', value: `<@${song.requestedBy}>`, inline: true },
        );
      if (song.thumbnail) embed.setThumbnail(song.thumbnail);
      return interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error('Music play error:', err);
      return interaction.editReply({ content: `❌ Couldn't play that: ${err.message}` });
    }
  },
};
