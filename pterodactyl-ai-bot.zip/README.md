# Pterodactyl / Minecraft AI Support Bot (Discord + Gemini)

A Discord bot that answers troubleshooting questions about **Pterodactyl Panel** and
**Minecraft servers** using Google's Gemini API. Works via `/ask`, by @mentioning the
bot, or (optionally) by auto-responding in specific channels — like a support channel.

## Features
- Replies to **every message in every channel it can see** — no @mention or slash
  command needed, it just responds like it's part of the conversation
- `/ask <question>` also works if you prefer that
- Per-channel short-term memory (remembers the last few messages so follow-ups work)
- `/resetchat` — wipe that channel's memory
- Long answers are automatically split to respect Discord's 2000-character limit
- System prompt tuned specifically for Pterodactyl (Panel/Wings/nodes/eggs) and Minecraft
  (crashes, plugin/mod conflicts, Java version errors, TPS/lag, memory settings, etc.)

## 1. Create the Discord bot
1. Go to https://discord.com/developers/applications → **New Application**.
2. Go to **Bot** → **Add Bot**.
3. Under **Privileged Gateway Intents**, enable **MESSAGE CONTENT INTENT**.
4. Copy the **Bot Token** (Bot page) and the **Application (Client) ID** (General Information page).
5. Go to **OAuth2 → URL Generator**:
   - Scopes: `bot`, `applications.commands`
   - Bot Permissions: `Send Messages`, `Read Message History`, `Use Slash Commands`
   - Open the generated URL and invite the bot to your server.

## 2. Get a Gemini API key
Go to https://aistudio.google.com/apikey and create a free API key.

## 3. Configure
```bash
cp .env.example .env
```
Fill in `.env`:
- `DISCORD_TOKEN`
- `DISCORD_CLIENT_ID`
- `DISCORD_GUILD_ID` (optional — your server's ID, for instant command sync while testing)
- `GEMINI_API_KEY`

> **Heads up:** the bot now replies to every message in every channel it can see —
> including casual chat, not just Pterodactyl/Minecraft questions. If you want it
> limited to specific channels (e.g. just `#support`), don't grant it "View Channel"
> permission on the others in Discord's channel permission settings — that's the
> actual on/off switch now, not a config option in the bot itself.

## 4. Install & run
Requires Node.js 18+.
```bash
npm install
npm run deploy   # registers the /ask and /resetchat slash commands
npm start        # starts the bot
```

You should see `Logged in as YourBot#1234` in the console.

## 5. Keep it running on your server/PC
For a always-on setup, use a process manager, e.g.:
```bash
npm install -g pm2
pm2 start index.js --name ptero-mc-bot
pm2 save
pm2 startup   # follow the printed instructions to survive reboots
```

## Customizing the bot's knowledge/behavior
Edit `systemPrompt.js` — that's the instruction block that tells Gemini how to behave.
You can add:
- Your specific panel version, node setup, or common eggs you use
- House rules (e.g. "always tell users to check console logs before restarting")
- Links to your own wiki/docs for the bot to reference by name

## Notes / limits
- Gemini doesn't know about your specific server setup unless you tell it (paste logs,
  configs, or describe your setup in the message) — it's not connected to your actual
  Pterodactyl panel or servers, it just gives advice.
- Conversation memory is in-memory only (resets if the bot restarts) and scoped per channel.
- `gemini-2.0-flash` (default) is fast and cheap; swap `GEMINI_MODEL` in `.env` for a
  stronger model if you want deeper reasoning on gnarly bugs.
