'use strict';

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const { TICKET_TYPES, TICKET_PANEL_DESCRIPTION } = require('../tickets');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket-panel')
    .setDescription('Deploy the 3-tier ticket creation panel in this channel')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),

  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)) {
      return interaction.reply({ content: '❌ Manage Channels permission required.', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(0x2B6CB0)
      .setTitle('🎫 Ticket Categories')
      .setDescription(TICKET_PANEL_DESCRIPTION);

    const menu = new StringSelectMenuBuilder()
      .setCustomId('ticket_create')
      .setPlaceholder('Select ticket type...')
      .addOptions(
        Object.entries(TICKET_TYPES).map(([key, t]) => ({
          label: t.label, value: key, emoji: t.emoji,
        }))
      );

    await interaction.channel.send({ embeds: [embed], components: [new ActionRowBuilder().addComponents(menu)] });
    return interaction.reply({ content: '✅ Ticket panel deployed.', ephemeral: true });
  },
};
