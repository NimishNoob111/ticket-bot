'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const ptero = require('../pterodactyl');
const { successEmbed, errorEmbed } = require('../utils/embeds');
const { hasManageServerPermission } = require('../utils/permissions');

const POWER_SIGNALS = ['start', 'stop', 'restart', 'kill'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('console')
    .setDescription('ADMIN: Send console commands or power actions to a server.')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sub) =>
      sub
        .setName('command')
        .setDescription('Send a raw command to the server console')
        .addStringOption((o) =>
          o.setName('server_id').setDescription('Server identifier (e.g. s1 or full UUID)').setRequired(true)
        )
        .addStringOption((o) =>
          o
            .setName('command')
            .setDescription('The console command to run (e.g. "op ItzNimish", "safeshutdown")')
            .setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('power')
        .setDescription("Control the server's power state")
        .addStringOption((o) =>
          o.setName('server_id').setDescription('Server identifier (e.g. s1 or full UUID)').setRequired(true)
        )
        .addStringOption((o) =>
          o
            .setName('action')
            .setDescription('Power action to perform')
            .setRequired(true)
            .addChoices(
              { name: 'start', value: 'start' },
              { name: 'stop', value: 'stop' },
              { name: 'restart', value: 'restart' },
              { name: 'kill (force-stop, use with care)', value: 'kill' }
            )
        )
    ),

  async execute(interaction) {
    if (!hasManageServerPermission(interaction)) {
      await interaction.reply({
        embeds: [
          errorEmbed({
            title: 'Permission Denied',
            description: 'This command requires the **Administrator** permission.',
          }),
        ],
        ephemeral: true,
      });
      return;
    }

    const subcommand = interaction.options.getSubcommand();
    const serverId = interaction.options.getString('server_id', true).trim();

    await interaction.deferReply();

    try {
      if (subcommand === 'command') {
        const command = interaction.options.getString('command', true).trim();

        const result = await ptero.sendConsoleCommand(serverId, command);

        if (!result.ok) {
          await interaction.editReply({
            embeds: [errorEmbed({ title: 'Console Command Failed', description: result.error })],
          });
          return;
        }

        await interaction.editReply({
          embeds: [
            successEmbed({
              title: 'Command Sent',
              description: `Sent to **${serverId}**:\n\`\`\`\n${command}\n\`\`\``,
              fields: [],
            }),
          ],
        });
        return;
      }

      if (subcommand === 'power') {
        const action = interaction.options.getString('action', true);

        if (!POWER_SIGNALS.includes(action)) {
          await interaction.editReply({
            embeds: [errorEmbed({ title: 'Invalid Action', description: `Must be one of: ${POWER_SIGNALS.join(', ')}` })],
          });
          return;
        }

        const result = await ptero.setPowerState(serverId, action);

        if (!result.ok) {
          await interaction.editReply({
            embeds: [errorEmbed({ title: 'Power Action Failed', description: result.error })],
          });
          return;
        }

        await interaction.editReply({
          embeds: [
            successEmbed({
              title: 'Power Signal Sent',
              description: `Sent **${action}** to server **${serverId}**. State changes may take a few seconds to reflect.`,
            }),
          ],
        });
        return;
      }
    } catch (err) {
      console.error('[/console] Unexpected error:', err);
      await interaction.editReply({
        embeds: [
          errorEmbed({
            description: 'An unexpected error occurred. Check the bot console logs.',
          }),
        ],
      });
    }
  },
};
