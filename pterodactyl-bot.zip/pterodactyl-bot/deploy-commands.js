// Run this once (and again whenever you change the command definitions) with:
//   npm run deploy-commands
require("dotenv").config();
const { REST, Routes, SlashCommandBuilder } = require("discord.js");

const commands = [
  new SlashCommandBuilder()
    .setName("support")
    .setDescription("Ask the bot for help with a Pterodactyl or Minecraft server problem")
    .addStringOption((option) =>
      option
        .setName("question")
        .setDescription("Describe your problem or paste an error/log")
        .setRequired(true)
    ),
].map((command) => command.toJSON());

const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);

(async () => {
  try {
    console.log("Registering slash command...");
    await rest.put(Routes.applicationCommands(process.env.DISCORD_CLIENT_ID), {
      body: commands,
    });
    console.log("Slash command registered. It may take up to an hour to show up everywhere, but usually it's instant.");
  } catch (error) {
    console.error(error);
  }
})();
