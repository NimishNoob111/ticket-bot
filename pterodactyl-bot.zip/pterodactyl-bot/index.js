require("dotenv").config();
const { Client, GatewayIntentBits, Partials, Events } = require("discord.js");
const Groq = require("groq-sdk");

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });
const MODEL = process.env.GROQ_MODEL || "llama-3.3-70b-versatile";

const SYSTEM_PROMPT = `You are a friendly, highly experienced support assistant specializing in:
- Pterodactyl Panel (the web panel: nodes, servers, users, permissions, databases, allocations)
- Wings (Pterodactyl's daemon that actually runs the game servers, Docker-based)
- Minecraft servers of all kinds: Vanilla, Paper, Spigot, Purpur, Forge, Fabric, NeoForge, plugins, mods
- Common hosting issues: Docker, ports/allocations, startup variables, egg configuration, crash logs, "Installing..." stuck states, RAM/Java version mismatches, backups, SFTP, database connections, ip/port binding, wings offline/node offline errors

When a user describes a problem or pastes a log/error:
1. Briefly identify the likely root cause in plain language.
2. Give clear, numbered steps to fix it, being specific (exact settings, file names, commands, or panel menu paths).
3. If the log is ambiguous, ask exactly one clarifying question OR give the 2-3 most likely causes ranked by likelihood, whichever is more helpful.
4. Keep answers focused and practical, not overly long. Use Discord-friendly formatting (short paragraphs, numbered lists, \`code blocks\` for commands/config/errors).
5. If something requires server console access, panel admin access, or SSH into the node, say so clearly.
6. Never make up Pterodactyl/Wings config keys or commands you're not confident about — say "double check X in your panel/node config" instead of guessing.

You are not affiliated with the official Pterodactyl team; if a question needs their official docs or Discord, say so and suggest https://pterodactyl.io/ or their Discord.`;

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages,
  ],
  partials: [Partials.Channel],
});

async function askGroq(userText) {
  const completion = await groq.chat.completions.create({
    model: MODEL,
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: userText },
    ],
    temperature: 0.4,
    max_tokens: 1024,
  });
  return completion.choices[0]?.message?.content?.trim() || "Sorry, I couldn't come up with an answer for that.";
}

// Discord messages max out at 2000 chars; split long replies safely.
function splitMessage(text, maxLen = 1900) {
  const chunks = [];
  let remaining = text;
  while (remaining.length > maxLen) {
    let splitAt = remaining.lastIndexOf("\n", maxLen);
    if (splitAt === -1) splitAt = maxLen;
    chunks.push(remaining.slice(0, splitAt));
    remaining = remaining.slice(splitAt);
  }
  chunks.push(remaining);
  return chunks;
}

client.once(Events.ClientReady, (c) => {
  console.log(`Logged in as ${c.user.tag}. Ready to help with Pterodactyl/Minecraft problems!`);
});

// Slash command handler
client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand()) return;
  if (interaction.commandName !== "support") return;

  const question = interaction.options.getString("question", true);
  await interaction.deferReply();

  try {
    const answer = await askGroq(question);
    const chunks = splitMessage(answer);
    await interaction.editReply(chunks[0]);
    for (let i = 1; i < chunks.length; i++) {
      await interaction.followUp(chunks[i]);
    }
  } catch (err) {
    console.error(err);
    await interaction.editReply(
      "Something went wrong talking to the AI backend. Please try again in a moment."
    );
  }
});

// Also respond to @mentions and DMs so it feels like a real help bot, not just a slash command
client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot) return;

  const isDM = message.channel.isDMBased?.();
  const isMentioned = message.mentions.has(client.user.id);
  if (!isDM && !isMentioned) return;

  const question = message.content.replace(`<@${client.user.id}>`, "").trim();
  if (!question) return;

  await message.channel.sendTyping();

  try {
    const answer = await askGroq(question);
    const chunks = splitMessage(answer);
    for (const chunk of chunks) {
      await message.reply(chunk);
    }
  } catch (err) {
    console.error(err);
    await message.reply(
      "Something went wrong talking to the AI backend. Please try again in a moment."
    );
  }
});

client.login(process.env.DISCORD_TOKEN);
