'use strict';

const { SlashCommandBuilder } = require('discord.js');
const ptero = require('../pterodactyl');
const pluginRepo = require('../plugins');
const { getUserByDiscordId } = require('../database');
const { successEmbed, errorEmbed, warnEmbed } = require('../utils/embeds');
const { hasManageServerPermission } = require('../utils/permissions');

const PLUGINS_DIR = '/plugins';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('plugin')
    .setDescription('Install plugins onto a Minecraft server.')
    .addSubcommand((sub) =>
      sub
        .setName('install')
        .setDescription('Download and install the latest compatible version of a plugin')
        .addStringOption((o) =>
          o.setName('server_id').setDescription('Server identifier (e.g. s1)').setRequired(true)
        )
        .addStringOption((o) =>
          o
            .setName('plugin')
            .setDescription('Modrinth/SpigotMC slug, URL, resource ID, or plugin name to search for')
            .setRequired(true)
        )
        .addStringOption((o) =>
          o
            .setName('mc_version')
            .setDescription('Override the auto-detected Minecraft version, e.g. 1.20.4')
            .setRequired(false)
        )
    ),

  async execute(interaction) {
    if (interaction.options.getSubcommand() !== 'install') return;

    const serverId = interaction.options.getString('server_id', true).trim();
    const pluginInput = interaction.options.getString('plugin', true).trim();
    const versionOverride = interaction.options.getString('mc_version')?.trim() || null;

    await interaction.deferReply();

    try {
      // --- Auth: must be linked, and either own the server or be an admin ---
      const callerMapping = getUserByDiscordId(interaction.user.id);
      if (!callerMapping) {
        await interaction.editReply({
          embeds: [
            errorEmbed({ title: 'Not Linked', description: 'You need to `/nothing link` your account first.' }),
          ],
        });
        return;
      }

      const serverResult = await ptero.findServerByIdentifier(serverId);
      if (!serverResult.ok) {
        await interaction.editReply({
          embeds: [errorEmbed({ title: 'Server Not Found', description: serverResult.error })],
        });
        return;
      }

      const server = serverResult.data;
      const isOwner = server.attributes.user === callerMapping.pterodactyl_id;
      if (!isOwner && !hasManageServerPermission(interaction)) {
        await interaction.editReply({
          embeds: [
            errorEmbed({
              title: 'Not The Server Owner',
              description: 'Only the server owner (or an admin) can install plugins on this server.',
            }),
          ],
        });
        return;
      }

      const identifier = server.attributes.identifier;
      const numericId = server.attributes.id;

      // --- Detect Minecraft version + loader from the egg config ---
      let mcVersion = versionOverride;
      let eggName = '';

      const detailResult = await ptero.getServerWithEggInfo(numericId);
      if (detailResult.ok) {
        eggName = detailResult.data?.attributes?.relationships?.egg?.attributes?.name || '';
        const environment = detailResult.data?.attributes?.container?.environment;
        if (!mcVersion) {
          mcVersion = pluginRepo.extractMinecraftVersion(environment);
        }
      }

      if (!mcVersion) {
        await interaction.editReply({
          embeds: [
            warnEmbed({
              title: 'Minecraft Version Unknown',
              description:
                "Couldn't auto-detect this server's Minecraft version from its startup variables " +
                '(egg reports "latest" or no version variable). Continuing without version filtering - ' +
                'the newest plugin release will be installed, which may not match your server.\n\n' +
                `Tip: re-run with the \`mc_version\` option to pin a version, e.g. \`/nothing plugin install server_id:${serverId} plugin:${pluginInput} mc_version:1.20.4\`.`,
            }),
          ],
        });
      }

      // --- Resolve + download the plugin ---
      const resolved = await pluginRepo.resolvePlugin(pluginInput, { mcVersion, eggName });
      if (!resolved.ok) {
        await interaction.editReply({
          embeds: [errorEmbed({ title: 'Plugin Not Found', description: resolved.error })],
        });
        return;
      }

      const plugin = resolved.data;

      let fileBuffer;
      try {
        fileBuffer = await pluginRepo.downloadPluginFile(plugin.downloadUrl);
      } catch (err) {
        await interaction.editReply({
          embeds: [
            errorEmbed({
              title: 'Download Failed',
              description: `Found **${plugin.name}** but couldn't download the file: ${err.message}`,
            }),
          ],
        });
        return;
      }

      const remotePath = `${PLUGINS_DIR}/${plugin.fileName}`;

      const uploadUrlResult = await ptero.getUploadUrl(identifier);
      if (!uploadUrlResult.ok) {
        await interaction.editReply({
          embeds: [
            errorEmbed({
              title: 'Failed To Get Upload URL',
              description: `Downloaded **${plugin.name}** but couldn't get an upload URL: ${uploadUrlResult.error}`,
            }),
          ],
        });
        return;
      }

      const uploadUrl = uploadUrlResult.data?.attributes?.url;
      if (!uploadUrl) {
        await interaction.editReply({
          embeds: [
            errorEmbed({
              title: 'Failed To Get Upload URL',
              description: 'Panel did not return a signed upload URL.',
            }),
          ],
        });
        return;
      }

      const writeResult = await ptero.uploadFile(uploadUrl, PLUGINS_DIR, plugin.fileName, fileBuffer);
      if (!writeResult.ok) {
        await interaction.editReply({
          embeds: [
            errorEmbed({
              title: 'Failed To Upload Plugin',
              description: `Downloaded **${plugin.name}** but couldn't write it to the server: ${writeResult.error}`,
            }),
          ],
        });
        return;
      }

      const fields = [
        { name: 'Source', value: plugin.source, inline: true },
        { name: 'Version', value: plugin.versionNumber, inline: true },
        { name: 'Loader', value: plugin.loader, inline: true },
        { name: 'File', value: `\`${remotePath}\``, inline: false },
      ];

      if (!plugin.exactMatch) {
        fields.push({
          name: '⚠️ Compatibility Not Confirmed',
          value: mcVersion
            ? `No build was published specifically for **${mcVersion}**. Installed the newest available release instead - check it works before relying on it.`
            : 'Server Minecraft version was unknown, so the newest available release was installed without version filtering.',
          inline: false,
        });
      }

      await interaction.editReply({
        embeds: [
          successEmbed({
            title: 'Plugin Installed',
            description: `**${plugin.name}** was installed on **${server.attributes.name}**.\n_A server restart is required for it to load._\n[View on ${plugin.source}](${plugin.pageUrl})`,
            fields,
          }),
        ],
      });
    } catch (err) {
      console.error('[/plugin install] Unexpected error:', err);
      await interaction.editReply({
        embeds: [
          errorEmbed({
            description: 'An unexpected error occurred. Check the bot console logs.',
          }),
        ],
      });
    }
  },
};
