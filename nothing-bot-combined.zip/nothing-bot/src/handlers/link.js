'use strict';

const { SlashCommandBuilder } = require('discord.js');
const ptero = require('../pterodactyl');
const { upsertUserMapping } = require('../database');
const { successEmbed, errorEmbed } = require('../utils/embeds');
const { hasManageServerPermission } = require('../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('link')
    .setDescription('Link your Discord account to your Pterodactyl panel account.')
    .addStringOption((option) =>
      option
        .setName('email')
        .setDescription('The email address on your Pterodactyl account')
        .setRequired(true)
    )
    .addUserOption((option) =>
      option
        .setName('user')
        .setDescription('(Staff only) Link this Discord user instead of yourself')
        .setRequired(false)
    ),

  async execute(interaction) {
    const email = interaction.options.getString('email', true).trim();
    const mentionedUser = interaction.options.getUser('user');

    if (mentionedUser && mentionedUser.id !== interaction.user.id) {
      if (!hasManageServerPermission(interaction)) {
        await interaction.reply({
          embeds: [
            errorEmbed({
              title: 'Permission Denied',
              description:
                'You need the **Manage Server** or **Administrator** permission to link accounts for other users.',
            }),
          ],
          ephemeral: true,
        });
        return;
      }
    }

    const targetUser = mentionedUser ?? interaction.user;

    await interaction.deferReply({ ephemeral: true });

    try {
      const result = await ptero.getUserByEmail(email);

      if (!result.ok) {
        await interaction.editReply({
          embeds: [
            errorEmbed({
              title: 'Pterodactyl API Error',
              description: result.error,
            }),
          ],
        });
        return;
      }

      const match = result.data?.data?.[0];

      if (!match) {
        await interaction.editReply({
          embeds: [
            errorEmbed({
              title: 'Account Not Found',
              description: `No Pterodactyl account exists for **${email}**. Ask an admin to create one, or double-check the email.`,
            }),
          ],
        });
        return;
      }

      const pterodactylId = match.attributes.id;
      const pterodactylEmail = match.attributes.email;

      upsertUserMapping({
        discordId: targetUser.id,
        pterodactylId,
        pterodactylEmail,
      });

      await interaction.editReply({
        embeds: [
          successEmbed({
            title: 'Account Linked',
            description:
              targetUser.id === interaction.user.id
                ? 'Your Discord account is now linked to your Pterodactyl account.'
                : `**${targetUser.tag}**'s Discord account is now linked to their Pterodactyl account.`,
            fields: [
              { name: 'Pterodactyl ID', value: `${pterodactylId}`, inline: true },
              { name: 'Email', value: pterodactylEmail, inline: true },
            ],
          }),
        ],
      });
    } catch (err) {
      console.error('[/link] Unexpected error:', err);
      await interaction.editReply({
        embeds: [
          errorEmbed({
            description: 'An unexpected error occurred. Check the bot console logs.',
          }),
        ],
      });
    }
  },
};
