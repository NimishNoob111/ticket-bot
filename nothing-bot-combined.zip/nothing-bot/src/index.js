'use strict';

require('dotenv').config();

const path = require('node:path');
const fs = require('node:fs');
const { Client, Collection, GatewayIntentBits, Partials, Events, EmbedBuilder } = require('discord.js');
const { getVoiceConnection } = require('@discordjs/voice');
const chalk = require('chalk');

const { initDatabase } = require('./database');
const { errorEmbed } = require('./utils/embeds');
const { hasAllowedRole } = require('./utils/permissions');
const tickets = require('./tickets');
const moderation = require('./moderation');

// ---------------------------------------------------------------------------
// Environment validation — fail fast with a clear message instead of a
// confusing crash three layers deep.
// ---------------------------------------------------------------------------
const REQUIRED_ENV = ['DISCORD_TOKEN', 'PTERO_URL', 'PTERO_APP_KEY'];
const missing = REQUIRED_ENV.filter((key) => !process.env[key]);

if (missing.length > 0) {
  console.error(
    `[Startup] Missing required environment variable(s): ${missing.join(', ')}.\n` +
      'Copy .env.example to .env and fill in the values before starting the bot.'
  );
  process.exit(1);
}

if (!process.env.STAFF_ROLE_ID) {
  console.warn('⚠️  STAFF_ROLE_ID is not set in .env — ticket/moderation staff checks will fall back to Administrator-only.');
}

const LOG_CHANNEL_ID = process.env.LOG_CHANNEL_ID || null;
if (!LOG_CHANNEL_ID) {
  console.warn('⚠️  LOG_CHANNEL_ID is not set in .env — moderation/ticket action logging is disabled until you set it.');
}

if (!process.env.SPOTIFY_CLIENT_ID || !process.env.SPOTIFY_CLIENT_SECRET) {
  console.warn('⚠️  SPOTIFY_CLIENT_ID/SPOTIFY_CLIENT_SECRET not set — /play with Spotify links will fail. YouTube/SoundCloud/direct links are unaffected.');
}

// ---------------------------------------------------------------------------
// Database (Pterodactyl <-> Discord account linking)
// ---------------------------------------------------------------------------
initDatabase();

// ---------------------------------------------------------------------------
// Discord Client
// ---------------------------------------------------------------------------
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates, // required for the music system
  ],
  partials: [Partials.Channel],
});

// Collections the music engine (src/musicbot) expects to find on the client.
client.players = new Collection();
const MusicEmbedManager = require('./musicbot/src/MusicEmbedManager');
client.musicEmbedManager = new MusicEmbedManager(client);
// A couple of musicbot internals reach for this global instead of the client
// directly — harmless to set, keeps that code path working unmodified.
if (!global.clients) global.clients = {};
global.clients.musicEmbedManager = client.musicEmbedManager;

async function logAction(guild, embed) {
  if (!LOG_CHANNEL_ID) return;
  try {
    const ch = guild.channels.cache.get(LOG_CHANNEL_ID) || (await guild.channels.fetch(LOG_CHANNEL_ID).catch(() => null));
    if (ch) await ch.send({ embeds: [embed] }).catch(() => {});
  } catch (e) {
    /* ignore */
  }
}

const ctx = { logAction };

// ---------------------------------------------------------------------------
// Slash commands — every file in ./commands exports { data, execute(interaction, ctx) }.
// Every file in ./musicbot/commands exports { data, execute(interaction, client) } —
// that's the music engine's own convention, so those are tagged so the
// interaction router below calls them with the right second argument.
// ---------------------------------------------------------------------------
client.commands = new Collection();

function loadCommandsFrom(dir, { isMusicbot }) {
  const commandFiles = fs.readdirSync(dir).filter((f) => f.endsWith('.js'));
  for (const file of commandFiles) {
    const command = require(path.join(dir, file));

    if (!command?.data || typeof command.execute !== 'function') {
      console.warn(`[Startup] Skipping invalid command file: ${file}`);
      continue;
    }

    if (client.commands.has(command.data.name)) {
      console.warn(`[Startup] Command name collision on /${command.data.name} — keeping the first one loaded, skipping ${file}.`);
      continue;
    }

    if (isMusicbot) command.__musicbot = true;
    client.commands.set(command.data.name, command);
    console.log(`[Startup] Loaded command: /${command.data.name}${isMusicbot ? ' (music)' : ''}`);
  }
}

loadCommandsFrom(path.join(__dirname, 'commands'), { isMusicbot: false });
loadCommandsFrom(path.join(__dirname, 'musicbot', 'commands'), { isMusicbot: true });

// Commands that stay open to everyone regardless of ALLOWED_ROLE_ID.
// Only the Pterodactyl-facing `/nothing` dispatcher is gated by this role at
// all (ticket/moderation/music commands have their own, separate staff
// checks) — and even then, `/nothing help` always stays open.
function isGatedByAllowedRole(interaction) {
  if (interaction.commandName !== 'nothing') return false;
  return interaction.options.getSubcommand(false) !== 'help';
}

// ---------------------------------------------------------------------------
// Ticket system + moderation (profanity filter, anti-ping quarantine)
// ---------------------------------------------------------------------------
tickets.register(client, ctx);
moderation.register(client, ctx);

// ---------------------------------------------------------------------------
// Music engine's own event handlers (button clicks on the now-playing embed,
// volume modal, language picker, etc). These already guard themselves to
// only react to their own customIds (see the comments in those files for
// why that guard was necessary), so they're safe to register alongside the
// ticket system's own InteractionCreate listener.
// ---------------------------------------------------------------------------
const musicbotEventsPath = path.join(__dirname, 'musicbot', 'events');
for (const file of fs.readdirSync(musicbotEventsPath).filter((f) => f.endsWith('.js'))) {
  const event = require(path.join(musicbotEventsPath, file));
  if (event.once) {
    client.once(event.name, (...args) => event.execute(...args));
  } else {
    client.on(event.name, (...args) => event.execute(...args));
  }
  console.log(`[Startup] Loaded music event: ${event.name} (${file})`);
}

// ---------------------------------------------------------------------------
// Music session persistence — survive restarts without losing what was
// playing. Mirrors the original MusicBot project's index.js behavior.
// ---------------------------------------------------------------------------
const PlayerStateManager = require('./musicbot/src/PlayerStateManager');
const MusicPlayer = require('./musicbot/src/MusicPlayer');

async function cleanupAudioCache() {
  const cacheDir = path.join(__dirname, 'musicbot', 'audio_cache');
  try {
    if (!fs.existsSync(cacheDir)) {
      fs.mkdirSync(cacheDir, { recursive: true });
      return;
    }
    const protectedFiles = PlayerStateManager.getProtectedCacheFiles();
    for (const file of await fs.promises.readdir(cacheDir)) {
      const absolutePath = path.join(cacheDir, file);
      if (protectedFiles.has(path.resolve(absolutePath))) continue;
      await fs.promises.unlink(absolutePath).catch(() => {});
    }
  } catch (error) {
    console.error(chalk.red('❌ Failed to clean up audio cache:'), error.message);
  }
}

async function restoreSavedPlayers() {
  const savedStates = PlayerStateManager.getAllStates();
  const entries = Object.entries(savedStates || {});
  if (entries.length === 0) return;

  console.log(chalk.cyan(`🔄 Found ${entries.length} saved music session(s) to restore...`));

  for (const [guildId, state] of entries) {
    try {
      const guild = client.guilds.cache.get(guildId) || (await client.guilds.fetch(guildId).catch(() => null));
      if (!guild) {
        await PlayerStateManager.removeState(guildId);
        continue;
      }

      const voiceChannel =
        guild.channels.cache.get(state.voiceChannelId) ||
        (await guild.channels.fetch(state.voiceChannelId).catch(() => null));
      const textChannel =
        guild.channels.cache.get(state.textChannelId) ||
        (await guild.channels.fetch(state.textChannelId).catch(() => null));

      const isVoiceValid = voiceChannel && typeof voiceChannel.isVoiceBased === 'function' && voiceChannel.isVoiceBased();
      const isTextValid = textChannel && typeof textChannel.isTextBased === 'function' && textChannel.isTextBased();

      if (!isVoiceValid || !isTextValid) {
        await PlayerStateManager.removeState(guildId);
        continue;
      }

      const player = new MusicPlayer(guild, textChannel, voiceChannel);
      client.players.set(guildId, player);

      try {
        await player.restoreFromState(state);
        console.log(chalk.green(`✅ Restored music session for ${guild.name}`));
      } catch (error) {
        console.error(chalk.red(`❌ Failed to restore music session for ${guild.name}:`), error.message);
        client.players.delete(guildId);
        player.cleanup();
        await PlayerStateManager.removeState(guildId);
      }
    } catch (error) {
      console.error(chalk.red(`❌ Error restoring music session for guild ${guildId}:`), error.message);
      await PlayerStateManager.removeState(guildId);
    }
  }
}

// ---------------------------------------------------------------------------
// Ready
// ---------------------------------------------------------------------------
client.once(Events.ClientReady, async (readyClient) => {
  console.log(`[Startup] Logged in as ${readyClient.user.tag}`);
  console.log(`[Startup] Serving ${readyClient.guilds.cache.size} guild(s)`);

  readyClient.user.setActivity('server infrastructure', { type: 3 });

  for (const guild of readyClient.guilds.cache.values()) {
    await moderation.ensureQuarantineRole(guild);
  }

  // Give guild/channel caches a moment to fully populate before trying to
  // resolve saved voice/text channels.
  await new Promise((resolve) => setTimeout(resolve, 5000));
  await restoreSavedPlayers();
  await cleanupAudioCache();
});

// ---------------------------------------------------------------------------
// Voice state updates — pauses when everyone leaves / bot gets server-muted,
// resumes when they come back, and cleans up on forced disconnect. Needed
// for the music engine; nothing else in the bot listens to this event.
// ---------------------------------------------------------------------------
client.on(Events.VoiceStateUpdate, async (oldState, newState) => {
  const guild = oldState.guild;
  const player = client.players.get(guild.id);
  if (!player) return;

  const botId = guild.members.me?.id ?? client.user.id;
  const involvesBot = oldState.id === botId || newState.id === botId;

  if (involvesBot) {
    const oldChannelId = oldState.channelId;
    const newChannelId = newState.channelId;

    if (oldChannelId && !newChannelId) {
      try {
        player.pendingEndReason = 'forced-disconnect';
        player.queue = [];
        player.currentTrack = null;
        await client.musicEmbedManager.handlePlaybackEnd(player);
      } catch (error) {
        console.error('❌ Failed to update playback UI after forced disconnect:', error);
      } finally {
        player.cleanup();
        client.players.delete(guild.id);
      }
      return;
    }

    if (newChannelId && oldChannelId !== newChannelId && newState.channel) {
      await player.moveToChannel(newState.channel);
      player.clearInactivityTimer(false);
      await client.musicEmbedManager.updateNowPlayingEmbed(player);
    }

    const wasMuted = oldState.serverMute || oldState.serverDeaf || oldState.suppress;
    const isMuted = newState.serverMute || newState.serverDeaf || newState.suppress;

    if (!wasMuted && isMuted) {
      if (player.pauseFor('mute')) await client.musicEmbedManager.updateNowPlayingEmbed(player);
    } else if (wasMuted && !isMuted) {
      const resumed = player.resumeFor('mute');
      if (resumed || !player.pauseReasons.has('mute')) await client.musicEmbedManager.updateNowPlayingEmbed(player);
    }
  }

  const voiceChannelId = player.voiceChannel?.id;
  if (!voiceChannelId) return;
  if (oldState.channelId !== voiceChannelId && newState.channelId !== voiceChannelId) return;

  const channel = guild.channels.cache.get(voiceChannelId);
  if (!channel) {
    player.cleanup();
    client.players.delete(guild.id);
    return;
  }

  const listeners = channel.members.filter((m) => !m.user.bot).size;
  if (listeners === 0) {
    const alreadyPaused = player.pauseReasons.has('alone');
    player.startInactivityTimer();
    if (!alreadyPaused && player.currentTrack) await client.musicEmbedManager.updateNowPlayingEmbed(player);
  } else {
    const wasPausedForAlone = player.pauseReasons.has('alone');
    player.clearInactivityTimer(true);
    if (wasPausedForAlone && player.currentTrack) await client.musicEmbedManager.updateNowPlayingEmbed(player);
  }
});

// ---------------------------------------------------------------------------
// Slash command interaction routing
// ---------------------------------------------------------------------------
client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);

  if (!command) {
    console.warn(`[Interaction] Unknown command received: /${interaction.commandName}`);
    return;
  }

  if (isGatedByAllowedRole(interaction) && !hasAllowedRole(interaction)) {
    await interaction.reply({
      embeds: [
        errorEmbed({
          title: 'Access Restricted',
          description: 'You need the required role to use this bot.',
        }),
      ],
      ephemeral: true,
    });
    return;
  }

  try {
    // Music commands are the upstream project's own code and expect the raw
    // Discord Client as their second argument (they read client.players /
    // client.musicEmbedManager off it) — everything else here expects our
    // { logAction } context object instead.
    await command.execute(interaction, command.__musicbot ? client : ctx);
  } catch (error) {
    console.error(`[Interaction] Error executing /${interaction.commandName}:`, error);

    const payload = {
      embeds: [
        errorEmbed({
          description:
            'An unexpected error occurred while running this command. The bot owner has been logged the details.',
        }),
      ],
      ephemeral: true,
    };

    try {
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(payload);
      } else {
        await interaction.reply(payload);
      }
    } catch (followUpError) {
      console.error('[Interaction] Failed to send error response:', followUpError);
    }
  }
});

// ---------------------------------------------------------------------------
// Shutdown — save whatever's currently playing so it can be restored on the
// next boot, then disconnect cleanly from every voice channel.
// ---------------------------------------------------------------------------
async function gracefulShutdown() {
  const savePromises = [];
  for (const [guildId, player] of client.players) {
    if (typeof player.persistState === 'function') {
      savePromises.push(player.persistState('shutdown', true).catch(() => {}));
    }
  }
  await Promise.all(savePromises);

  client.players.forEach((player, guildId) => {
    player.stop?.();
    const connection = getVoiceConnection(guildId);
    if (connection) connection.destroy();
  });

  client.destroy();
  process.exit(0);
}

process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);

process.on('unhandledRejection', (reason) => {
  console.error('[Process] Unhandled promise rejection:', reason);
});

client.login(process.env.DISCORD_TOKEN);
