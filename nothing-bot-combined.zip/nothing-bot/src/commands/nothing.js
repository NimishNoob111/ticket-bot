'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const help = require('../handlers/help');
const link = require('../handlers/link');
const status = require('../handlers/status');
const deploy = require('../handlers/deploy');
const upgrade = require('../handlers/upgrade');
const consoleHandler = require('../handlers/console');
const subuser = require('../handlers/subuser');
const config = require('../handlers/config');
const server = require('../handlers/server');
const plugin = require('../handlers/plugin');

const { updateJSON } = require('../jsonStore');
const { WHITELIST_PATH } = require('../moderation');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('nothing')
    .setDescription('Pterodactyl panel management + core Nothing system commands.')

    // ---------------------------------------------------------------
    // Direct subcommands (everyone can see these; admin-gating for
    // deploy/upgrade/whitelist happens in-code, not via Discord's UI
    // hiding, since that's only possible at the top-level command).
    // ---------------------------------------------------------------
    .addSubcommand((sub) => sub.setName('help').setDescription('Show all available commands.'))
    .addSubcommand((sub) =>
      sub
        .setName('link')
        .setDescription('Link your Discord account to your Pterodactyl panel account.')
        .addStringOption((o) =>
          o.setName('email').setDescription('The email address on your Pterodactyl account').setRequired(true)
        )
        .addUserOption((o) =>
          o.setName('user').setDescription('(Staff only) Link this Discord user instead of yourself').setRequired(false)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('status')
        .setDescription("View a user's Pterodactyl server status.")
        .addUserOption((o) =>
          o.setName('user').setDescription('The Discord user to check (staff only)').setRequired(false)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('deploy')
        .setDescription('ADMIN: Create a Pterodactyl account (if needed) and deploy a Minecraft Paper server.')
        .addStringOption((o) =>
          o.setName('username').setDescription('Panel username (only used if creating a new account)').setRequired(true)
        )
        .addStringOption((o) =>
          o.setName('email').setDescription('Email address for the panel account').setRequired(true)
        )
        .addStringOption((o) =>
          o.setName('server_name').setDescription('Name for the new game server').setRequired(true)
        )
        .addIntegerOption((o) =>
          o.setName('ram_gb').setDescription('RAM to allocate, in GB').setRequired(true).setMinValue(1).setMaxValue(64)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('upgrade')
        .setDescription("ADMIN: Scale a server's RAM/CPU limits.")
        .addStringOption((o) =>
          o.setName('server_id_or_uuid').setDescription('The internal server ID or full/short UUID').setRequired(true)
        )
        .addIntegerOption((o) =>
          o.setName('new_ram_gb').setDescription('New RAM allocation, in GB').setRequired(true).setMinValue(1).setMaxValue(64)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('whitelist')
        .setDescription('ADMIN: Whitelist a user to bypass @everyone/@here quarantine.')
        .addUserOption((o) => o.setName('user').setDescription('User to whitelist').setRequired(true))
    )
    .addSubcommand((sub) =>
      sub
        .setName('unwhitelist')
        .setDescription('ADMIN: Remove a user from the ping-quarantine whitelist.')
        .addUserOption((o) => o.setName('user').setDescription('User to remove').setRequired(true))
    )

    // ---------------------------------------------------------------
    // Subcommand groups (each mirrors what used to be its own
    // top-level command with its own subcommands).
    // ---------------------------------------------------------------
    .addSubcommandGroup((group) =>
      group
        .setName('console')
        .setDescription('ADMIN: Send console commands or power actions to a server.')
        .addSubcommand((sub) =>
          sub
            .setName('command')
            .setDescription('Send a raw command to the server console')
            .addStringOption((o) =>
              o.setName('server_id').setDescription('Server identifier (e.g. s1 or full UUID)').setRequired(true)
            )
            .addStringOption((o) =>
              o.setName('command').setDescription('The console command to run (e.g. "op ItzNimish", "safeshutdown")').setRequired(true)
            )
        )
        .addSubcommand((sub) =>
          sub
            .setName('power')
            .setDescription("Control the server's power state")
            .addStringOption((o) =>
              o.setName('server_id').setDescription('Server identifier (e.g. s1 or full UUID)').setRequired(true)
            )
            .addStringOption((o) =>
              o
                .setName('action')
                .setDescription('Power action to perform')
                .setRequired(true)
                .addChoices(
                  { name: 'start', value: 'start' },
                  { name: 'stop', value: 'stop' },
                  { name: 'restart', value: 'restart' },
                  { name: 'kill (force-stop, use with care)', value: 'kill' }
                )
            )
        )
    )
    .addSubcommandGroup((group) =>
      group
        .setName('subuser')
        .setDescription('Grant or revoke console/power access to your server for another user.')
        .addSubcommand((sub) =>
          sub
            .setName('add')
            .setDescription('Grant a user console + power access to your server')
            .addUserOption((o) => o.setName('user').setDescription('Discord user to grant access to').setRequired(true))
            .addStringOption((o) => o.setName('server_id').setDescription('Server identifier (e.g. s1)').setRequired(true))
        )
        .addSubcommand((sub) =>
          sub
            .setName('remove')
            .setDescription("Revoke a user's console + power access to your server")
            .addUserOption((o) => o.setName('user').setDescription('Discord user to revoke access from').setRequired(true))
            .addStringOption((o) => o.setName('server_id').setDescription('Server identifier (e.g. s1)').setRequired(true))
        )
    )
    .addSubcommandGroup((group) =>
      group
        .setName('config')
        .setDescription("Edit your server's server.properties file.")
        .addSubcommand((sub) =>
          sub
            .setName('set')
            .setDescription('Set a key in server.properties')
            .addStringOption((o) => o.setName('server_id').setDescription('Server identifier (e.g. s1)').setRequired(true))
            .addStringOption((o) => o.setName('key').setDescription('Property key, e.g. difficulty').setRequired(true))
            .addStringOption((o) => o.setName('value').setDescription('New value, e.g. hard').setRequired(true))
        )
    )
    .addSubcommandGroup((group) =>
      group
        .setName('server')
        .setDescription('ADMIN: Renew, suspend, or delete a server.')
        .addSubcommand((sub) =>
          sub
            .setName('renew')
            .setDescription('Unsuspend a server, restoring access')
            .addStringOption((o) => o.setName('server_id').setDescription('Server identifier or numeric ID').setRequired(true))
        )
        .addSubcommand((sub) =>
          sub
            .setName('suspend')
            .setDescription('Suspend a server, blocking start/console access')
            .addStringOption((o) => o.setName('server_id').setDescription('Server identifier or numeric ID').setRequired(true))
        )
        .addSubcommand((sub) =>
          sub
            .setName('delete')
            .setDescription('PERMANENTLY delete a server and all its data')
            .addStringOption((o) => o.setName('server_id').setDescription('Server identifier or numeric ID').setRequired(true))
            .addStringOption((o) =>
              o.setName('confirm_name').setDescription("Type the server's exact name to confirm deletion").setRequired(true)
            )
        )
    )
    .addSubcommandGroup((group) =>
      group
        .setName('plugin')
        .setDescription('Install plugins onto a Minecraft server.')
        .addSubcommand((sub) =>
          sub
            .setName('install')
            .setDescription('Download and install the latest compatible version of a plugin')
            .addStringOption((o) => o.setName('server_id').setDescription('Server identifier (e.g. s1)').setRequired(true))
            .addStringOption((o) =>
              o.setName('plugin').setDescription('Modrinth/SpigotMC slug, URL, resource ID, or plugin name to search for').setRequired(true)
            )
            .addStringOption((o) =>
              o.setName('mc_version').setDescription('Override the auto-detected Minecraft version, e.g. 1.20.4').setRequired(false)
            )
        )
    ),

  /**
   * Routes to the right handler based on subcommand group (if any) + subcommand.
   */
  async execute(interaction) {
    const group = interaction.options.getSubcommandGroup(false);
    const sub = interaction.options.getSubcommand(false);

    try {
      if (!group) {
        switch (sub) {
          case 'help':
            return await help.execute(interaction);
          case 'link':
            return await link.execute(interaction);
          case 'status':
            return await status.execute(interaction);
          case 'deploy':
            return await deploy.execute(interaction);
          case 'upgrade':
            return await upgrade.execute(interaction);
          case 'whitelist':
          case 'unwhitelist': {
            if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
              return interaction.reply({ content: '❌ Administrator permission required.', ephemeral: true });
            }
            const user = interaction.options.getUser('user', true);

            if (sub === 'whitelist') {
              await updateJSON(WHITELIST_PATH, (whitelist) => {
                if (!whitelist.includes(user.id)) whitelist.push(user.id);
              });
              return interaction.reply({ content: `✅ **${user.tag}** whitelisted for \`@everyone\`/\`@here\` bypass.` });
            }

            await updateJSON(WHITELIST_PATH, (whitelist) => {
              const idx = whitelist.indexOf(user.id);
              if (idx !== -1) whitelist.splice(idx, 1);
            });
            return interaction.reply({ content: `🔒 **${user.tag}** removed from whitelist.` });
          }
          default:
            console.warn(`[/nothing] Unhandled top-level subcommand: ${sub}`);
            return;
        }
      }

      switch (group) {
        case 'console':
          return await consoleHandler.execute(interaction);
        case 'subuser':
          return await subuser.execute(interaction);
        case 'config':
          return await config.execute(interaction);
        case 'server':
          return await server.execute(interaction);
        case 'plugin':
          return await plugin.execute(interaction);
        default:
          console.warn(`[/nothing] Unhandled subcommand group: ${group}`);
          return;
      }
    } catch (err) {
      // Safety net - individual handlers already catch their own errors,
      // but this covers anything that slips through the dispatcher itself.
      console.error('[/nothing] Dispatcher error:', err);
      const payload = {
        content: 'An unexpected error occurred. Check the bot console logs.',
        ephemeral: true,
      };
      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(payload).catch(() => {});
      } else {
        await interaction.reply(payload).catch(() => {});
      }
    }
  },
};
