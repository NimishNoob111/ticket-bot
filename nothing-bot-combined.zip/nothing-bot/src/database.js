'use strict';

const path = require('node:path');
const fs = require('node:fs');
const Database = require('better-sqlite3');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_PATH = path.join(DATA_DIR, 'bot.sqlite');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

/** @type {import('better-sqlite3').Database} */
const db = new Database(DB_PATH);

// Sensible production pragmas: WAL for concurrent read/write safety,
// foreign_keys for integrity, synchronous=NORMAL for a good perf/safety balance.
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('synchronous = NORMAL');

let _initialized = false;

function initDatabase() {
  if (_initialized) return;
  _initialized = true;

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      discord_id        TEXT PRIMARY KEY,
      pterodactyl_id    INTEGER NOT NULL,
      pterodactyl_email TEXT NOT NULL,
      created_at        TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at        TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_users_pterodactyl_id
    ON users (pterodactyl_id);
  `);

  console.log(`[Database] SQLite initialized at ${DB_PATH}`);
}

// Run schema creation immediately on module load (idempotent thanks to
// "IF NOT EXISTS") so prepared statements below always have their table.
// index.js still calls initDatabase() explicitly for a clear startup log.
initDatabase();

// ---------------------------------------------------------------------------
// Prepared statements (compiled once, reused everywhere -> fast + safe)
// ---------------------------------------------------------------------------

const statements = {
  upsertUser: db.prepare(`
    INSERT INTO users (discord_id, pterodactyl_id, pterodactyl_email, updated_at)
    VALUES (@discord_id, @pterodactyl_id, @pterodactyl_email, datetime('now'))
    ON CONFLICT(discord_id) DO UPDATE SET
      pterodactyl_id    = excluded.pterodactyl_id,
      pterodactyl_email = excluded.pterodactyl_email,
      updated_at        = datetime('now')
  `),
  getUserByDiscordId: db.prepare(`
    SELECT * FROM users WHERE discord_id = ?
  `),
  getUserByPterodactylId: db.prepare(`
    SELECT * FROM users WHERE pterodactyl_id = ?
  `),
  deleteUser: db.prepare(`
    DELETE FROM users WHERE discord_id = ?
  `),
};

/**
 * Create or update a Discord <-> Pterodactyl mapping.
 */
function upsertUserMapping({ discordId, pterodactylId, pterodactylEmail }) {
  return statements.upsertUser.run({
    discord_id: discordId,
    pterodactyl_id: pterodactylId,
    pterodactyl_email: pterodactylEmail,
  });
}

function getUserByDiscordId(discordId) {
  return statements.getUserByDiscordId.get(discordId);
}

function getUserByPterodactylId(pterodactylId) {
  return statements.getUserByPterodactylId.get(pterodactylId);
}

function deleteUserMapping(discordId) {
  return statements.deleteUser.run(discordId);
}

module.exports = {
  db,
  initDatabase,
  upsertUserMapping,
  getUserByDiscordId,
  getUserByPterodactylId,
  deleteUserMapping,
};
