// ================= JSON STORE (race-condition-safe) =================
// Previously, every handler did loadJSON() -> mutate in memory -> saveJSON().
// If two interactions on the same file (e.g. claiming a ticket while another
// staffer closes it) landed close together, the second write could stomp on
// the first because both reads happened before either write. `updateJSON`
// below serializes all read-modify-write cycles per file path so that never
// happens, regardless of how many interactions come in concurrently.

const fs = require('fs');

const fileLocks = new Map();

function loadJSON(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function saveJSON(filePath, data) {
  // Write to a temp file then rename, so a crash mid-write can't corrupt the real file.
  const tmpPath = `${filePath}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2));
  fs.renameSync(tmpPath, filePath);
}

/**
 * Runs `mutator(data)` against the current contents of `filePath`, then persists
 * whatever `mutator` mutated `data` into, all while holding an exclusive lock on
 * that file path so concurrent callers queue up instead of racing.
 *
 * `mutator` may be async and may return a value, which `updateJSON` resolves to.
 */
function updateJSON(filePath, mutator) {
  const previous = fileLocks.get(filePath) || Promise.resolve();

  const run = previous.then(async () => {
    const data = loadJSON(filePath);
    const result = await mutator(data);
    saveJSON(filePath, data);
    return result;
  });

  // Keep the chain alive even if this call throws, so future callers aren't stuck forever,
  // but let the actual error still propagate to whoever awaited `run`.
  fileLocks.set(filePath, run.then(() => {}, () => {}));

  return run;
}

module.exports = { loadJSON, saveJSON, updateJSON };
