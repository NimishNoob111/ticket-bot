'use strict';

const { SlashCommandBuilder } = require('discord.js');
const music = require('../music');
const { checkVoiceState } = require('../musicGuards');

module.exports = {
  data: new SlashCommandBuilder().setName('skip').setDescription('Skip the current song'),

  async execute(interaction) {
    const denial = checkVoiceState(interaction, 'skip');
    if (denial) return interaction.reply(denial);

    const queue = music.getQueue(interaction.guild.id);
    if (!queue) return interaction.reply({ content: '❌ Nothing is playing right now.', ephemeral: true });

    const skipped = queue.songs[0];
    music.skip(interaction.guild.id);
    return interaction.reply({ content: skipped ? `⏭️ Skipped **${skipped.title}**.` : '⏭️ Skipped.' });
  },
};
