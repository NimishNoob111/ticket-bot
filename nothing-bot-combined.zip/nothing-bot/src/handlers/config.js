'use strict';

const { SlashCommandBuilder } = require('discord.js');
const ptero = require('../pterodactyl');
const { getUserByDiscordId } = require('../database');
const { successEmbed, errorEmbed } = require('../utils/embeds');
const { hasManageServerPermission } = require('../utils/permissions');

const PROPERTIES_FILE = '/server.properties';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('config')
    .setDescription("Edit your server's server.properties file.")
    .addSubcommand((sub) =>
      sub
        .setName('set')
        .setDescription('Set a key in server.properties')
        .addStringOption((o) =>
          o.setName('server_id').setDescription('Server identifier (e.g. s1)').setRequired(true)
        )
        .addStringOption((o) =>
          o.setName('key').setDescription('Property key, e.g. difficulty').setRequired(true)
        )
        .addStringOption((o) =>
          o.setName('value').setDescription('New value, e.g. hard').setRequired(true)
        )
    ),

  async execute(interaction) {
    const serverId = interaction.options.getString('server_id', true).trim();
    const key = interaction.options.getString('key', true).trim();
    const value = interaction.options.getString('value', true).trim();

    // Line breaks would let someone inject extra properties file lines.
    if (/[\r\n]/.test(key) || /[\r\n]/.test(value)) {
      await interaction.reply({
        embeds: [
          errorEmbed({
            title: 'Invalid Input',
            description: 'Key and value cannot contain line breaks.',
          }),
        ],
        ephemeral: true,
      });
      return;
    }

    await interaction.deferReply({ ephemeral: true });

    const callerMapping = getUserByDiscordId(interaction.user.id);
    if (!callerMapping) {
      await interaction.editReply({
        embeds: [
          errorEmbed({ title: 'Not Linked', description: 'You need to `/nothing link` your account first.' }),
        ],
      });
      return;
    }

    const serverResult = await ptero.findServerByIdentifier(serverId);
    if (!serverResult.ok) {
      await interaction.editReply({
        embeds: [errorEmbed({ title: 'Server Not Found', description: serverResult.error })],
      });
      return;
    }

    const server = serverResult.data;
    const isOwner = server.attributes.user === callerMapping.pterodactyl_id;

    if (!isOwner && !hasManageServerPermission(interaction)) {
      await interaction.editReply({
        embeds: [
          errorEmbed({
            title: 'Not The Server Owner',
            description: "Only the server owner (or an admin) can edit this server's configuration.",
          }),
        ],
      });
      return;
    }

    const identifier = server.attributes.identifier;

    try {
      const fileResult = await ptero.readFile(identifier, PROPERTIES_FILE);

      let lines;
      let oldValue = null;

      if (fileResult.ok) {
        const content =
          typeof fileResult.data === 'string' ? fileResult.data : JSON.stringify(fileResult.data);
        lines = content.split(/\r?\n/);

        const idx = lines.findIndex((line) => line.trim().startsWith(`${key}=`));
        if (idx !== -1) {
          oldValue = lines[idx].slice(lines[idx].indexOf('=') + 1);
          lines[idx] = `${key}=${value}`;
        } else {
          lines.push(`${key}=${value}`);
        }
      } else {
        // File doesn't exist yet (or couldn't be read) - start fresh with just this key.
        lines = [`${key}=${value}`];
      }

      const newContent = lines.join('\n');
      const writeResult = await ptero.writeFile(identifier, PROPERTIES_FILE, newContent);

      if (!writeResult.ok) {
        await interaction.editReply({
          embeds: [errorEmbed({ title: 'Failed To Write Config', description: writeResult.error })],
        });
        return;
      }

      await interaction.editReply({
        embeds: [
          successEmbed({
            title: 'Configuration Updated',
            description: `Updated \`${key}\` in **${server.attributes.name}**'s \`server.properties\`.\n_A server restart is usually required for this to take effect._`,
            fields: [
              { name: 'Old Value', value: oldValue ?? '_(not previously set)_', inline: true },
              { name: 'New Value', value, inline: true },
            ],
          }),
        ],
      });
    } catch (err) {
      console.error('[/config] Unexpected error:', err);
      await interaction.editReply({
        embeds: [
          errorEmbed({
            description: 'An unexpected error occurred. Check the bot console logs.',
          }),
        ],
      });
    }
  },
};
