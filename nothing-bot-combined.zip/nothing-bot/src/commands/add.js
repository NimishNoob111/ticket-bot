'use strict';

const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');
const { loadJSON } = require('../jsonStore');
const { TICKETS_PATH } = require('../tickets');
const { isStaffInteraction } = require('../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('add')
    .setDescription('Add a user to the current ticket channel')
    .addUserOption((opt) => opt.setName('user').setDescription('User to add').setRequired(true)),

  async execute(interaction) {
    const tickets = loadJSON(TICKETS_PATH);
    const ticketInfo = tickets[interaction.channel.id];
    if (!ticketInfo) {
      return interaction.reply({ content: '❌ This command may only be used inside a ticket channel.', ephemeral: true });
    }

    const isOwner = interaction.user.id === ticketInfo.owner;
    if (!isStaffInteraction(interaction) && !isOwner) {
      return interaction.reply({ content: '❌ Only staff or the ticket owner can manage ticket access.', ephemeral: true });
    }

    const user = interaction.options.getUser('user', true);
    await interaction.channel.permissionOverwrites.edit(user.id, {
      ViewChannel: true, SendMessages: true, ReadMessageHistory: true,
    });
    return interaction.reply({ content: `✅ **${user.tag}** added to this ticket.` });
  },
};
