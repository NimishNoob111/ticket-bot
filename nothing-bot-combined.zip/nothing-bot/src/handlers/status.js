'use strict';

const { SlashCommandBuilder } = require('discord.js');
const ptero = require('../pterodactyl');
const { getUserByDiscordId } = require('../database');
const { infoEmbed, errorEmbed } = require('../utils/embeds');
const { hasManageServerPermission } = require('../utils/permissions');

/** Convert MB to a "512 MB" or "4 GB" style string. */
function formatMebibytes(mb) {
  if (mb === 0) return 'Unlimited';
  if (mb >= 1024) return `${(mb / 1024).toFixed(mb % 1024 === 0 ? 0 : 1)} GB`;
  return `${mb} MB`;
}

function formatAllocation(server) {
  const relationships = server.attributes.relationships;
  const allocation = relationships?.allocations?.data?.find(
    (a) => a.attributes.id === server.attributes.allocation
  ) ?? relationships?.allocations?.data?.[0];

  if (!allocation) return 'N/A';

  const ip = allocation.attributes.ip_alias || allocation.attributes.ip;
  return `${ip}:${allocation.attributes.port}`;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('status')
    .setDescription("View a user's Pterodactyl server status.")
    .addUserOption((option) =>
      option
        .setName('user')
        .setDescription('The Discord user to check (staff only)')
        .setRequired(false)
    ),

  async execute(interaction) {
    const mentionedUser = interaction.options.getUser('user');

    if (mentionedUser && mentionedUser.id !== interaction.user.id) {
      if (!hasManageServerPermission(interaction)) {
        await interaction.reply({
          embeds: [
            errorEmbed({
              title: 'Permission Denied',
              description:
                'You need the **Manage Server** or **Administrator** permission to check other users\' server status.',
            }),
          ],
          ephemeral: true,
        });
        return;
      }
    }

    const targetUser = mentionedUser ?? interaction.user;

    await interaction.deferReply();

    try {
      const mapping = getUserByDiscordId(targetUser.id);

      if (!mapping) {
        await interaction.editReply({
          embeds: [
            errorEmbed({
              title: 'Not Linked',
              description:
                targetUser.id === interaction.user.id
                  ? 'You haven\'t linked your Pterodactyl account yet. Use `/nothing link <email>` first.'
                  : `**${targetUser.tag}** hasn't linked a Pterodactyl account yet.`,
            }),
          ],
        });
        return;
      }

      const result = await ptero.getServersByUserId(mapping.pterodactyl_id);

      if (!result.ok) {
        await interaction.editReply({
          embeds: [
            errorEmbed({
              title: 'Pterodactyl API Error',
              description: result.error,
            }),
          ],
        });
        return;
      }

      const servers = result.data;

      if (servers.length === 0) {
        await interaction.editReply({
          embeds: [
            infoEmbed({
              title: `${targetUser.tag} — Server Status`,
              description: 'This account owns **0 servers**.',
            }),
          ],
        });
        return;
      }

      const fields = servers.slice(0, 20).map((server) => {
        const attrs = server.attributes;
        const shortId = attrs.identifier.slice(0, 8);
        return {
          name: `🖥️ ${attrs.name}`,
          value: [
            `**Identifier:** \`${shortId}\``,
            `**Node ID:** ${attrs.node}`,
            `**RAM:** ${formatMebibytes(attrs.limits.memory)}`,
            `**Disk:** ${formatMebibytes(attrs.limits.disk)}`,
            `**Allocation:** ${formatAllocation(server)}`,
          ].join('\n'),
          inline: true,
        };
      });

      await interaction.editReply({
        embeds: [
          infoEmbed({
            title: `${targetUser.tag} — Server Status`,
            description: `**Total servers owned:** ${servers.length}`,
            fields,
          }),
        ],
      });
    } catch (err) {
      console.error('[/status] Unexpected error:', err);
      await interaction.editReply({
        embeds: [
          errorEmbed({
            description: 'An unexpected error occurred. Check the bot console logs.',
          }),
        ],
      });
    }
  },
};
