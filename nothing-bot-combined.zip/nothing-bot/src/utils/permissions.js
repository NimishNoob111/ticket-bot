'use strict';

const { PermissionFlagsBits } = require('discord.js');

/**
 * Discord.js has no literal "ManageServer" flag - the panel calls the
 * "Manage Server" permission `ManageGuild` internally. We check both that
 * and Administrator, since either should grant elevated bot access.
 */
function hasManageServerPermission(interaction) {
  if (!interaction.inGuild()) return false;

  const memberPermissions = interaction.member?.permissions;
  if (!memberPermissions) return false;

  return (
    memberPermissions.has(PermissionFlagsBits.Administrator) ||
    memberPermissions.has(PermissionFlagsBits.ManageGuild)
  );
}

/**
 * Checks whether the interacting member has the role configured via
 * ALLOWED_ROLE_ID in .env. Administrators always pass, regardless of role,
 * so server owners/admins never lock themselves out.
 *
 * If ALLOWED_ROLE_ID is not set, this always returns true (no restriction).
 */
function hasAllowedRole(interaction) {
  const requiredRoleId = process.env.ALLOWED_ROLE_ID;

  // No role configured -> everyone (subject to each command's own checks) can use it.
  if (!requiredRoleId) return true;

  if (!interaction.inGuild()) return false;

  const memberPermissions = interaction.member?.permissions;
  if (memberPermissions?.has(PermissionFlagsBits.Administrator)) return true;

  return interaction.member?.roles?.cache?.has(requiredRoleId) ?? false;
}

/**
 * Ticket/moderation "staff" check: true if the member has Administrator, OR
 * has the role configured via STAFF_ROLE_ID in .env.
 * Works against both interactions (has .member) and raw guild members.
 */
function isStaffMember(member) {
  if (!member) return false;
  const isAdmin = member.permissions?.has(PermissionFlagsBits.Administrator);
  const staffRoleId = process.env.STAFF_ROLE_ID;
  const hasStaffRole = staffRoleId ? member.roles?.cache?.has(staffRoleId) : false;
  return Boolean(isAdmin || hasStaffRole);
}

/** Same check, but takes an interaction directly. */
function isStaffInteraction(interaction) {
  return isStaffMember(interaction.member);
}

module.exports = {
  hasManageServerPermission,
  hasAllowedRole,
  isStaffMember,
  isStaffInteraction,
};
