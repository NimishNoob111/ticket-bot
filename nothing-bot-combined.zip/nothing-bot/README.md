# Nothing — Combined Discord Bot

Your two bots merged into **one** Discord application: the ticket /
moderation / music bot, plus the Pterodactyl panel-control bot. One
`DISCORD_TOKEN`, one process, one `npm start`.

## What changed from your two separate projects

### Node config (the reason you asked for this)
- Deploying used to be hardcoded to a single `DEFAULT_NODE_ID` (node 1).
  That node is gone now, so it's replaced with **`NODE_IDS`** in `.env` —
  a comma-separated list the bot tries in order until it finds a node with
  a free allocation. It's already set to `NODE_IDS=2,3`.
- `/nothing deploy` (and `/nothing upgrade`, unaffected) now report back
  *which* node it actually landed the server on, instead of always
  printing the old static node number.
- If both nodes are full, you get one clear error listing why each node
  was skipped, instead of a single opaque failure.

### The two bots' `/nothing` command collision
Both bots separately registered a top-level `/nothing` command with
different subcommands — that can't coexist as two separate Discord
applications sharing a command name cleanly, and definitely can't once
they're one process. They're merged into a single `/nothing` with all
subcommands from both: `help`, `link`, `status`, `deploy`, `upgrade`,
`whitelist`, `unwhitelist`, plus the `console`/`subuser`/`config`/`server`/
`plugin` subcommand groups.

### Other bugs fixed along the way
- **Dead cookies config**: your old `.env` had `YOUTUBE_COOKIE=...`, but
  `music.js` only ever read `YOUTUBE_COOKIES_FILE` — so your YouTube
  cookies were silently never applied. Fixed the variable name in `.env`.
- **Unused `QUARANTINE_ROLE_ID`**: this was in your `.env` but the code
  always looked up the quarantine role by the literal name `"Quarantine"`
  instead, ignoring the ID. Now it checks `QUARANTINE_ROLE_ID` first and
  falls back to the name search — more robust if that role ever gets
  renamed.
- **Dead files removed**: `ticket-auto-responder.js` and
  `ticket-autoresponder.js` were two abandoned draft versions of the
  auto-greeter, neither of which was ever wired into `index.js` — the
  ticket bot's real (and better) auto-greeter logic was already inline.
  Not carried over; nothing used them.
- Staff checks across tickets/quarantine/whitelist are now one shared
  `isStaffMember()` helper (Administrator OR `STAFF_ROLE_ID`) instead of
  being re-typed slightly differently in half a dozen places.

### Music engine replaced entirely
The old hand-rolled `music.js` (relying on a system `yt-dlp` binary via
`YTDLP_PATH`) is gone. In its place: a full, actively-maintained music
engine (MIT-licensed, originally the "MusicBot"/Beatra project) that
bundles its own `yt-dlp` binary via `youtube-dl-exec` — no system install
or `PATH` config needed — and supports YouTube, Spotify (resolved to a
YouTube match — Spotify audio is DRM'd, no bot streams it directly),
SoundCloud, and direct audio links, plus lyrics, per-track filters, and
session persistence across restarts.

It lives under `src/musicbot/` (kept namespaced/self-contained rather than
interleaved with the rest of the code, since it's a large third-party
project — makes it easy to update independently later). Music commands are
now `/play`, `/search`, `/nowplaying`, `/help`, `/language` — the old flat
`/skip` `/stop` `/pause` `/resume` `/queue` `/volume` `/loop` `/disconnect`
commands are gone, **replaced by buttons** on the now-playing embed
(pause/skip/stop/queue/shuffle/volume/loop/autoplay/lyrics) — click
instead of typing a command.

**Bugs fixed while integrating it:**
- Its `src/commandLoader.js` runs a full slash-command **overwrite** as a
  side effect of merely being `require()`d — on every boot it would wipe
  out every other command (`/nothing`, `/ticket-panel`, etc.) from Discord,
  leaving only its own 5. **Deliberately not copied over** — `deploy-commands.js`
  already handles registering the full combined command set correctly.
- Its button and modal/select-menu handlers didn't check whether an
  interaction's `customId` actually belonged to them before acting — any
  unrecognized button (including the ticket system's `ticket_claim`,
  `ticket_close`, etc.) fell through into "join a voice channel first" /
  "no music playing" replies, and any unrecognized modal or select menu
  (including the ticket system's own ticket-creation form) got hijacked
  with an "unknown modal" error. Both now check their own `customId`
  prefixes first and leave anything else alone.
- Two files initialized their language database with a bare relative path
  (`'database/languages'`), which resolves against whatever directory the
  process happens to be started from — worked by luck in the original
  standalone repo, would've quietly pointed at the wrong folder (or
  silently created an empty one) once nested inside this project. Both
  now resolve relative to their own file location instead.
- Its `postinstall` script (auto-updates the bundled yt-dlp binary) assumed
  it lived at the project root; fixed the relative path now that it's
  nested three folders deep.

**New env vars** (see `.env`/`.env.example`): `SPOTIFY_CLIENT_ID`,
`SPOTIFY_CLIENT_SECRET` (free at the
[Spotify developer dashboard](https://developer.spotify.com/dashboard)),
optionally `GENIUS_CLIENT_ID`/`GENIUS_CLIENT_SECRET` for lyrics, and
`COOKIES_FILE`/`COOKIES_FROM_BROWSER` (replacing the old, never-actually-working
`YOUTUBE_COOKIES_FILE`) — `COOKIES_FILE=./cookies.txt` is already set,
pointing at your existing cookies file.

### ⚠️ Your bot token was exposed
Your uploaded `bot_backup.zip` had a live `DISCORD_TOKEN` sitting in plain
text `.env`. Treat it as compromised — **regenerate it** in the
[Discord Developer Portal](https://discord.com/developers/applications) →
your app → Bot → Reset Token, and put the *new* token in `.env`. I left
`DISCORD_TOKEN` blank in the generated `.env` on purpose so the old one
doesn't get reused anywhere. Same goes for `cookies.txt` /
`youtube-cookies.txt` if that YouTube account matters to you — a leaked
cookies file lets someone else act as that logged-in session.

## Project layout

```
nothing-bot/
├── package.json
├── .env                 # prefilled with your real ticket-bot config (token blanked, see above)
├── .env.example          # clean template, safe to share
├── cookies.txt            # your YouTube cookies (gitignored, don't share)
├── data/
│   ├── bad-words.json          # your existing filter list
│   ├── swear-offenses.json     # your existing offense counts
│   ├── tickets.json            # your existing ticket history
│   ├── whitelist.json          # your existing ping-whitelist
│   └── bot.sqlite               # auto-created — Discord<->Pterodactyl account links
└── src/
    ├── index.js              # single entrypoint: client, command loader, event wiring
    ├── deploy-commands.js    # registers every command in src/commands + src/musicbot/commands
    ├── database.js           # SQLite — Pterodactyl account linking
    ├── jsonStore.js          # race-safe JSON read/modify/write for tickets/whitelist/offenses
    ├── pterodactyl.js        # Pterodactyl API client (now with multi-node allocation lookup)
    ├── plugins.js            # Modrinth/SpigotMC plugin resolution for /nothing plugin install
    ├── musicbot/             # third-party music engine, kept self-contained (see below)
    │   ├── config.js
    │   ├── src/               # YouTube/Spotify/SoundCloud/DirectLink resolvers, player engine, embeds
    │   ├── commands/          # /play, /search, /nowplaying, /help, /language
    │   ├── events/            # button + modal/select-menu handlers for the now-playing controls
    │   ├── database/          # its own language-preference + session-persistence store
    │   └── languages/         # 23 bundled UI translations
    ├── tickets/index.js      # ticket panel/modal/button logic + config
    ├── moderation/index.js   # profanity filter + anti-mass-ping auto-quarantine
    ├── handlers/             # Pterodactyl command implementations (help/link/status/deploy/...)
    ├── utils/
    │   ├── embeds.js
    │   └── permissions.js    # both permission systems: ManageGuild/Admin (ptero) + staff role (tickets)
    └── commands/              # one file per slash command, auto-loaded by index.js
```

## 1. Prerequisites

- Node.js **20+**
- A Discord Application + Bot ([discord.com/developers/applications](https://discord.com/developers/applications))
- A Pterodactyl panel with an **Application API key** (Admin → API
  Credentials — different from a user's personal Client API key)
- Optional but recommended: a free
  [Spotify API app](https://developer.spotify.com/dashboard) (Client ID +
  Secret) so `/play` works with Spotify links, and a free
  [Genius API client](https://genius.com/api-clients) for lyrics.
- `yt-dlp` and `ffmpeg` are bundled automatically via npm
  (`youtube-dl-exec` and `ffmpeg-static`) — nothing to install system-wide.

## 2. Install

```bash
cd nothing-bot
npm install
```

`better-sqlite3` compiles a small native addon on install — if it fails,
make sure `python3`, `make`, and a C++ toolchain are available
(`build-essential` on Debian/Ubuntu), or use a Node LTS version (18/20/22)
that has prebuilt binaries.

## 3. Configure

`.env` is already filled in with your real ticket-bot settings (categories,
staff role, etc.) — you still need to:

1. Paste a **new, regenerated** `DISCORD_TOKEN` (see the warning above).
2. Fill in `PTERO_URL` and `PTERO_APP_KEY` for your panel.
3. Double check `DEFAULT_NEST_ID` / `DEFAULT_EGG_ID` match your panel's
   Minecraft/Paper nest+egg (Admin → Nests), and that `DEFAULT_DOCKER_IMAGE`
   / `DEFAULT_STARTUP_CMD` match your egg's actual config.
4. `NODE_IDS=2,3` is already set — add/remove node IDs there if that
   changes again in the future.
5. Optional: set `PTERO_CLIENT_KEY` (a personal Client API key from an
   account that owns/subusers your servers) to enable `/nothing console`
   and the power-action part of it. Without it, those two subcommands
   reply with a clear "not configured" message instead of crashing.
6. Optional: set `SPOTIFY_CLIENT_ID`/`SPOTIFY_CLIENT_SECRET` for Spotify
   link support in `/play`, and `GENIUS_CLIENT_ID`/`GENIUS_CLIENT_SECRET`
   for lyrics. `COOKIES_FILE=./cookies.txt` is already set, pointing at
   your existing cookies file (helps avoid YouTube bot-detection walls).

## 4. Register slash commands

```bash
npm run deploy-commands
```

With `GUILD_ID` set (it already is, from your old bot), commands register
instantly to that one server. Remove `GUILD_ID` for global registration
(works everywhere the bot is added, but can take up to an hour to
propagate).

## 5. Run

```bash
npm start
```

or, for auto-restart on file changes during development:

```bash
npm run dev
```

## Commands

### Pterodactyl (`/nothing ...`)
| Command | Description |
|---|---|
| `/nothing help` | Lists all commands |
| `/nothing link <email>` | Link your Discord account to your Pterodactyl account |
| `/nothing status [user]` | Server stats for yourself, or (staff) another user |
| `/nothing deploy <username> <email> <server_name> <ram_gb>` | ADMIN: create account + deploy a Paper server on the first node (2 or 3) with room |
| `/nothing upgrade <server_id_or_uuid> <new_ram_gb>` | ADMIN: rescale RAM/CPU |
| `/nothing whitelist <user>` / `unwhitelist <user>` | ADMIN: bypass list for the `@everyone`/`@here` auto-quarantine |
| `/nothing console command\|power <server_id> ...` | ADMIN: raw console commands / start-stop-restart-kill |
| `/nothing subuser add\|remove <user> <server_id>` | Grant/revoke console+power access to *your* server |
| `/nothing config set <server_id> <key> <value>` | Edit `server.properties` |
| `/nothing server renew\|suspend\|delete <server_id>` | ADMIN: server lifecycle |
| `/nothing plugin install <server_id> <plugin>` | Install a plugin from Modrinth/SpigotMC |

### Tickets
| Command | Description |
|---|---|
| `/ticket-panel` | Deploy the ticket-creation panel in the current channel |
| `/add <user>` / `/remove <user>` | Manage who can see the current ticket |
| Claim / Close / Reopen / Delete buttons | On every ticket, for staff (or the owner, for Reopen) |

### Moderation
| Command | Description |
|---|---|
| `/attack <user>` | Manually quarantine a user (full lockdown) |
| `/release <user>` | Undo quarantine |
| Profanity filter | Auto-deletes + escalating timeouts → ban on repeat offenses (message-based, no command) |
| Anti-mass-ping | Auto-quarantines anyone who pings `@everyone`/`@here` without being whitelisted |

### Music
| Command | Description |
|---|---|
| `/play <query>` | YouTube search, YouTube/Spotify/SoundCloud link, or direct audio link |
| `/search <query>` | Search YouTube and pick a result from a list |
| `/nowplaying` | Shows the current track |
| `/help` | Music-specific command/feature help |
| `/language` | ADMIN (Manage Server): change the bot's reply language for this server |

Everything else — pause, skip, stop, queue, shuffle, volume, loop,
autoplay, lyrics — is on **buttons** attached to the now-playing message,
not separate slash commands.

## Error handling

Every Pterodactyl API call goes through `pterodactyl.js`'s `safeRequest()`,
which never throws — it returns `{ ok, data }` or `{ ok, error }` with the
panel's actual reported reason. Any other unexpected error is still caught
by a top-level handler in `index.js` so one broken command can't take the
whole bot down or leave an interaction hanging forever.

## Extending

- **New command:** add a file to `src/commands/` exporting `{ data, execute }`, then `npm run deploy-commands`.
- **New node:** just add its ID to `NODE_IDS` in `.env` — no code changes needed.
- **Different game egg:** update `DEFAULT_NEST_ID`/`DEFAULT_EGG_ID` in `.env`, and the `docker_image`/`startup`/`environment` block in `src/handlers/deploy.js`.
