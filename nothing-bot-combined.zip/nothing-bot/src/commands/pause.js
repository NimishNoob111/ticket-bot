'use strict';

const { SlashCommandBuilder } = require('discord.js');
const music = require('../music');
const { checkVoiceState } = require('../musicGuards');

module.exports = {
  data: new SlashCommandBuilder().setName('pause').setDescription('Pause the current song'),

  async execute(interaction) {
    const denial = checkVoiceState(interaction, 'pause');
    if (denial) return interaction.reply(denial);

    const queue = music.getQueue(interaction.guild.id);
    if (!queue) return interaction.reply({ content: '❌ Nothing is playing right now.', ephemeral: true });

    music.pause(interaction.guild.id);
    return interaction.reply({ content: '⏸️ Paused.' });
  },
};
