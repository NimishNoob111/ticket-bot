'use strict';

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const ptero = require('../pterodactyl');
const { successEmbed, errorEmbed, warnEmbed } = require('../utils/embeds');
const { hasManageServerPermission } = require('../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('server')
    .setDescription('ADMIN: Renew, suspend, or delete a server.')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand((sub) =>
      sub
        .setName('renew')
        .setDescription('Unsuspend a server, restoring access')
        .addStringOption((o) =>
          o.setName('server_id').setDescription('Server identifier or numeric ID').setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('suspend')
        .setDescription('Suspend a server, blocking start/console access')
        .addStringOption((o) =>
          o.setName('server_id').setDescription('Server identifier or numeric ID').setRequired(true)
        )
    )
    .addSubcommand((sub) =>
      sub
        .setName('delete')
        .setDescription('PERMANENTLY delete a server and all its data')
        .addStringOption((o) =>
          o.setName('server_id').setDescription('Server identifier or numeric ID').setRequired(true)
        )
        .addStringOption((o) =>
          o
            .setName('confirm_name')
            .setDescription("Type the server's exact name to confirm deletion")
            .setRequired(true)
        )
    ),

  async execute(interaction) {
    if (!hasManageServerPermission(interaction)) {
      await interaction.reply({
        embeds: [
          errorEmbed({
            title: 'Permission Denied',
            description: 'This command requires the **Administrator** permission.',
          }),
        ],
        ephemeral: true,
      });
      return;
    }

    const subcommand = interaction.options.getSubcommand();
    const serverId = interaction.options.getString('server_id', true).trim();

    await interaction.deferReply();

    try {
      const resolved = await ptero.findServerByIdentifier(serverId);
      if (!resolved.ok) {
        await interaction.editReply({
          embeds: [errorEmbed({ title: 'Server Not Found', description: resolved.error })],
        });
        return;
      }

      const server = resolved.data;
      const numericId = server.attributes.id;
      const serverName = server.attributes.name;

      if (subcommand === 'renew') {
        const result = await ptero.unsuspendServer(numericId);
        if (!result.ok) {
          await interaction.editReply({
            embeds: [errorEmbed({ title: 'Failed To Renew Server', description: result.error })],
          });
          return;
        }

        await interaction.editReply({
          embeds: [
            successEmbed({
              title: 'Server Renewed',
              description: `**${serverName}** has been unsuspended and access is restored.`,
            }),
          ],
        });
        return;
      }

      if (subcommand === 'suspend') {
        const result = await ptero.suspendServer(numericId);
        if (!result.ok) {
          await interaction.editReply({
            embeds: [errorEmbed({ title: 'Failed To Suspend Server', description: result.error })],
          });
          return;
        }

        await interaction.editReply({
          embeds: [
            warnEmbed({
              title: 'Server Suspended',
              description: `**${serverName}** has been suspended. The owner can no longer start it or use the console until renewed.`,
            }),
          ],
        });
        return;
      }

      if (subcommand === 'delete') {
        const confirmName = interaction.options.getString('confirm_name', true).trim();

        if (confirmName.toLowerCase() !== serverName.toLowerCase()) {
          await interaction.editReply({
            embeds: [
              errorEmbed({
                title: 'Confirmation Mismatch',
                description: `\`confirm_name\` must exactly match the server's name **${serverName}** to proceed. Nothing was deleted.`,
              }),
            ],
          });
          return;
        }

        const result = await ptero.deleteServer(numericId);
        if (!result.ok) {
          await interaction.editReply({
            embeds: [errorEmbed({ title: 'Failed To Delete Server', description: result.error })],
          });
          return;
        }

        await interaction.editReply({
          embeds: [
            successEmbed({
              title: 'Server Deleted',
              description: `**${serverName}** and all of its data have been permanently deleted.`,
            }),
          ],
        });
        return;
      }
    } catch (err) {
      console.error('[/server] Unexpected error:', err);
      await interaction.editReply({
        embeds: [
          errorEmbed({
            description: 'An unexpected error occurred. Check the bot console logs.',
          }),
        ],
      });
    }
  },
};
