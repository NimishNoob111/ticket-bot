'use strict';

const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { ensureQuarantineRole } = require('../moderation');
const { isStaffInteraction } = require('../utils/permissions');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('attack')
    .setDescription('Manually quarantine a user (full lockdown)')
    .addUserOption((opt) => opt.setName('user').setDescription('User to quarantine').setRequired(true)),

  async execute(interaction, { logAction }) {
    if (!isStaffInteraction(interaction)) {
      return interaction.reply({ content: '❌ Staff only.', ephemeral: true });
    }

    const target = interaction.options.getUser('user', true);
    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) {
      return interaction.reply({ content: '❌ Could not find that member in this server.', ephemeral: true });
    }

    const role = await ensureQuarantineRole(interaction.guild);
    if (!role) {
      return interaction.reply({ content: '❌ Quarantine role could not be created/found.', ephemeral: true });
    }

    await member.roles.add(role).catch(() => {});

    const embed = new EmbedBuilder()
      .setColor(0xE02424)
      .setTitle('🔒 Manual Quarantine Executed')
      .setDescription(`**User Quarantined:** ${target} has been manually quarantined by ${interaction.user}.`)
      .addFields({ name: 'Restrictions Applied', value: '👁️ No channel visibility\n💬 No messaging\n🔗 No invite creation\n🎙️ No voice access' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
    return logAction(interaction.guild, new EmbedBuilder()
      .setColor(0xE02424)
      .setTitle('🔒 Manual Quarantine (/attack)')
      .setDescription(`**Target:** ${target} (${target.id})\n**By:** ${interaction.user}`)
      .setTimestamp());
  },
};
