'use strict';

const music = require('./music');

// Commands that don't require the invoker to be in a voice channel at all.
const NO_VOICE_REQUIRED = new Set(['queue', 'nowplaying']);

/**
 * Shared guard for every music command: checks the invoker is in a voice
 * channel (except /queue and /nowplaying), and if the bot already has an
 * active queue, that the invoker is in the *same* channel as the bot (so a
 * random person in another VC can't stop/skip someone else's session).
 *
 * Returns null if the check passes, or a reply payload to send if it fails.
 */
function checkVoiceState(interaction, commandName) {
  const voiceChannel = interaction.member.voice?.channel;
  const queue = music.getQueue(interaction.guild.id);
  const needsVoice = !NO_VOICE_REQUIRED.has(commandName);

  if (needsVoice && !voiceChannel) {
    return { content: '❌ Join a voice channel first.', ephemeral: true };
  }
  if (needsVoice && queue && voiceChannel.id !== queue.voiceChannelId) {
    return { content: '❌ You need to be in the same voice channel as the bot.', ephemeral: true };
  }
  return null;
}

module.exports = { checkVoiceState };
