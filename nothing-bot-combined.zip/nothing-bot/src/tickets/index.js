'use strict';

const path = require('node:path');
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ChannelType,
  StringSelectMenuBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  PermissionsBitField,
} = require('discord.js');
const { loadJSON, updateJSON } = require('../jsonStore');
const { isStaffMember } = require('../utils/permissions');

const TICKETS_PATH = path.join(__dirname, '..', '..', 'data', 'tickets.json');

// ---------------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------------

const TICKET_TYPES = {
  support: { label: 'General Support', emoji: '💬', categoryEnv: 'CATEGORY_SUPPORT' },
  billing: { label: 'Billing', emoji: '💳', categoryEnv: 'CATEGORY_BILLING' },
  reports: { label: 'Report', emoji: '🚨', categoryEnv: 'CATEGORY_REPORTS' },
};

const TICKET_MODALS = {
  support: {
    title: 'General Support Ticket',
    fields: [
      { id: 'problem', label: 'What is your problem?', style: TextInputStyle.Paragraph, required: true },
    ],
  },
  billing: {
    title: 'Billing Ticket',
    fields: [
      { id: 'purchase', label: 'What do you want to purchase?', style: TextInputStyle.Paragraph, required: true },
    ],
  },
  reports: {
    title: 'Report Ticket',
    fields: [
      { id: 'target', label: 'Who are you reporting? (Player/Staff)', style: TextInputStyle.Short, required: true },
      { id: 'reason', label: 'Reason / Evidence', style: TextInputStyle.Paragraph, required: true },
    ],
  },
};

const TICKET_PANEL_DESCRIPTION = `Welcome to our support system! Please select the appropriate category before opening a ticket.

**💬 General Support**
Need help with our services, panel, Discord, or have a general question? Open this ticket for any non-purchase related assistance.

**💳 Billing**
Planning to purchase a VPS, Minecraft Server, or have questions regarding payments, invoices, upgrades, or refunds? Open a Billing ticket.

**🚨 Report**
Report a player, staff member, or any rule violation. Please provide valid evidence (screenshots, videos, or logs) to help us investigate.

⚠️ **Important Notice**
• Open tickets only for genuine reasons.
• Creating unnecessary, troll, or spam tickets may result in a ban without prior warning.
• Please be patient after opening a ticket. Our average response time is **within 1 hour**, though it may take longer during peak hours.`;

// Matches "help", "support", "staff", or close variants — used for the
// General Support follow-up ping.
const SUPPORT_KEYWORDS = /\b(help|support|staff|assist(?:ance)?|issue|problem)\b/i;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function getStaffMention() {
  return process.env.STAFF_ROLE_ID ? `<@&${process.env.STAFF_ROLE_ID}>` : '@staff';
}

function buildAutoGreeting(type, userId) {
  const mention = userId ? `<@${userId}>` : 'there';
  const staffMention = getStaffMention();

  if (type === 'support') return `Hello ${mention}, how may I help you today?`;
  if (type === 'billing') return `Hello ${mention}, what would you like to purchase today? I'm pinging staff now ${staffMention}`;
  if (type === 'reports') return `Hello ${mention}, what would you like to report? Pinging staff now ${staffMention}`;
  return null;
}

// Finds a user's currently open (non-closed) ticket channel, regardless of type.
// Used to enforce "one active ticket at a time" across Support/Billing/Report.
function findOpenTicketChannelId(ownerId) {
  const tickets = loadJSON(TICKETS_PATH);
  for (const [channelId, info] of Object.entries(tickets)) {
    if (info.owner === ownerId && info.status !== 'closed') return channelId;
  }
  return null;
}

// Builds the live ticket status embed shown at the top of every ticket channel
function buildTicketEmbed(meta, ticketInfo) {
  const statusLine = ticketInfo.status === 'closed' ? '🔴 Closed' : '🟢 Active';
  const createdLine = `<t:${Math.floor(ticketInfo.createdAt / 1000)}:F> (<t:${Math.floor(ticketInfo.createdAt / 1000)}:R>)`;
  const claimedLine = ticketInfo.claimed ? `<@${ticketInfo.claimedBy}>` : 'Unclaimed';

  const embed = new EmbedBuilder()
    .setColor(ticketInfo.status === 'closed' ? 0x71717A : 0x2B6CB0)
    .setTitle(`${meta.emoji} ${meta.label} Ticket`)
    .setDescription(`Welcome <@${ticketInfo.owner}>. Support staff will be with you shortly.\n\nUse the controls below to manage this ticket.`)
    .addFields(
      { name: 'Status', value: statusLine, inline: true },
      { name: 'Claimed By', value: claimedLine, inline: true },
      { name: 'Created', value: createdLine, inline: false },
    )
    .setTimestamp();

  if (ticketInfo.details) {
    embed.addFields({ name: '📝 Submitted Info', value: ticketInfo.details });
  }

  if (ticketInfo.status === 'closed' && ticketInfo.closedBy) {
    embed.addFields({ name: 'Closed By', value: `<@${ticketInfo.closedBy}>`, inline: true });
  }

  return embed;
}

// Renames and re-categorizes a ticket channel based on its current state
async function syncTicketChannel(channel, ticketInfo, meta, actorUsername) {
  if (ticketInfo.status === 'closed') {
    await channel.setName(`❌closed-${ticketInfo.closedByUsername || actorUsername}`).catch(() => {});
    const closedCat = process.env.CATEGORY_CLOSED;
    if (closedCat) await channel.setParent(closedCat, { lockPermissions: false }).catch(() => {});
    return;
  }

  if (ticketInfo.claimed) {
    await channel.setName(`✅ticket-${ticketInfo.claimedByUsername || actorUsername}`).catch(() => {});
    const claimedCat = process.env.CATEGORY_CLAIMED;
    if (claimedCat) await channel.setParent(claimedCat, { lockPermissions: false }).catch(() => {});
    return;
  }

  // Reopened / unclaimed — restore to original category
  const originalCat = process.env[meta.categoryEnv];
  await channel.setName(`${meta.emoji}ticket`).catch(() => {});
  if (originalCat) await channel.setParent(originalCat, { lockPermissions: false }).catch(() => {});
}

// ---------------------------------------------------------------------------
// Registration — wires all ticket-related events onto an existing client.
// logAction(guild, embed) is injected from index.js so this module doesn't
// need to know about the log channel itself.
// ---------------------------------------------------------------------------

function register(client, { logAction }) {
  // Follow-up trigger — support tickets only, fired once when the user's
  // reply contains a support-related keyword.
  client.on('messageCreate', async (message) => {
    if (!message.guild || message.author.bot) return;

    const ticketInfo = loadJSON(TICKETS_PATH)[message.channel.id];
    if (!ticketInfo || ticketInfo.type !== 'support' || ticketInfo.followupSent) return;
    if (!SUPPORT_KEYWORDS.test(message.content)) return;

    // Claim the "send the follow-up" right atomically first, so two
    // keyword-matching messages arriving back-to-back can't both pass the
    // followupSent check above and both send the follow-up message.
    const claimed = await updateJSON(TICKETS_PATH, (tickets) => {
      const info = tickets[message.channel.id];
      if (!info || info.followupSent) return false;
      info.followupSent = true;
      return true;
    });
    if (!claimed) return;

    const staffMention = getStaffMention();
    await message.channel.send({
      content: `What kind of support do you need? Pinging staff now ${staffMention}`,
      allowedMentions: { parse: ['roles'] },
    }).catch(() => {});
  });

  client.on('interactionCreate', async (interaction) => {
    try {
      // ============ TICKET CREATION — STEP 1: show the form ============
      if (interaction.isStringSelectMenu() && interaction.customId === 'ticket_create') {
        const type = interaction.values[0];
        const meta = TICKET_TYPES[type];
        const modalConfig = TICKET_MODALS[type];

        const existingId = findOpenTicketChannelId(interaction.user.id);
        if (existingId) {
          const existing = interaction.guild.channels.cache.get(existingId);
          return interaction.reply({
            content: existing
              ? `⚠️ You already have an open ticket: ${existing}. Please close it before opening another.`
              : `⚠️ You already have an open ticket. Please close it before opening another.`,
            ephemeral: true,
          });
        }

        const modal = new ModalBuilder()
          .setCustomId(`ticket_modal_${type}`)
          .setTitle(modalConfig.title);

        const rows = modalConfig.fields.map((f) =>
          new ActionRowBuilder().addComponents(
            new TextInputBuilder()
              .setCustomId(f.id)
              .setLabel(f.label)
              .setStyle(f.style)
              .setRequired(f.required)
              .setMaxLength(f.style === TextInputStyle.Paragraph ? 1000 : 100)
          )
        );
        modal.addComponents(...rows);

        return interaction.showModal(modal);
      }

      // ============ TICKET CREATION — STEP 2: form submitted, create the channel ============
      if (interaction.isModalSubmit() && interaction.customId.startsWith('ticket_modal_')) {
        const type = interaction.customId.replace('ticket_modal_', '');
        const meta = TICKET_TYPES[type];
        const modalConfig = TICKET_MODALS[type];
        const categoryId = process.env[meta.categoryEnv];

        const answers = modalConfig.fields.map((f) => {
          const value = interaction.fields.getTextInputValue(f.id);
          return `**${f.label}**\n${value}`;
        }).join('\n\n');

        // The "already has an open ticket?" check and the write that
        // registers the new ticket both happen inside this single
        // updateJSON call, so two near-simultaneous submissions from the
        // same user can no longer both pass the check and both create a
        // channel.
        let duplicateChannelId = null;
        let channel = null;

        await updateJSON(TICKETS_PATH, async (tickets) => {
          for (const [channelId, info] of Object.entries(tickets)) {
            if (info.owner === interaction.user.id && info.status !== 'closed') {
              duplicateChannelId = channelId;
              return;
            }
          }

          channel = await interaction.guild.channels.create({
            name: `${meta.emoji}${interaction.user.username}`,
            type: ChannelType.GuildText,
            parent: categoryId || undefined,
            topic: `ticket-owner:${interaction.user.id}:${type}`,
            permissionOverwrites: [
              { id: interaction.guild.roles.everyone, deny: [PermissionsBitField.Flags.ViewChannel] },
              { id: interaction.user.id, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory] },
              ...(process.env.STAFF_ROLE_ID ? [{ id: process.env.STAFF_ROLE_ID, allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages] }] : []),
            ],
          });

          tickets[channel.id] = {
            owner: interaction.user.id,
            type,
            claimed: false,
            claimedBy: null,
            claimedByUsername: null,
            status: 'open',
            createdAt: Date.now(),
            closedBy: null,
            closedByUsername: null,
            messageId: null,
            details: answers,
            followupSent: false,
          };
        });

        if (duplicateChannelId) {
          const existing = interaction.guild.channels.cache.get(duplicateChannelId);
          return interaction.reply({
            content: existing
              ? `⚠️ You already have an open ticket: ${existing}. Please close it before opening another.`
              : `⚠️ You already have an open ticket. Please close it before opening another.`,
            ephemeral: true,
          });
        }

        const controls = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('ticket_claim').setLabel('Claim').setEmoji('🙋').setStyle(ButtonStyle.Primary),
          new ButtonBuilder().setCustomId('ticket_close').setLabel('Close').setEmoji('🔒').setStyle(ButtonStyle.Secondary),
          new ButtonBuilder().setCustomId('ticket_reopen').setLabel('Reopen').setEmoji('🔓').setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId('ticket_delete').setLabel('Delete').setEmoji('🗑️').setStyle(ButtonStyle.Danger),
        );

        // Re-read the record we just wrote (cheap, and avoids holding it
        // across the await-heavy channel.send below inside the lock).
        const createdTicket = loadJSON(TICKETS_PATH)[channel.id];

        // Which roles get pinged on ticket creation is configurable via
        // .env (TICKET_PING_ROLE_IDS, comma-separated), falling back to
        // STAFF_ROLE_ID.
        const pingRoleIds = (process.env.TICKET_PING_ROLE_IDS || process.env.STAFF_ROLE_ID || '')
          .split(',').map((s) => s.trim()).filter(Boolean);
        const pingMentions = pingRoleIds.map((id) => `<@&${id}>`).join(' ');

        const sentMessage = await channel.send({
          content: `${interaction.user}${pingMentions ? ' ' + pingMentions : ''}`,
          embeds: [buildTicketEmbed(meta, createdTicket)],
          components: [controls],
          allowedMentions: { parse: ['users', 'roles'] },
        });

        await updateJSON(TICKETS_PATH, (tickets) => {
          if (tickets[channel.id]) tickets[channel.id].messageId = sentMessage.id;
        });

        // Auto-greeting — fires immediately as the ticket is created.
        const greeting = buildAutoGreeting(type, interaction.user.id);
        if (greeting) {
          await channel.send({ content: greeting, allowedMentions: { parse: ['users', 'roles'] } }).catch(() => {});
        }

        await interaction.reply({ content: `✅ Ticket created: ${channel}`, ephemeral: true });
        return logAction(interaction.guild, new EmbedBuilder()
          .setColor(0x2B6CB0)
          .setTitle('🎫 Ticket Created')
          .setDescription(`**Type:** ${meta.label}\n**Owner:** ${interaction.user} (${interaction.user.id})\n**Channel:** ${channel}`)
          .setTimestamp());
      }

      // ============ TICKET CONTROLS (buttons) ============
      if (interaction.isButton() && interaction.customId.startsWith('ticket_')) {
        let ticketInfo = loadJSON(TICKETS_PATH)[interaction.channel.id];
        if (!ticketInfo) return;

        const meta = TICKET_TYPES[ticketInfo.type];
        const isStaff = isStaffMember(interaction.member);

        async function refreshEmbed(info) {
          if (!info.messageId) return;
          const msg = await interaction.channel.messages.fetch(info.messageId).catch(() => null);
          if (msg) await msg.edit({ embeds: [buildTicketEmbed(meta, info)] }).catch(() => {});
        }

        if (interaction.customId === 'ticket_claim') {
          if (!isStaff) return interaction.reply({ content: '❌ Staff only.', ephemeral: true });

          // The "is it already claimed?" check and the claim itself happen
          // inside one updateJSON call, so two staff clicking Claim within
          // milliseconds of each other can't both pass the check and both
          // believe they got it.
          let alreadyClaimedBy = null;
          ticketInfo = await updateJSON(TICKETS_PATH, (tickets) => {
            const info = tickets[interaction.channel.id];
            if (!info) return null;
            if (info.claimed) { alreadyClaimedBy = info.claimedBy; return info; }
            info.claimed = true;
            info.claimedBy = interaction.user.id;
            info.claimedByUsername = interaction.user.username;
            return info;
          });

          if (alreadyClaimedBy) {
            return interaction.reply({ content: `⚠️ This ticket is already claimed by <@${alreadyClaimedBy}>.`, ephemeral: true });
          }
          if (!ticketInfo) return;

          await syncTicketChannel(interaction.channel, ticketInfo, meta, interaction.user.username);
          await refreshEmbed(ticketInfo);

          await interaction.reply({ content: `🙋 Ticket claimed by ${interaction.user}. Moved to **Claimed Tickets**.` });
          return logAction(interaction.guild, new EmbedBuilder()
            .setColor(0x2B6CB0)
            .setTitle('🙋 Ticket Claimed')
            .setDescription(`**Channel:** ${interaction.channel}\n**Claimed By:** ${interaction.user}`)
            .setTimestamp());
        }

        if (interaction.customId === 'ticket_close') {
          if (!isStaff) return interaction.reply({ content: '❌ Staff only.', ephemeral: true });

          ticketInfo = await updateJSON(TICKETS_PATH, (tickets) => {
            const info = tickets[interaction.channel.id];
            if (!info) return null;
            info.status = 'closed';
            info.closedBy = interaction.user.id;
            info.closedByUsername = interaction.user.username;
            return info;
          });
          if (!ticketInfo) return;

          await interaction.channel.permissionOverwrites.edit(ticketInfo.owner, { ViewChannel: false });
          await syncTicketChannel(interaction.channel, ticketInfo, meta, interaction.user.username);
          await refreshEmbed(ticketInfo);

          await interaction.reply({ content: `🔒 Ticket closed by ${interaction.user}. User access revoked. Moved to **Closed Tickets**.` });
          return logAction(interaction.guild, new EmbedBuilder()
            .setColor(0x71717A)
            .setTitle('🔒 Ticket Closed')
            .setDescription(`**Channel:** ${interaction.channel}\n**Closed By:** ${interaction.user}`)
            .setTimestamp());
        }

        if (interaction.customId === 'ticket_reopen') {
          const isOwner = interaction.user.id === ticketInfo.owner;
          if (!isStaff && !isOwner) {
            return interaction.reply({ content: '❌ Only staff or the ticket owner can reopen this ticket.', ephemeral: true });
          }

          ticketInfo = await updateJSON(TICKETS_PATH, (tickets) => {
            const info = tickets[interaction.channel.id];
            if (!info) return null;
            info.status = 'open';
            info.closedBy = null;
            info.closedByUsername = null;
            return info;
          });
          if (!ticketInfo) return;

          await interaction.channel.permissionOverwrites.edit(ticketInfo.owner, {
            ViewChannel: true, SendMessages: true, ReadMessageHistory: true,
          });
          await syncTicketChannel(interaction.channel, ticketInfo, meta, interaction.user.username);
          await refreshEmbed(ticketInfo);

          await interaction.reply({ content: '🔓 Ticket reopened. User access restored.' });
          return logAction(interaction.guild, new EmbedBuilder()
            .setColor(0x2B6CB0)
            .setTitle('🔓 Ticket Reopened')
            .setDescription(`**Channel:** ${interaction.channel}\n**Reopened By:** ${interaction.user}`)
            .setTimestamp());
        }

        if (interaction.customId === 'ticket_delete') {
          if (!isStaff) return interaction.reply({ content: '❌ Staff only.', ephemeral: true });
          await interaction.reply({ content: '🗑️ This channel will be deleted in **5 seconds**...' });
          await logAction(interaction.guild, new EmbedBuilder()
            .setColor(0xE02424)
            .setTitle('🗑️ Ticket Deleted')
            .setDescription(`**Channel:** #${interaction.channel.name}\n**Deleted By:** ${interaction.user}`)
            .setTimestamp());
          await updateJSON(TICKETS_PATH, (tickets) => {
            delete tickets[interaction.channel.id];
          });
          setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
        }
      }
    } catch (err) {
      console.error('[tickets] Interaction error:', err);
      if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
        interaction.reply({ content: '❌ An internal error occurred.', ephemeral: true }).catch(() => {});
      }
    }
  });
}

module.exports = {
  TICKETS_PATH,
  TICKET_TYPES,
  TICKET_PANEL_DESCRIPTION,
  findOpenTicketChannelId,
  register,
};
