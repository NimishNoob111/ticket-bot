'use strict';

const { SlashCommandBuilder } = require('discord.js');
const music = require('../music');
const { checkVoiceState } = require('../musicGuards');

module.exports = {
  data: new SlashCommandBuilder().setName('disconnect').setDescription('Disconnect the bot from voice and clear the queue'),

  async execute(interaction) {
    const denial = checkVoiceState(interaction, 'disconnect');
    if (denial) return interaction.reply(denial);

    const queue = music.getQueue(interaction.guild.id);
    if (!queue) return interaction.reply({ content: '❌ Nothing is playing right now.', ephemeral: true });

    music.stop(interaction.guild.id);
    return interaction.reply({ content: '👋 Disconnected and cleared the queue.' });
  },
};
