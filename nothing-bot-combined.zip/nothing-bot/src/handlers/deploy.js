'use strict';

const crypto = require('node:crypto');
const {
  SlashCommandBuilder,
  PermissionFlagsBits,
} = require('discord.js');
const ptero = require('../pterodactyl');
const { upsertUserMapping } = require('../database');
const { successEmbed, errorEmbed } = require('../utils/embeds');
const { hasManageServerPermission } = require('../utils/permissions');

const DEFAULT_NEST_ID = Number(process.env.DEFAULT_NEST_ID || 1);
const DEFAULT_EGG_ID = Number(process.env.DEFAULT_EGG_ID || 3);

// Which nodes to try (in order) when looking for a free allocation to
// deploy onto. Configure via NODE_IDS in .env as a comma-separated list,
// e.g. NODE_IDS=2,3. Falls back to nodes 2 and 3 if unset, since node 1
// is no longer part of this panel.
const NODE_IDS = (process.env.NODE_IDS || '2,3')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean)
  .map(Number)
  .filter((n) => Number.isInteger(n) && n > 0);
const DEFAULT_DOCKER_IMAGE =
  process.env.DEFAULT_DOCKER_IMAGE || 'ghcr.io/pterodactyl/yolks:java_21';
const DEFAULT_STARTUP_CMD =
  process.env.DEFAULT_STARTUP_CMD ||
  'java -Xms128M -Xmx{{SERVER_MEMORY}}M -Dterminal.jline=false -Dterminal.ansi=true -jar {{SERVER_JARFILE}}';

/** Generates a strong random password for freshly created panel accounts. */
function generatePassword() {
  return crypto.randomBytes(12).toString('base64url'); // ~16 chars, URL-safe
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('register-and-deploy')
    .setDescription(
      'ADMIN: Create a Pterodactyl account (if needed) and deploy a Minecraft Paper server.'
    )
    // Discord-level lock: hidden from members without Administrator by default.
    // Combined with the explicit permission check below (defense in depth).
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addStringOption((o) =>
      o.setName('username').setDescription('Panel username (only used if creating a new account)').setRequired(true)
    )
    .addStringOption((o) =>
      o.setName('email').setDescription('Email address for the panel account').setRequired(true)
    )
    .addStringOption((o) =>
      o.setName('server_name').setDescription('Name for the new game server').setRequired(true)
    )
    .addIntegerOption((o) =>
      o
        .setName('ram_gb')
        .setDescription('RAM to allocate, in GB')
        .setRequired(true)
        .setMinValue(1)
        .setMaxValue(64)
    ),

  async execute(interaction) {
    if (!hasManageServerPermission(interaction)) {
      await interaction.reply({
        embeds: [
          errorEmbed({
            title: 'Permission Denied',
            description: 'This command requires the **Administrator** permission.',
          }),
        ],
        ephemeral: true,
      });
      return;
    }

    const username = interaction.options.getString('username', true).trim();
    const email = interaction.options.getString('email', true).trim();
    const serverName = interaction.options.getString('server_name', true).trim();
    const ramGb = interaction.options.getInteger('ram_gb', true);

    await interaction.deferReply();

    try {
      // -----------------------------------------------------------------
      // STEP A: Ensure the Pterodactyl user exists
      // -----------------------------------------------------------------
      let pterodactylId;
      let generatedPassword = null;
      let accountWasCreated = false;

      const lookup = await ptero.getUserByEmail(email);
      if (!lookup.ok) {
        await interaction.editReply({
          embeds: [errorEmbed({ title: 'Pterodactyl API Error (lookup)', description: lookup.error })],
        });
        return;
      }

      const existing = lookup.data?.data?.[0];

      if (existing) {
        pterodactylId = existing.attributes.id;
      } else {
        generatedPassword = generatePassword();

        const created = await ptero.createUser({
          email,
          username,
          password: generatedPassword,
        });

        if (!created.ok) {
          await interaction.editReply({
            embeds: [errorEmbed({ title: 'Failed To Create Panel Account', description: created.error })],
          });
          return;
        }

        pterodactylId = created.data.attributes.id;
        accountWasCreated = true;
      }

      // Persist the discord_id <-> pterodactyl_id mapping either way.
      upsertUserMapping({
        discordId: interaction.user.id, // linking to the admin running the command;
        // change to a target user option if you want to link a different Discord user.
        pterodactylId,
        pterodactylEmail: email,
      });

      // -----------------------------------------------------------------
      // STEP B: Find a free allocation across the configured nodes
      // -----------------------------------------------------------------
      const allocation = await ptero.getFreeAllocationFromNodes(NODE_IDS);

      if (!allocation.ok) {
        await interaction.editReply({
          embeds: [errorEmbed({ title: 'No Free Allocations', description: allocation.error })],
        });
        return;
      }

      const allocationId = allocation.data.id;
      const chosenNodeId = allocation.data.nodeId;

      // -----------------------------------------------------------------
      // STEP C: Create the server (Minecraft Paper defaults)
      // -----------------------------------------------------------------
      const memoryMb = ramGb * 1024;
      const cpuPercent = ramGb * 100;
      const diskMb = 10240; // 10 GB fixed default, per spec

      const serverPayload = {
        name: serverName,
        user: pterodactylId,

        // ---------------------------------------------------------------
        // 🔧 CHANGE ME: nest_id / egg_id target the stock "Minecraft" nest
        // and "Paper" egg (IDs 1 / 3 on a fresh Pterodactyl install).
        // If your panel's IDs differ, update DEFAULT_NEST_ID / DEFAULT_EGG_ID
        // in your .env, or hardcode different values here.
        // ---------------------------------------------------------------
        nest: DEFAULT_NEST_ID,
        egg: DEFAULT_EGG_ID,

        // ---------------------------------------------------------------
        // 🔧 CHANGE ME: docker_image / startup now come from .env
        // (DEFAULT_DOCKER_IMAGE / DEFAULT_STARTUP_CMD). Check your panel's
        // Admin -> Nests -> Minecraft -> Paper -> Docker Images list for the
        // exact tag your Paper build actually needs (Java version
        // requirements change between Minecraft versions), and match
        // `startup` to your egg's configured startup string.
        // ---------------------------------------------------------------
        docker_image: DEFAULT_DOCKER_IMAGE,
        startup: DEFAULT_STARTUP_CMD,

        environment: {
          // 🔧 CHANGE ME: these variable names must match your Paper egg's
          // defined environment variables exactly (check Admin -> Eggs -> Paper).
          SERVER_JARFILE: 'server.jar',
          MINECRAFT_VERSION: 'latest',
          BUILD_NUMBER: 'latest',
        },

        limits: {
          memory: memoryMb,
          swap: 0,
          disk: diskMb,
          io: 500,
          cpu: cpuPercent,
        },

        feature_limits: {
          databases: 1,
          backups: 1,
          allocations: 1,
        },

        allocation: {
          default: allocationId,
        },

        // Start installing immediately; set to false if you want to review first.
        start_on_completion: true,
      };

      const created = await ptero.createServer(serverPayload);

      if (!created.ok) {
        await interaction.editReply({
          embeds: [errorEmbed({ title: 'Failed To Create Server', description: created.error })],
        });
        return;
      }

      const serverAttrs = created.data.attributes;

      // -----------------------------------------------------------------
      // Deliver credentials privately via DM instead of posting the
      // password in the (potentially public) channel reply.
      // -----------------------------------------------------------------
      let dmSent = false;

      if (accountWasCreated) {
        try {
          await interaction.user.send({
            embeds: [
              successEmbed({
                title: 'New Panel Account Credentials',
                description: `Credentials for the account just created for **${serverName}**. Please change this password after logging in.`,
                fields: [
                  { name: 'Username', value: username, inline: true },
                  { name: 'Email', value: email, inline: true },
                  { name: 'Temporary Password', value: `\`${generatedPassword}\`` },
                ],
              }),
            ],
          });
          dmSent = true;
        } catch (dmErr) {
          console.warn('[/register-and-deploy] Could not DM credentials:', dmErr.message);
          dmSent = false;
        }
      }

      const credentialLines = accountWasCreated
        ? [
            `**Username:** ${username}`,
            `**Email:** ${email}`,
            dmSent
              ? '_Temporary password sent to you via DM._'
              : "⚠️ _Couldn't DM you (check your privacy settings) — sending it to you privately below instead._",
          ]
        : [`**Email:** ${email}`, '_Existing account — no new credentials generated._'];

      await interaction.editReply({
        embeds: [
          successEmbed({
            title: 'Server Deployed',
            description: `**${serverName}** has been created and is installing now.`,
            fields: [
              { name: 'Panel Account', value: credentialLines.join('\n') },
              { name: 'Server ID', value: `${serverAttrs.id}`, inline: true },
              { name: 'Identifier', value: `\`${serverAttrs.identifier}\``, inline: true },
              { name: 'Node', value: `${chosenNodeId}`, inline: true },
              { name: 'RAM', value: `${ramGb} GB`, inline: true },
              { name: 'CPU', value: `${cpuPercent}%`, inline: true },
              { name: 'Disk', value: `${diskMb} MB`, inline: true },
              {
                name: 'Allocation',
                value: `${allocation.data.ip}:${allocation.data.port}`,
                inline: true,
              },
            ],
          }),
        ],
      });

      // Fallback: if the DM failed, still deliver the password privately via
      // an ephemeral follow-up (visible only to the admin who ran the command).
      if (accountWasCreated && !dmSent) {
        await interaction.followUp({
          embeds: [
            errorEmbed({
              title: 'Credentials (DM Failed)',
              description: `Couldn't reach your DMs — here's the password privately instead:\n**Password:** \`${generatedPassword}\``,
            }),
          ],
          ephemeral: true,
        });
      }
    } catch (err) {
      console.error('[/register-and-deploy] Unexpected error:', err);
      await interaction.editReply({
        embeds: [
          errorEmbed({
            description: 'An unexpected error occurred. Check the bot console logs.',
          }),
        ],
      });
    }
  },
};
